await page.screenshot({path:'/tmp/learning-travel-e5-myi2vxx8/browser-submission-approval-before.png',fullPage:true});
await page.getByRole('button',{name:'批准',exact:true}).click();
await page.waitForTimeout(1000);console.log((await page.locator('body').innerText()).slice(-2300));
