import json
from pathlib import Path
from learning_agent_eval.blinding_v2 import build_blind_judge_input_v3
from learning_agent_eval.active_judge import build_provider_request_v3
from learning_agent_eval.judge_request_projection import unpack_shared_values
from learning_agent_eval.canonical import canonical_json_bytes
from learning_agent_eval.rubric import JUDGE_CONFIG_DOCUMENT_V3
from learning_agent_eval.validator import resolve_evidence_path
base=Path('/tmp/learning-travel-e5-myi2vxx8'); r=base/'calibration-runtime'; out=[]
for p in sorted((r/'episodes').glob('*.json')):
 e=json.loads(p.read_text());eid=e['episode_id'];rule=json.loads((base/f'calibration-rules/rules/{eid}.json').read_text());ref=json.loads((r/f'judge-references/{eid}.json').read_text());blind=build_blind_judge_input_v3(e,rule,ref)
 req=build_provider_request_v3(blind,repair_error_codes=['response_evidence_invalid'],invalid_evidence_paths=['episode.result.action_class'])
 packed=json.loads(req['messages'][1]['content']);assert canonical_json_bytes(unpack_shared_values(packed))==canonical_json_bytes(blind.document)
 assert all(resolve_evidence_path(e,path)[0] for path in packed['evidence_path_catalog'])
 body={k:JUDGE_CONFIG_DOCUMENT_V3[k] for k in ['model','temperature','reasoning_effort','max_tokens','n']};body.update(messages=req['messages'],response_format=req['response_format']);bound=len(canonical_json_bytes(body))+2048
 assert bound<=196608,(eid,bound)
 out.append(dict(episode_id=eid,track=e['track'],input_bound_with_repair=bound,lossless_round_trip=True))
(base/'preflight-v2.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print('24/24 lossless + path validity + request admission',min(x['input_bound_with_repair'] for x in out),max(x['input_bound_with_repair'] for x in out))
