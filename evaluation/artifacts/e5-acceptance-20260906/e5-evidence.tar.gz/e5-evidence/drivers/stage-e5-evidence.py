import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path

BASE = Path('/tmp/learning-travel-e5-myi2vxx8')
REPO = Path('/root/workspace/tencent_rhinobird2026/learning_travel')
STAGE = BASE / 'public-evidence'
PRIVATE = Path('/root/.local/state/learning-travel/e5-browser-20260906')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + '\n')


def cp(source, target):
    target.parent.mkdir(parents=True, exist_ok=True)
    if source.is_dir():
        shutil.copytree(source, target)
    else:
        shutil.copy2(source, target)


assert not STAGE.exists()
STAGE.mkdir()
for name in ['calibration-runtime', 'calibration-rules', 'e5-v1',
             'calibration-runtime-v2', 'calibration-rules-v2', 'e5-v2']:
    cp(BASE / name, STAGE / name)

for path in sorted(BASE.iterdir()):
    if not path.is_file():
        continue
    if path.suffix == '.log':
        cp(path, STAGE / 'logs' / path.name)
    elif path.name.startswith('browser-') and path.suffix in {'.png', '.txt', '.json'}:
        cp(path, STAGE / 'browser' / path.name)
    elif path.suffix in {'.py', '.mjs', '.js'}:
        cp(path, STAGE / 'drivers' / path.name)
    elif path.name.startswith('preflight-') and path.suffix == '.json':
        cp(path, STAGE / 'preflight' / path.name)
    elif path.name in {'budget-start.json', 'budget-final.json', 'budget-reconciliation.json', 'price-check.json'}:
        cp(path, STAGE / 'budget' / path.name)
    elif path.name in {'git-task-1-evidence.txt', 'e5-content-inspection.txt'}:
        cp(path, STAGE / ('browser' if path.name.startswith('git-') else 'review') / path.name)

for path in (BASE / 'browser-state').glob('*-calls.jsonl'):
    cp(path, STAGE / 'browser' / path.name)

source_index = []
for name, clone, commit in [
    ('v1-3ed0541', 'experiment-repo', '3ed0541346909500c65123a2dd87188136ab39b4'),
    ('v2-40fddb8', 'experiment-v2-repo', '40fddb8f777e16de9711863381a4e26f534e4529'),
    ('final-d8fa199', 'final-verification-repo', 'd8fa1999cbeea4e820c610d201e084acbd49d5f7'),
]:
    root = BASE / clone
    actual = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
    assert actual == commit
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True).strip()
    target = STAGE / 'sources' / name
    paths = set()
    bundles = {}
    for file in (root / 'evaluation/releases/source-bundles').glob('*.json'):
        bundle = json.loads(file.read_text())
        bundles[bundle['component']] = bundle['bundle_sha256']
        for item in bundle['files']:
            path = root / item['relative_path']
            assert sha(path) == item['sha256'], (name, item['relative_path'])
            paths.add(item['relative_path'])
    for relative in sorted(paths):
        cp(root / relative, target / relative)
    for relative in ['evaluation/releases', 'evaluation/datasets/decisionbench-v1-candidate',
                     'evaluation/datasets/decisionbench-v4-engineering']:
        cp(root / relative, target / relative)
    cp(root / 'docs/E5验收工作记录.md', target / 'docs/E5验收工作记录.md')
    item = {'name': name, 'commit': actual, 'tracked_tree_clean': True,
            'source_bundle_files_verified': len(paths), 'source_bundle_sha256': bundles}
    write(target / 'snapshot.json', item)
    source_index.append(item)
write(STAGE / 'sources/index.json', source_index)

for folder, name in [
    (Path('/tmp/learning-s06-7rs1sff5'), 's06'),
    (Path('/tmp/learning-sse-g0amjlql'), 'sse'),
    (Path('/tmp/learning-approval-elapsed-rpvwc9cd'), 'approval-and-summary'),
]:
    for path in folder.iterdir():
        if path.is_file() and path.suffix in {'.log', '.json'}:
            cp(path, STAGE / 'verification' / name / path.name)
for path in Path('/tmp').glob('learning-e5-judge-failures*.log'):
    cp(path, STAGE / 'verification/judge-failures' / path.name)

# Keep the complete isolated learner state locally, outside the public archive.
assert not PRIVATE.exists()
cp(BASE / 'browser-state', PRIVATE)
cp(BASE / 'learner-git-project', PRIVATE / 'learner-git-project')
(PRIVATE / 'README.txt').write_text(
    'E5 isolated synthetic learner state, 2026-09-06. Private local evidence.\n'
    'Contains the original SQLite, uploads, expanded context and built frontend; do not publish the whole directory.\n'
    'The public, redacted projection is in evaluation/artifacts/e5-acceptance-20260906.\n'
    'No running service. Any authorized resume must reuse the original shared budget ledger and environment key.\n'
)
private_files = []
for path in sorted(PRIVATE.rglob('*')):
    os.chmod(path, 0o700 if path.is_dir() else 0o600)
    if path.is_file():
        private_files.append({'path': str(path.relative_to(PRIVATE)), 'bytes': path.stat().st_size, 'sha256': sha(path)})
os.chmod(PRIVATE, 0o700)
assert sha(BASE / 'browser-state/data/learning_companion.db') == sha(PRIVATE / 'data/learning_companion.db')
write(STAGE / 'browser/private-local-state-inventory.json', {
    'local_only_directory': str(PRIVATE), 'published_database': False,
    'contains_no_database_or_context_content': True,
    'files': private_files,
})

report = json.loads((STAGE / 'browser/browser-public-facts.json').read_text())
screenshots = []
special = {
    'browser-approval-after.png': 'Restart home page; not evidence of approval success.',
    'browser-revision-reconnected.png': 'Reconnect while already terminal; not an active reconnect proof.',
    'browser-active-reconnect.png': 'Final d8fa199 active run, offline/online/reload; same durable run restored.',
    'browser-final-restored.png': 'Final d8fa199 completed read-only review after active reconnect.',
    'browser-task-controls.png': 'Desktop task submission control scrolled into view and hit-tested.',
}
for path in sorted((STAGE / 'browser').glob('*.png')):
    screenshots.append({'file': path.name, 'sha256': sha(path), 'interpretation': special.get(path.name, 'Contemporaneous browser screenshot; correlate with the work record and public facts.')})
write(STAGE / 'browser/experience-review.json', {
    'version': 'e5-browser-ai-experience-review-v1',
    'reviewer_role': 'primary_ai_reviewer', 'independent_human': False,
    'provider': 'real Hy3', 'public_facts_sha256': sha(STAGE / 'browser/browser-public-facts.json'),
    'counts': report['counts'], 'screenshots': screenshots,
    'active_reconnect_run': 'cc39f58c-79c7-4ee7-9456-114f8c01572d',
    'adjustment_run': '3d4730fc-1b10-449a-9ecd-b1d3ae1b96a4',
    'original_elapsed_fallback_run': '1df64568-8faf-4373-8e69-4c2f298ca67f',
    'isolated_state_complete_preserved_locally': True,
    'limitations': [
        'A completed Runtime fallback did not fulfill the original goal; the learner retried later.',
        'Only one synthetic Git learning story, not real human learning-effect evidence.',
        'Initial 15 browser requests have ledger coverage but no persisted public per-call JSONL; later 18 have both.',
        'Two initial browser requests retain unknown usage reservation, without reconstructing unavailable response payloads.',
        'Early DOM observations were tool outputs only; automatic text logs started partway through the workflow.',
        'The actual plan-scoped session was newly created with no parent/handoff; other handoff branches are test coverage.',
        'The uploaded file contains actual terminal outputs, not the literal hello.py source claimed in one user message.',
    ],
})

print(json.dumps({'stage': str(STAGE), 'private_state': str(PRIVATE),
                  'source_versions': len(source_index), 'files': sum(p.is_file() for p in STAGE.rglob('*'))}, ensure_ascii=False))
