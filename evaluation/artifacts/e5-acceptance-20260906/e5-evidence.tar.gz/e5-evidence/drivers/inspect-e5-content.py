import json,pathlib
root=pathlib.Path('/tmp/learning-travel-e5-myi2vxx8'); design=json.load(open(root/'e5-v2/design.json'))
for item in design['cases']:
 if item['label']=='good' and item['track']!='revision':continue
 e=json.load(open(root/'calibration-runtime-v2/episodes'/f"{item['episode_id']}.json"));r=json.load(open(root/'calibration-rules-v2/rules'/f"{item['episode_id']}.json"))
 print('\nCASE',item['case_id']);print('OBJECTIVE',e['trigger']['objective']);print('OUTPUT',e['result']['user_visible_output']);print('ACTION',e['result']['action_class']);print('CALL TEXT',[x['assistant_text'] for x in e['observable_trace']['model_calls']]);
 print('TOOLS',json.dumps([{'name':x.get('tool_name',x.get('name')),'args':x['canonical_args'],'result':x['result']} for x in e['observable_trace']['tool_invocations']],ensure_ascii=False));
 print('RULE FAILURES',json.dumps([x for x in r['checks'] if x['status']=='fail'],ensure_ascii=False))
