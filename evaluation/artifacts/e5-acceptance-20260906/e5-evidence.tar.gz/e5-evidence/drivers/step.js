await page.reload({waitUntil:'domcontentloaded'});
await page.waitForTimeout(1000);
await page.getByRole('button',{name:'提交成果',exact:true}).first().click();
await page.waitForTimeout(1500);
console.log(page.url());
console.log((await page.locator('body').innerText()).slice(-4500));
await page.screenshot({path:'/tmp/learning-travel-e5-myi2vxx8/browser-plan-scope-fixed.png',fullPage:true});
