console.log('BEFORE DISCONNECT',(await page.locator('body').innerText()).slice(-2200));
await context.setOffline(true);await page.waitForTimeout(1500);await context.setOffline(false);await page.waitForTimeout(1800);
console.log('RECONNECTED',(await page.locator('body').innerText()).slice(-3500));
await page.screenshot({path:'/tmp/learning-travel-e5-myi2vxx8/browser-revision-reconnected.png',fullPage:true});
