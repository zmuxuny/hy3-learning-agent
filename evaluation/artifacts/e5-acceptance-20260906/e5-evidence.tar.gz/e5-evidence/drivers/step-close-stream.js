await page.goto('about:blank');console.log('Closed browser stream before server restart.');
