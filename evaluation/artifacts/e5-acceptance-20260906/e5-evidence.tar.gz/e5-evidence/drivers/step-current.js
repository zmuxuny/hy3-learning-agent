console.log('URL',page.url());console.log((await page.locator('body').innerText()).slice(-18000));
