import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile
from pathlib import Path

from dotenv import dotenv_values

BASE = Path('/tmp/learning-travel-e5-myi2vxx8')
REPO = Path('/root/workspace/tencent_rhinobird2026/learning_travel')
STAGE = BASE / 'public-evidence'
OUT = REPO / 'evaluation/artifacts/e5-acceptance-20260906'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n')


for name in ['archive-validation.json', 'archive-replay-verification.json']:
    shutil.copy2(BASE / name, STAGE / name)
    shutil.copy2(BASE / name, OUT / name)
shutil.copy2(BASE / 'archive-validation.log', STAGE / 'logs/archive-validation.log')
shutil.copy2(Path(__file__), STAGE / 'drivers' / Path(__file__).name)
schemas = sorted((REPO / 'evaluation/schemas').glob('*.json'))
assert len(schemas) == 44
for path in schemas:
    before = subprocess.check_output(['git', 'show', '5e7a4fb:' + str(path.relative_to(REPO))], cwd=REPO)
    assert path.read_bytes() == before == (STAGE / 'frozen-schemas' / path.name).read_bytes()
write(STAGE / 'schema-preservation.json', {
    'handoff_commit': '5e7a4fb', 'files': 44, 'all_original_bytes_unchanged': True,
})

secret = dotenv_values(REPO / '.env').get('OPENAI_API_KEY')
assert secret
secret_bytes = secret.encode()
members = []
for path in sorted(STAGE.rglob('*')):
    assert not path.is_symlink()
    if not path.is_file():
        continue
    assert secret_bytes not in path.read_bytes()
    assert path.suffix not in {'.sqlite', '.sqlite3', '.db'} and path.name != '.env'
    members.append({'path': str(path.relative_to(STAGE)), 'bytes': path.stat().st_size, 'sha256': sha(path)})
member_manifest = {
    'version': 'e5-evidence-file-inventory-v1', 'root': 'e5-evidence',
    'excludes_self': 'member-manifest.json', 'member_count_excluding_self': len(members),
    'total_bytes_excluding_self': sum(row['bytes'] for row in members), 'members': members,
}
write(STAGE / 'member-manifest.json', member_manifest)
archive = OUT / 'e5-evidence.tar.gz'
assert not archive.exists()
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=9) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for path in sorted(STAGE.rglob('*')):
                if not path.is_file():
                    continue
                info = tar.gettarinfo(str(path), arcname='e5-evidence/' + str(path.relative_to(STAGE)))
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                info.mtime = 0
                info.mode = 0o644
                with path.open('rb') as source:
                    tar.addfile(info, source)

with tarfile.open(archive, 'r:gz') as tar:
    packed = tar.getmembers()
    assert len(packed) == len(members) + 1
    assert all(item.isfile() and item.name.startswith('e5-evidence/') and '..' not in Path(item.name).parts for item in packed)
    for row in members:
        content = tar.extractfile('e5-evidence/' + row['path']).read()
        assert len(content) == row['bytes'] and hashlib.sha256(content).hexdigest() == row['sha256']

index = {
    'version': 'e5-acceptance-artifact-index-v1',
    'archive': {'file': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive),
                'member_count': len(members) + 1, 'members_verified_after_compression': True},
    'member_manifest_path_in_archive': 'e5-evidence/member-manifest.json',
    'source_code_commit': 'd8fa1999cbeea4e820c610d201e084acbd49d5f7',
    'judge_v2_commit': '40fddb8f777e16de9711863381a4e26f534e4529',
    'exact_key_occurrences_all_final_archive_members': 0,
    'all_44_schema_bytes_match_handoff': True,
    'members': members,
}
write(OUT / 'artifact-index.json', index)
print(json.dumps(index['archive'], ensure_ascii=False))
