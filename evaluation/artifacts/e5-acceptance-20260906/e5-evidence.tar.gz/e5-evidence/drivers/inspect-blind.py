import json,collections
from pathlib import Path
from learning_agent_eval.blinding_v2 import build_blind_judge_input_v3
from learning_agent_eval.canonical import canonical_json_bytes
root=Path('/tmp/learning-travel-e5-myi2vxx8/calibration-runtime');rules=Path('/tmp/learning-travel-e5-myi2vxx8/calibration-rules')
p=next(root.glob('episodes/episode-17dd*.json'));e=json.loads(p.read_text());id=e['episode_id'];b=build_blind_judge_input_v3(e,json.loads((rules/f'rules/{id}.json').read_text()),json.loads((root/f'judge-references/{id}.json').read_text())).document
print('bytes',len(canonical_json_bytes(b)))
def sizes(d,p='',depth=0):
 if isinstance(d,dict) and depth<3:
  for k,v in d.items():
   if len(canonical_json_bytes(v))>3000: print(p+k,len(canonical_json_bytes(v)));sizes(v,p+k+'.',depth+1)
sizes(b)
print('modelcall keys',b['episode']['observable_trace']['model_calls'][0].keys())
print('tool keys',b['episode']['observable_trace'].keys())
for k,v in b['episode']['observable_trace'].items():
 if isinstance(v,list):print(k,len(v),[(x.get('tool_name'),x.keys()) for x in v[:1]])
