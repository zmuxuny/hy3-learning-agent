from pathlib import Path
import subprocess
base=Path('/tmp/learning-travel-e5-myi2vxx8');work=base/'learner-git-project';work.mkdir(exist_ok=False)
lines=['# 学习者练习证据（由主 AI 以学习者身份实际操作）','', '目标：本地 Git 初始化、首次提交、干净工作区；无远程仓库。','']
def run(*args):
 r=subprocess.run(args,cwd=work,text=True,capture_output=True);lines.append('$ '+' '.join(args));lines.append((r.stdout+r.stderr).rstrip());lines.append('exit_code='+str(r.returncode));lines.append('');assert r.returncode==0
run('git','--version');run('python3','--version');run('git','init','-b','main')
run('git','config','user.name','AI Learner');run('git','config','user.email','ai-learner@example.invalid')
(work/'hello.py').write_text('print("v1 hello git")\n')
run('git','status');run('git','add','hello.py');run('git','status');run('git','commit','-m','init: add learning script');run('git','log','--oneline');run('python3','hello.py');run('git','status');run('git','remote','-v');run('git','rev-parse','--is-inside-work-tree')
lines.append('观察：文件开始为 Untracked，add 后进入暂存区，commit 后 log 有一条记录且工作区 clean；Python 输出 v1 hello git。')
(base/'git-task-1-evidence.txt').write_text('\n'.join(lines)+'\n');print('\n'.join(lines))
