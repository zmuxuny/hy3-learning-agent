await page.reload();await page.waitForTimeout(900);
const results=[];
for (const width of [375,768,1280,1440]) {
 await page.setViewportSize({width,height:1000});await page.waitForTimeout(300);
 await page.getByText('最近学习证据',{exact:true}).scrollIntoViewIfNeeded();
 const metrics=await page.evaluate(()=>({scrollWidth:document.documentElement.scrollWidth,clientWidth:document.documentElement.clientWidth}));
 results.push({width,...metrics,submissionButtons:await page.getByRole('button',{name:'提交成果',exact:true}).count()});
 await page.screenshot({path:`/tmp/learning-travel-e5-myi2vxx8/browser-evidence-${width}-final.png`,fullPage:true});
}
await writeFile('/tmp/learning-travel-e5-myi2vxx8/browser-responsive-final.json',JSON.stringify(results,null,2));console.log(results);
await page.goto('http://127.0.0.1:8765/sessions/16fb65c3-bc58-4925-a294-ee13ec250a5b');await page.waitForTimeout(900);
await page.route('**/api/v1/agent/runs',route=>route.request().method()==='POST'?route.abort('failed'):route.continue());
const draft='核对当前任务进度。';await page.locator('textarea').fill(draft);await page.locator('textarea').press('Enter');await page.waitForTimeout(500);
console.log('ERROR FIX',await page.getByText('无法连接服务，请检查网络后重试。',{exact:true}).innerText(),'DRAFT',await page.locator('textarea').inputValue());
await page.screenshot({path:'/tmp/learning-travel-e5-myi2vxx8/browser-network-error-final.png',fullPage:true});
await page.unroute('**/api/v1/agent/runs');await page.locator('textarea').fill('');
