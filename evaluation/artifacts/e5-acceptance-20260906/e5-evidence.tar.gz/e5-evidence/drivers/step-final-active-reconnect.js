await page.goto('http://127.0.0.1:8765/sessions/16fb65c3-bc58-4925-a294-ee13ec250a5b');await page.waitForTimeout(900);
await page.locator('textarea').fill('请读取当前计划并核对任务 1 的提交结果。用一两句话说明目前进度、每周时间和剩余任务，不需要创建、修改或发送任何内容。');await page.locator('textarea').press('Enter');await page.waitForTimeout(700);
console.log('ACTIVE BEFORE',(await page.locator('body').innerText()).slice(-1100));
await context.setOffline(true);await page.waitForTimeout(1000);await context.setOffline(false);await page.waitForTimeout(1300);
console.log('ACTIVE AFTER',(await page.locator('body').innerText()).slice(-1100));
await page.reload();await page.waitForTimeout(1100);console.log('RESTORED',(await page.locator('body').innerText()).slice(-1700));
await page.screenshot({path:'/tmp/learning-travel-e5-myi2vxx8/browser-active-reconnect.png',fullPage:true});
