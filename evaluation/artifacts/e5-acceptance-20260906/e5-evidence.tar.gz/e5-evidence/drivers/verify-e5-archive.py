import hashlib
import json
from pathlib import Path

from dotenv import dotenv_values
from learning_agent_eval.canonical import sha256_digest
from learning_agent_eval.privacy import privacy_issues

BASE = Path('/tmp/learning-travel-e5-myi2vxx8')
REPO = Path('/root/workspace/tencent_rhinobird2026/learning_travel')
STAGE = BASE / 'public-evidence'
ledger = Path('/root/.local/state/learning-travel/e4-hy3-20260905-osj4FCZZ-budget.json')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


issues = []
checked_documents = 0
for root in ['e5-v1', 'e5-v2', 'calibration-runtime', 'calibration-rules',
             'calibration-runtime-v2', 'calibration-rules-v2', 'browser', 'budget', 'review']:
    for path in (STAGE / root).rglob('*'):
        if not path.is_file():
            continue
        if path.suffix == '.json':
            documents = [read(path)]
        elif path.suffix == '.jsonl':
            documents = [json.loads(line) for line in path.read_text().splitlines() if line]
        else:
            continue
        for document in documents:
            checked_documents += 1
            issues.extend({'file': str(path.relative_to(STAGE)), 'code': issue.code, 'path': issue.path}
                          for issue in privacy_issues(document, file=str(path.relative_to(STAGE))))
assert not issues, issues

# Compare exact secret bytes without printing them or sending them anywhere.
secret = dotenv_values(REPO / '.env').get('OPENAI_API_KEY')
assert secret
secret_bytes = secret.encode()
files = sorted(path for path in STAGE.rglob('*') if path.is_file())
assert not any(secret_bytes in path.read_bytes() for path in files)
for path in files:
    assert path.name != '.env' and path.suffix not in {'.db', '.sqlite', '.sqlite3'}

end = read(ledger)
start = read(STAGE / 'budget/budget-start.json')
assert sha(ledger) == sha(STAGE / 'budget/budget-final.json') == '18bf439406ceee17967cba6f5dfd96e3f0deae99a256a7a671cf907b3245ad87'
assert len(end['requests']) == 330
prefix = hashlib.sha256(json.dumps(end['requests'][:190], sort_keys=True).encode()).hexdigest()
assert prefix == start['historical_requests_sha256']
assert sum(row['charged_micro_cny'] for row in end['requests']) == 11606238
assert sum(row['charged_micro_cny'] for row in end['requests'][:190]) == 5397645
assert not any(row['status'] == 'reserved' for row in end['requests'])

method = read(STAGE / 'e5-v2/method-validation.json')
assert sha256_digest({key: value for key, value in method.items() if key != 'report_sha256'}) == method['report_sha256']
assert method['metrics_sha256'] == sha256_digest(read(STAGE / 'e5-v2/metrics.json'))
assert method['defect_review_sha256'] == read(STAGE / 'e5-v2/defect-content-review.json')['review_sha256']
assert method['minimum_prespecified_method_targets_met'] and method['experiment_execution_complete']

audit = read(STAGE / 'verification/approval-and-summary/e5-final-audit.json')
assert sum(audit['checks'].values()) == 2765
assert audit['experiment_complete'] and audit['declared_macro_method_targets_met']
for log, fragment in [('full-regression.log', '1378 passed, 2 warnings'),
                      ('final-evaluation-regression.log', '292 passed'),
                      ('final-product-regression.log', '34 passed'),
                      ('frontend-approval-preview-tests.log', '45 passed')]:
    assert fragment in (STAGE / 'logs' / log).read_text()

report = {
    'version': 'e5-public-archive-validation-v1', 'reviewer_role': 'primary_ai_reviewer',
    'real_model_calls': 0, 'structured_documents_privacy_checked': checked_documents,
    'privacy_issues': issues, 'files_checked_for_exact_authorized_key': len(files),
    'exact_key_occurrences': 0, 'database_or_env_files_published': False,
    'ledger_snapshot_matches_live_read_only': True, 'historical_190_requests_unchanged': True,
    'ai_recomputed_assertions': sum(audit['checks'].values()), 'method_report_bindings_verified': True,
    'fixed_source_snapshots': read(STAGE / 'sources/index.json'),
    'private_state_directory': '/root/.local/state/learning-travel/e5-browser-20260906',
    'private_state_published': False,
}
(BASE / 'archive-validation.json').write_text(json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2) + '\n')
print(json.dumps({k: v for k, v in report.items() if k != 'fixed_source_snapshots'}, ensure_ascii=False))
