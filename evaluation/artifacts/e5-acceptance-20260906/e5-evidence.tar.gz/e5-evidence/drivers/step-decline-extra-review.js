await page.locator('.approval-answer').fill('本周时间很紧，暂不额外安排复习，也不要创建新提醒。保留任务 1 的已通过验收，请用中文简短汇报结果。');
await page.getByRole('button',{name:'回答并继续',exact:true}).click();
console.log('Declined extra scheduled review; kept acceptance.');
