await page.screenshot({path:'/tmp/learning-travel-e5-myi2vxx8/browser-assessment-approval-before.png',fullPage:true});
await page.getByRole('button',{name:'批准',exact:true}).click();
await page.waitForTimeout(700);console.log((await page.locator('body').innerText()).slice(-1200));
