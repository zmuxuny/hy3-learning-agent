import json,sqlite3
from pathlib import Path
from learning_agent_eval.recorder import public_projection
from learning_agent_eval.privacy import privacy_issues
from learning_agent_eval.canonical import sha256_digest
base=Path('/tmp/learning-travel-e5-myi2vxx8');db=sqlite3.connect('file:'+str(base/'browser-state/data/learning_companion.db')+'?mode=ro',uri=True);db.row_factory=sqlite3.Row
columns={
 'agent_runs':'id,session_id,plan_id,parent_run_id,trigger,objective,status,phase,status_reason,budget_usage,output,created_plan_id,started_at,completed_at,created_at',
 'plans':'id,title,description,goal,current_level,deadline,weekly_minutes,preferences,expected_outcome,status,version,progress,memory_summary,created_at,updated_at',
 'stages':'id,plan_id,title,description,objectives,status,position',
 'tasks':'id,stage_id,title,description,kind,status,is_core,evidence_required,estimated_minutes,position,due_at,completed_at,review_due_at,resource_url,task_metadata',
 'task_submissions':'id,plan_id,task_id,run_id,submission_type,content,artifacts,status,score,feedback,checked_at,created_at',
 'operations':'id,run_id,invocation_id,tool_name,entity_type,entity_id,forward_patch,inverse_patch,status,created_at,undone_at',
 'run_approvals':'id,run_id,invocation_id,tool_call_id,tool_name,tool_call,reason,decision,note,answer,decided_at,consumed_at,created_at',
 'tool_invocations':'id,run_id,tool_name,tool_call_id,args_hash,request_digest,canonical_args,effect_kind,status,result_payload,attempt,version,completed_at,created_at',
 'sessions':'id,plan_id,parent_session_id,title,handoff_summary,archived_at,created_at',
 'chat_messages':'id,session_id,run_id,role,content,version,content_hash,validity_state,message_metadata,created_at',
 'evidence_observations':'id,source_type,source_id,run_id,session_id,plan_id,task_id,fact_kind,target_observation_id,reason_code,evidence_role,eligibility_stage,eligibility_reason,counts_as_success,outcome,normalized_score,is_correct,assistance_level,transfer_level,rubric_snapshot,evaluator,occurred_at,recorded_at',
 'review_schedules':'id,plan_id,task_id,status,due_at,review_type',
}
json_fields={'budget_usage','preferences','artifacts','forward_patch','inverse_patch','tool_call','canonical_args','result_payload','message_metadata','rubric_snapshot','evaluator','task_metadata','objectives'}
tables={}
for table,cols in columns.items():
 rows=[]
 for raw in db.execute('SELECT '+cols+' FROM '+table+' ORDER BY id'):
  row=dict(raw)
  for k in json_fields & row.keys():
   if isinstance(row[k],str):
    try:row[k]=json.loads(row[k])
    except ValueError:pass
  rows.append(public_projection(row))
 tables[table]=rows
# Preserve public operation/approval/error events, excluding raw reasoning and expanded contexts.
events=[]
for raw in db.execute('SELECT run_id,sequence,event_type,summary,payload,created_at FROM run_events ORDER BY run_id,sequence'):
 row=dict(raw)
 if row['event_type']=='assistant.reasoning':continue
 payload=json.loads(row['payload']) if row['payload'] else {}
 if row['event_type']=='context.built':payload={k:payload[k] for k in ['estimated_tokens','sections','request_budget_breakdown'] if k in payload}
 row['payload']=public_projection(payload);events.append(row)
tables['run_events']=events
issues=privacy_issues(tables,file='browser-public-facts');print('privacy issues',[(i.code,i.path) for i in issues]);assert not issues
report={'version':'e5-browser-public-evidence-v1','reviewer_role':'primary_ai_reviewer','source':'isolated learner database, read-only projection','not_exported':['expanded context snapshots','private reasoning','Runtime checkpoints','provider credentials'],'tables':tables,'counts':{k:len(v) for k,v in tables.items()}}
report['evidence_sha256']=sha256_digest(report);(base/'browser-public-facts.json').write_text(json.dumps(report,ensure_ascii=False,sort_keys=True,indent=2)+'\n');print(report['counts'])
