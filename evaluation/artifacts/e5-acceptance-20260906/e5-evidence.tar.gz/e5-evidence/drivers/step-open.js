await page.getByText('我想学会用 Git 给一个 Python 小项目做本地版本管理。基础、时间和验收方式我还想和你一起确认。',{exact:true}).first().click();
await page.waitForTimeout(1200);
console.log((await page.locator('body').innerText()).slice(-5500));
await page.screenshot({path:'/tmp/learning-travel-e5-myi2vxx8/browser-approval-visible.png',fullPage:true});
