import os, runpy, sys
from pathlib import Path
from dotenv import dotenv_values
root=Path('/root/workspace/tencent_rhinobird2026/learning_travel')
key=os.environ.get('OPENAI_API_KEY') or dotenv_values(root/'.env').get('OPENAI_API_KEY')
if not key:
 raise RuntimeError('authorized provider key unavailable')
os.environ['OPENAI_API_KEY']=key
sys.argv=sys.argv[1:]
runpy.run_path(sys.argv[0],run_name='__main__')
