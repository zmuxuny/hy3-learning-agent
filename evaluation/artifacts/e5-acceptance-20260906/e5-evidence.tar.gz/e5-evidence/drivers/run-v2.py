import subprocess,os,sys
from pathlib import Path
base=Path('/tmp/learning-travel-e5-myi2vxx8');repo=base/'experiment-v2-repo';runtime=base/'calibration-runtime-v2';rules=base/'calibration-rules-v2';out=base/'e5-v2';ledger='/root/.local/state/learning-travel/e4-hy3-20260905-osj4FCZZ-budget.json'
env={**os.environ,'PYTHONPATH':'evaluation/src'}
def run(label,args,allowed=(0,)):
 with (base/f'{label}.log').open('w') as log:
  result=subprocess.run([sys.executable,*map(str,args)],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 print(label,'exit',result.returncode,flush=True)
 if result.returncode not in allowed:raise SystemExit(result.returncode)
run('calibration-runtime-v2',['-m','learning_agent_eval','run-agent','--dataset','evaluation/datasets/decisionbench-v1-candidate/calibration','--manifest','evaluation/datasets/decisionbench-v1-candidate/calibration/manifest.json','--output',runtime])
run('calibration-rules-v2',['-m','learning_agent_eval','evaluate-rules','--input',runtime,'--output',rules],(0,2))
common=['--output',out,'--runtime',runtime,'--rules',rules,'--budget-ledger',ledger]
driver='evaluation/scripts/run_e5_experiments.py'
run('e5-v2-prepare',[driver,'prepare',*common])
run('e5-v2-discrimination',[base/'launch-paid.py',driver,'discrimination',*common])
run('e5-v2-repeat',[base/'launch-paid.py',driver,'repeat',*common])
run('e5-v2-summary',[driver,'summarize','--output',out])
