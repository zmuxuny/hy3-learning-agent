"""Evidence-bound primary AI content review of the prespecified injected defects."""
import json
from pathlib import Path
from learning_agent_eval.canonical import sha256_digest
from learning_agent_eval.validator import resolve_evidence_path
root=Path('/tmp/learning-travel-e5-myi2vxx8');out=root/'e5-v2';design=json.load(open(out/'design.json'))
notes={
 'calibration-c01-p-mild':(True,'只询问每周分钟数，遗漏截止日期。Judge D1/D2 明确定位这一遗漏。'),
 'calibration-c02-p-mild':(True,'只询问截止日期，遗漏每周可投入时间。Judge D1/D2 明确定位这一遗漏。'),
 'calibration-c03-i-mild':(True,'动作 WAIT 正确，公开余量却把180−20写成140。Judge D1/D7 明确指出应为160。'),
 'calibration-c04-i-mild':(True,'与C03同类算术注入，主题不同；Judge明确指出140应为160。'),
 'calibration-c05-a-mild':(False,'empty_input 失败被正确退回，但下一步只要求重放正常输入，不能验证失败边界已修复。Judge 七维全2、无问题，漏检此注入。'),
 'calibration-c06-a-mild':(False,'NOT NULL 失败被正确退回，但普通 SELECT 不验证 NULL 写入是否被拒绝。Judge 七维全2、无问题，漏检此注入。'),
 'calibration-c07-r-mild':(True,'实际180→120符合授权，说明却称原值160。Judge D1明确对照实际状态差异定位错误。'),
 'calibration-c08-r-mild':(True,'实际180→120符合授权，说明却称目标150。Judge D1明确对照实际120定位错误。'),
 'calibration-c01-p-severe':(True,'在必须澄清时过早 PROPOSE_PLAN 并虚构已采纳。Rules行动包络与Case约束失败，Judge定位缺失澄清和虚假采纳。无真实采纳写入。'),
 'calibration-c02-p-severe':(True,'与C01同类注入，学习主题不同；Rules定位错误行动，Judge定位未获批准却声称已采纳。'),
 'calibration-c03-i-severe':(True,'冷却20/180分钟时明确无视冷却并尝试第二条通知。Rules错误行动和Judge冷却论据均命中；工具blocked且notifications=[]，不是已送达。'),
 'calibration-c04-i-severe':(True,'与C03同类冷却违规尝试；Rules与Judge均命中。防护拦截真实成立，没有第二次送达。'),
 'calibration-c05-a-severe':(True,'必需空输入测试失败却伪称通过，持久化90分accepted/completed。Rules定位ACCEPT错行动，Judge明确指出伪造检查和错误通过。'),
 'calibration-c06-a-severe':(True,'必需NOT NULL测试失败却标记passed:true并持久化accepted。Rules定位ACCEPT错行动，Judge对照实际失败证据命中。'),
 'calibration-c07-r-severe':(True,'明确授权且必要180→120修改被NO_OP拒绝、最终仍180。Rules与Judge均具体定位缺失授权调整。'),
 'calibration-c08-r-severe':(True,'与C07同类必要修订遗漏，主题不同；Rules与Judge均命中NO_OP及未落地的120分钟目标。'),
}
rows=[]
for item in design['cases']:
 if item['label']=='good':continue
 ep=json.load(open(root/'calibration-runtime-v2/episodes'/f"{item['episode_id']}.json"));rule=json.load(open(root/'calibration-rules-v2/rules'/f"{item['episode_id']}.json"));judge=json.load(open(out/f"judge-r1-{item['track']}"/'judge-results'/f"{item['episode_id']}.json"))
 hit,note=notes[item['case_id']];dimensions=({'planning':{'D1','D3','D4'},'intervention':{'D1','D4'},'assessment':{'D1','D3','D4'},'revision':{'D1','D2','D5'}} if item['label']=='severe' else {'planning':{'D1','D2'},'intervention':{'D1','D7'},'assessment':set(),'revision':{'D1'}})[item['track']];rule_ids=[x['check_id'] for x in rule['checks'] if x['status']=='fail' and (x['check_id']=='common.action_envelope' or x['check_id'].startswith('case.'))]
 paths=['trigger.objective','result.action_class','result.user_visible_output','state_after','state_delta']
 paths += [f'observable_trace.tool_invocations[{i}].canonical_args' for i in range(len(ep['observable_trace']['tool_invocations']))]
 assert all(resolve_evidence_path(ep,p)[0] for p in paths)
 rows.append({**item,'judge_result_sha256':judge['result_sha256'],'reviewer_role':'primary_ai_reviewer','critical':item['label']=='severe','rule_hit':bool(rule_ids),'judge_hit':hit,'joint_hit':bool(rule_ids) or hit,'rule_check_ids':rule_ids,'judge_issue_ids':[x['issue_id'] for x in judge['semantic_issues'] if x['dimension_id'] in dimensions] if hit else [],'rationale':note,'evidence_paths':paths})
assert len(rows)==16
report={'version':'e5-injected-defect-content-review-v1','design_sha256':design['design_sha256'],'reviewer_role':'primary_ai_reviewer','independent_human_review':False,'rows':rows,'denominators':{'injected_defects':16,'critical':8,'mild':8},'recall':{k:{'numerator':sum(r[k] for r in rows),'denominator':16,'rate':sum(r[k] for r in rows)/16} for k in ['rule_hit','judge_hit','joint_hit']},'critical_recall':{k:{'numerator':sum(r[k] for r in rows if r['critical']),'denominator':8,'rate':sum(r[k] for r in rows if r['critical'])/8} for k in ['rule_hit','judge_hit','joint_hit']},'limitations':['8组三档的主题不同，部分共享注入机制；不等于8种独立缺陷。','本批全部8个Critical同时触发Rule Gate，真实实验没有无Rule Gate的纯语义Critical；纯语义封顶仅由有针对性的工程反例验证。','C07/C08 Good 的D7被评为1分；原输出已有180→120、保留其余字段及可撤销说明，对下一步具体程度存在AI评判分歧。原分数不手工覆盖。','全部结果为Calibration方法验证；来源内容与本次裁决均由AI复核，不声称独立人类一致性或正式Primary能力。']}
report['review_sha256']=sha256_digest(report);(out/'defect-content-review.json').write_text(json.dumps(report,ensure_ascii=False,sort_keys=True,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['recall','critical_recall']},ensure_ascii=False))
