console.log(await page.getByText('进入计划',{exact:true}).evaluateAll(es=>es.map(e=>({html:e.outerHTML,parent:e.parentElement.outerHTML.slice(0,500)}))));
await page.getByText('进入计划',{exact:true}).click();
await page.waitForTimeout(1000);
console.log((await page.locator('body').innerText()).slice(-8500));
