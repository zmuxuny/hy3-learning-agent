await page.getByRole('button',{name:'关闭错误提示',exact:true}).click();
await page.getByRole('button',{name:'打开计划',exact:true}).click();await page.waitForTimeout(500);
const target=page.getByRole('button',{name:'提交成果',exact:true}).last();await target.scrollIntoViewIfNeeded();
const box=await target.boundingBox();console.log('LAST ACTION',box,await page.evaluate(({x,y,width,height})=>{const el=document.elementFromPoint(x+width/2,y+height/2);return {tag:el?.tagName,text:el?.textContent?.slice(0,200),class:el?.className}},box));
console.log(await page.evaluate(()=>Array.from(document.querySelectorAll('*')).filter(e=>e.scrollHeight>e.clientHeight+50&&getComputedStyle(e).overflowY.match(/auto|scroll/)).map(e=>({class:e.className,scrollTop:e.scrollTop,max:e.scrollHeight-e.clientHeight}))));
await page.screenshot({path:'/tmp/learning-travel-e5-myi2vxx8/browser-task-controls.png',fullPage:true});
