await page.reload();await page.waitForTimeout(1000);await page.getByRole('button',{name:'打开计划',exact:true}).click();await page.waitForTimeout(1000);
const results=[];
for (const width of [1440,1280,768,375]) {
 await page.setViewportSize({width,height:1000});await page.waitForTimeout(400);
 results.push({width,url:page.url(),...await page.evaluate(()=>({scrollWidth:document.documentElement.scrollWidth,clientWidth:document.documentElement.clientWidth,bodyWidth:document.body.scrollWidth})),text:(await page.locator('body').innerText()).slice(-1600)});
 await page.screenshot({path:`/tmp/learning-travel-e5-myi2vxx8/browser-plan-${width}.png`,fullPage:true});
}
console.log(JSON.stringify(results,null,2));await writeFile('/tmp/learning-travel-e5-myi2vxx8/browser-responsive-checks.json',JSON.stringify(results,null,2));
