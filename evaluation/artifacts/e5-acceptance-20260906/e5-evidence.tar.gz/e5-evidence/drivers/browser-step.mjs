import {chromium} from '/root/workspace/tencent_rhinobird2026/learning_travel/frontend/node_modules/playwright-core/index.mjs';
import {readFile,writeFile} from 'node:fs/promises';
import {format} from 'node:util';
const browser=await chromium.connectOverCDP('http://127.0.0.1:9322');
const context=browser.contexts()[0];
const page=context.pages()[0]||await context.newPage();
const source=await readFile(process.argv[2],'utf8');
const captured=[];const log=console.log;
console.log=(...args)=>{captured.push(format(...args));log(...args);};
try {
 await new (Object.getPrototypeOf(async function(){}).constructor)('page','context','writeFile',source)(page,context,writeFile);
} finally {
 await writeFile(`/tmp/learning-travel-e5-myi2vxx8/browser-observation-${Date.now()}.txt`,captured.join('\n')+'\n');
 await browser.close();
}
