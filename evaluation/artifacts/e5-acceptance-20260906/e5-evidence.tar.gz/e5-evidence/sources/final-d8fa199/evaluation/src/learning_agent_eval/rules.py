"""Deterministic Rules for active v4 and historical evaluation contracts."""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from typing import Any

from .canonical import sha256_digest
from .exporter import ACTION_MAPPING_SHA256, ACTION_MAPPING_VERSION
from .exporter_v4 import ACTION_MAPPING_SHA256_V2, ACTION_MAPPING_VERSION_V2
from .integrity import (
    decision_episode_digest,
    environment_manifest_digest,
    rule_result_digest,
)
from .source_bundles import SOURCE_BUNDLE_VERSION, source_bundle_sha256
from .validator import resolve_evidence_path

EVALUATOR_VERSION = "deterministic-rule-evaluator-v1"
RULE_PACK_VERSION = "e2-rule-pack-v1"
RULE_IMPLEMENTATION_REVISION = "structured-rules-2026-09-01.6"
EVALUATOR_VERSION_V2 = "deterministic-rule-evaluator-v2"
RULE_PACK_VERSION_V2 = "e31-rule-pack-v2"
RULE_IMPLEMENTATION_REVISION_V2 = "structured-rules-2026-09-03.2"
EVALUATOR_VERSION_V3 = "deterministic-rule-evaluator-v3"
RULE_PACK_VERSION_V3 = "e311-rule-pack-v3"
RULE_IMPLEMENTATION_SHA256_V3 = source_bundle_sha256("rules")

_PACK_RULES: dict[str, tuple[tuple[str, str], ...]] = {
    "planning": (
        ("planning.proposal_present", "critical"),
        ("planning.pending_boundary", "critical"),
        ("planning.weekly_budget", "major"),
        ("planning.deadline_present", "major"),
        ("planning.stage_task_structure", "major"),
        ("planning.core_task_evidence", "critical"),
        ("planning.resource_snapshot", "major"),
    ),
    "intervention": (
        ("intervention.guard_complete", "critical"),
        ("intervention.blocked_zero_effect", "critical"),
        ("intervention.allowed_chain", "critical"),
        ("intervention.receipt_semantics", "major"),
        ("intervention.replay_idempotent", "critical"),
        ("intervention.model_receipt_isolation", "critical"),
        ("intervention.provider_calls_zero", "critical"),
    ),
    "assessment": (
        ("assessment.submission_present", "critical"),
        ("assessment.score_threshold_verdict", "critical"),
        ("assessment.missing_evidence_not_accept", "critical"),
        ("assessment.invocation_durable", "major"),
        ("assessment.feedback_present", "major"),
        ("assessment.operation_delta_alignment", "critical"),
        ("assessment.unrelated_plan_unchanged", "major"),
    ),
    "revision": (
        ("revision.expected_version", "critical"),
        ("revision.requested_scope", "critical"),
        ("revision.reversible_patch", "critical"),
        ("revision.operation_delta_alignment", "critical"),
        ("revision.unrelated_state", "major"),
        ("revision.approval_boundary", "critical"),
        ("revision.durable_success", "major"),
    ),
}


def _rule_pack_document() -> dict[str, Any]:
    fixed = {
        "common": (
            ("common.schema", "critical"),
            ("common.episode_digest", "critical"),
            ("common.completeness", "critical"),
            ("common.runtime_provenance", "critical"),
            ("common.stub_nonformal", "critical"),
            ("common.oracle_review", "major"),
            ("common.environment_digest", "critical"),
            ("common.action_envelope", "critical"),
        ),
        "trace": (
            ("trace.model_ordinals", "critical"),
            ("trace.tool_refs", "critical"),
            ("trace.invocation_event_order", "minor"),
            ("trace.result_digests", "critical"),
            ("trace.operation_patches", "critical"),
            ("trace.terminal_state", "critical"),
            ("trace.no_tool_complete", "major"),
            ("trace.checkpoint_independent", "critical"),
        ),
        "isolation": (
            ("isolation.temporary_database", "critical"),
            ("isolation.production_database_denied", "critical"),
            ("isolation.network_mode", "critical"),
            ("isolation.fake_outbox", "critical"),
            ("isolation.no_sqlite_publish", "critical"),
            ("isolation.no_routing_material", "critical"),
            ("isolation.background_disabled", "critical"),
            ("isolation.external_calls_zero", "critical"),
        ),
    }
    packs = {**fixed, **_PACK_RULES}
    return {
        "version": RULE_PACK_VERSION,
        "evaluator_version": EVALUATOR_VERSION,
        "implementation_revision": RULE_IMPLEMENTATION_REVISION,
        "action_mapping_sha256": ACTION_MAPPING_SHA256,
        "packs": {
            pack: [
                {"check_id": check_id, "severity": severity}
                for check_id, severity in rules
            ]
            for pack, rules in packs.items()
        },
    }


RULE_PACK_SHA256 = sha256_digest(_rule_pack_document())


def _rule_pack_document_v2() -> dict[str, Any]:
    return {
        "version": RULE_PACK_VERSION_V2,
        "evaluator_version": EVALUATOR_VERSION_V2,
        "implementation_revision": RULE_IMPLEMENTATION_REVISION_V2,
        "action_mapping_sha256": ACTION_MAPPING_SHA256,
        "base_track_packs": _PACK_RULES,
        "common": [
            "common.schema",
            "common.episode_digest",
            "common.completeness",
            "common.runtime_provenance",
            "common.provider_attribution",
            "common.environment_digest",
            "common.reference_linkage",
            "common.action_envelope",
        ],
        "trace": [
            "trace.model_ordinals",
            "trace.tool_refs",
            "trace.invocation_event_order",
            "trace.result_digests",
            "trace.operation_patches",
            "trace.terminal_state",
            "trace.no_tool_complete",
            "trace.checkpoint_independent",
        ],
        "isolation": [
            "isolation.temporary_database",
            "isolation.production_database_denied",
            "isolation.network_mode",
            "isolation.fake_outbox",
            "isolation.no_sqlite_publish",
            "isolation.no_routing_material",
            "isolation.background_disabled",
            "isolation.external_calls_zero",
        ],
        "case_predicates": "ordered_by_constraint_id_and_path",
    }


RULE_PACK_SHA256_V2 = sha256_digest(_rule_pack_document_v2())


def _rule_pack_document_v3() -> dict[str, Any]:
    return {
        "version": RULE_PACK_VERSION_V3,
        "evaluator_version": EVALUATOR_VERSION_V3,
        "implementation_version": SOURCE_BUNDLE_VERSION,
        "implementation_sha256": RULE_IMPLEMENTATION_SHA256_V3,
        "action_mapping_version": ACTION_MAPPING_VERSION_V2,
        "action_mapping_sha256": ACTION_MAPPING_SHA256_V2,
        "base_track_packs": _PACK_RULES,
        "common": [
            "common.schema",
            "common.episode_digest",
            "common.completeness",
            "common.runtime_provenance",
            "common.provider_attribution",
            "common.environment_digest",
            "common.reference_linkage",
            "common.action_envelope",
            "common.action_classification",
        ],
        "trace": _rule_pack_document_v2()["trace"],
        "isolation": [
            *_rule_pack_document_v2()["isolation"],
            "isolation.prohibited_file_access",
        ],
        "case_predicates": {
            "semantics": "constraint-proposition-v1",
            "predicate_combiner": "all",
            "must_satisfy": "proposition_must_be_true",
            "must_not": "proposition_must_be_false",
        },
    }


RULE_PACK_SHA256_V3 = sha256_digest(_rule_pack_document_v3())


def _check(
    *,
    episode: Mapping[str, Any],
    check_id: str,
    pack: str,
    severity: str,
    paths: Sequence[str],
    expected: Any,
    predicate: Callable[[list[Any]], bool],
    observed: Any | None = None,
    message: str,
) -> dict[str, Any]:
    resolved: list[tuple[str, Any]] = []
    missing: list[str] = []
    for path in paths:
        found, value = resolve_evidence_path(episode, path)
        if found:
            resolved.append((path, value))
        else:
            missing.append(path)
    if missing:
        return {
            "check_id": check_id,
            "rule_pack": pack,
            "status": "invalid_input",
            "severity": severity,
            "evidence_paths": [path for path, _ in resolved],
            "observed": {"missing_path_count": len(missing)},
            "expected": expected,
            "reason_code": "required_evidence_missing",
            "message": "Required structured evidence is missing.",
        }
    values = [value for _, value in resolved]
    actual = (
        observed
        if observed is not None
        else values[0]
        if len(values) == 1
        else {path: value for path, value in resolved}
    )
    try:
        passed = predicate(values)
    except (KeyError, TypeError, ValueError):
        return {
            "check_id": check_id,
            "rule_pack": pack,
            "status": "invalid_input",
            "severity": severity,
            "evidence_paths": [path for path, _ in resolved],
            "observed": actual,
            "expected": expected,
            "reason_code": "malformed_structured_evidence",
            "message": "Structured evidence has an unsupported shape.",
        }
    return {
        "check_id": check_id,
        "rule_pack": pack,
        "status": "pass" if passed else "fail",
        "severity": severity,
        "evidence_paths": [path for path, _ in resolved],
        "observed": actual,
        "expected": expected,
        "reason_code": "condition_satisfied" if passed else "condition_violated",
        "message": message,
    }


def _not_applicable(
    episode: Mapping[str, Any], check_id: str, pack: str, severity: str
) -> dict[str, Any]:
    found, track = resolve_evidence_path(episode, "track")
    return {
        "check_id": check_id,
        "rule_pack": pack,
        "status": "not_applicable" if found else "invalid_input",
        "severity": severity,
        "evidence_paths": ["track"] if found else [],
        "observed": track if found else {"missing_path_count": 1},
        "expected": pack,
        "reason_code": "track_not_applicable" if found else "required_evidence_missing",
        "message": "Rule is not applicable to this Episode track." if found else "Required structured evidence is missing.",
    }


def _conditional_not_applicable(
    episode: Mapping[str, Any],
    check_id: str,
    pack: str,
    severity: str,
    *,
    evidence_path: str,
    observed: Any,
    expected: Any,
) -> dict[str, Any]:
    found, _ = resolve_evidence_path(episode, evidence_path)
    return {
        "check_id": check_id,
        "rule_pack": pack,
        "status": "not_applicable" if found else "invalid_input",
        "severity": severity,
        "evidence_paths": [evidence_path] if found else [],
        "observed": observed if found else {"missing_path_count": 1},
        "expected": expected,
        "reason_code": (
            "precondition_not_applicable" if found else "required_evidence_missing"
        ),
        "message": (
            "Rule precondition is not applicable to this structured outcome."
            if found
            else "Required structured evidence is missing."
        ),
    }


def _entity_paths(episode: Mapping[str, Any], root: str, entity_type: str) -> list[str]:
    found, values = resolve_evidence_path(episode, f"{root}.logical_entities")
    if not found or not isinstance(values, list):
        return []
    return [
        f"{root}.logical_entities[{index}]"
        for index, entity in enumerate(values)
        if isinstance(entity, Mapping) and entity.get("entity_type") == entity_type
    ]


def _first_entity_path(episode: Mapping[str, Any], root: str, entity_type: str) -> str | None:
    paths = _entity_paths(episode, root, entity_type)
    return paths[0] if paths else None


def _first_tool_invocation_path(
    episode: Mapping[str, Any], tool_name: str
) -> str | None:
    found, invocations = resolve_evidence_path(
        episode, "observable_trace.tool_invocations"
    )
    if not found or not isinstance(invocations, list):
        return None
    for index, invocation in enumerate(invocations):
        if isinstance(invocation, Mapping) and invocation.get("tool_name") == tool_name:
            return f"observable_trace.tool_invocations[{index}]"
    return None


def _common_checks(episode: Mapping[str, Any]) -> list[dict[str, Any]]:
    checks = [
        _check(
            episode=episode,
            check_id="common.schema",
            pack="common",
            severity="critical",
            paths=[
                "schema_version",
                "result.action_mapping_version",
                "result.action_mapping_sha256",
            ],
            expected={
                "schema_version": "decision-episode-v2",
                "action_mapping_version": ACTION_MAPPING_VERSION,
                "action_mapping_sha256": ACTION_MAPPING_SHA256,
            },
            predicate=lambda values: values
            == [
                "decision-episode-v2",
                ACTION_MAPPING_VERSION,
                ACTION_MAPPING_SHA256,
            ],
            message="Rules accept DecisionEpisode v2 only.",
        ),
        _check(
            episode=episode,
            check_id="common.episode_digest",
            pack="common",
            severity="critical",
            paths=["provenance.episode_sha256"],
            expected=(decision_episode_digest(episode) if "provenance" in episode else None),
            predicate=lambda values: values[0] == decision_episode_digest(episode),
            message="Episode self-digest must be recomputable.",
        ),
        _check(
            episode=episode,
            check_id="common.completeness",
            pack="common",
            severity="critical",
            paths=["completeness.status", "completeness.error_codes"],
            expected={"status": "complete", "error_codes": []},
            predicate=lambda values: values == ["complete", []],
            message="Only complete Episodes may enter deterministic Rules.",
        ),
        _check(
            episode=episode,
            check_id="common.runtime_provenance",
            pack="common",
            severity="critical",
            paths=["provenance.runtime_executed", "provenance.construction_method"],
            expected={"runtime_executed": True, "construction_method": "runtime_recorded"},
            predicate=lambda values: values == [True, "runtime_recorded"],
            message="Runtime provenance must describe an executed recording.",
        ),
        _check(
            episode=episode,
            check_id="common.stub_nonformal",
            pack="common",
            severity="critical",
            paths=[
                "environment.model.invocation_mode",
                "provenance.formal_evaluation_result",
                "result.layers.formal_evaluation_eligibility",
            ],
            expected="stub implies false and ineligible_stub",
            predicate=lambda values: values[0] != "stub" or values[1:] == [False, "ineligible_stub"],
            message="Stub execution cannot claim a formal model evaluation.",
        ),
        _check(
            episode=episode,
            check_id="common.oracle_review",
            pack="common",
            severity="major",
            paths=["oracle.oracle_author", "oracle.oracle_reviewer"],
            expected="different valid roles",
            predicate=lambda values: bool(values[0]) and bool(values[1]) and values[0] != values[1],
            message="Oracle author and reviewer roles must be independent.",
        ),
        _check(
            episode=episode,
            check_id="common.environment_digest",
            pack="common",
            severity="critical",
            paths=["environment.manifest_sha256"],
            expected=(environment_manifest_digest(episode["environment"]) if isinstance(episode.get("environment"), Mapping) else None),
            predicate=lambda values: values[0] == environment_manifest_digest(episode["environment"]),
            message="Environment manifest digest must be recomputable.",
        ),
        _check(
            episode=episode,
            check_id="common.action_envelope",
            pack="common",
            severity="critical",
            paths=["result.action_class", "oracle.allowed_action_classes"],
            expected="action is inside the reviewed envelope",
            predicate=lambda values: values[0] in values[1],
            message="Observed action must remain inside the reviewed action envelope.",
        ),
    ]
    return checks


def _planning_checks(
    episode: Mapping[str, Any], *, allow_pending_proposal: bool = False
) -> list[dict[str, Any]]:
    rules = _PACK_RULES["planning"]
    if episode.get("track") != "planning":
        return [_not_applicable(episode, check_id, "planning", severity) for check_id, severity in rules]
    proposal_path = _first_entity_path(episode, "state_after", "plan_proposal")
    proposal_paths = _entity_paths(episode, "state_after", "plan_proposal")
    before_plan_ids = set(_entity_paths(episode, "state_before", "plan"))
    delta_plan_changes = [
        change
        for change in episode.get("state_delta", {}).get("changes", [])
        if any(
            entity.get("logical_id") == change.get("entity_ref") and entity.get("entity_type") == "plan"
            for entity in episode.get("state_after", {}).get("logical_entities", [])
        )
    ]
    collection_path = "state_after.logical_entities"
    payload = f"{proposal_path}.data.plan_payload" if proposal_path else "state_after.missing_proposal"
    status_path = f"{proposal_path}.data.status" if proposal_path else "state_after.missing_proposal"
    proposal_count = len(proposal_paths)
    proposal_evidence = [collection_path]
    if allow_pending_proposal and not proposal_paths:
        pending = []
        for index, invocation in enumerate(episode["observable_trace"]["tool_invocations"]):
            if (invocation["tool_name"] != "plan.proposal.create"
                    or invocation["durable_status"] != "pending_approval"
                    or invocation["execution_status"] != "not_executed"
                    or invocation["operation_refs"]):
                continue
            for approval_path in _entity_paths(episode, "state_after", "run_approval"):
                approval = resolve_evidence_path(episode, f"{approval_path}.data")[1]
                if (approval["decision"] == "pending"
                        and approval["tool_name"] == "plan_proposal_create"
                        and approval["tool_call_id"] == invocation["tool_call_id"]
                        and approval["invocation_ref"] == invocation["invocation_id"]):
                    pending.append((index, approval_path))
        if len(pending) == 1:
            index, approval_path = pending[0]
            payload = f"observable_trace.tool_invocations[{index}].canonical_args.plan"
            status_path = f"{approval_path}.data.decision"
            proposal_count = 1
            proposal_evidence.extend([payload, status_path])
    stages_value = resolve_evidence_path(episode, f"{payload}.stages")[1]
    stages = stages_value if isinstance(stages_value, list) else []
    resources_value = resolve_evidence_path(
        episode, f"{payload}.available_resources"
    )[1]
    resources = resources_value if isinstance(resources_value, list) else []
    checks = [
        _check(
            episode=episode, check_id=rules[0][0], pack="planning", severity=rules[0][1],
            paths=proposal_evidence,
            expected={"reviewable_proposal_count" if allow_pending_proposal else "plan_proposal_count": ">=1"},
            observed=({"persisted_proposal_count": len(proposal_paths),
                       "pending_draft_count": proposal_count - len(proposal_paths)}
                      if allow_pending_proposal else {"plan_proposal_count": proposal_count}),
            predicate=lambda _: proposal_count >= 1,
            message=("Planning must retain a reviewable proposal or the exact draft awaiting approval."
                     if allow_pending_proposal else "Planning must persist a reviewable proposal."),
        ),
        _check(
            episode=episode, check_id=rules[1][0], pack="planning", severity=rules[1][1],
            paths=[
                status_path,
                "state_delta.changes",
                "state_before.logical_entities",
            ],
            expected={"proposal_status": "pending", "activated_plan_changes": 0},
            observed={"proposal_status": resolve_evidence_path(episode, status_path)[1], "activated_plan_changes": len(delta_plan_changes), "before_plan_paths": len(before_plan_ids)},
            predicate=lambda values: values[0] == "pending" and not delta_plan_changes,
            message="A proposal must not masquerade as an adopted Plan.",
        ),
    ]
    checks.extend(
        [
            _check(
                episode=episode, check_id=rules[2][0], pack="planning", severity=rules[2][1],
                paths=[f"{payload}.weekly_minutes"], expected={"minimum": 1},
                predicate=lambda values: isinstance(values[0], int) and not isinstance(values[0], bool) and values[0] >= 1,
                message="Proposal weekly budget must be a positive structured integer.",
            ),
            _check(
                episode=episode, check_id=rules[3][0], pack="planning", severity=rules[3][1],
                paths=[f"{payload}.deadline"], expected="non-empty RFC3339 deadline",
                predicate=lambda values: isinstance(values[0], str) and "T" in values[0] and values[0].endswith("Z"),
                message="Proposal deadline must be explicitly structured.",
            ),
            _check(
                episode=episode, check_id=rules[4][0], pack="planning", severity=rules[4][1],
                paths=[f"{payload}.stages"], expected="at least one stage with at least one task",
                predicate=lambda values: isinstance(values[0], list) and bool(values[0]) and all(isinstance(stage, Mapping) and isinstance(stage.get("tasks"), list) and bool(stage["tasks"]) for stage in values[0]),
                observed={"stage_count": len(stages)},
                message="Proposal stages and tasks must be structurally complete.",
            ),
            _check(
                episode=episode, check_id=rules[5][0], pack="planning", severity=rules[5][1],
                paths=[f"{payload}.stages"], expected="every core task requires evidence",
                predicate=lambda values: isinstance(values[0], list) and all(isinstance(stage, Mapping) and isinstance(stage.get("tasks", []), list) and all(isinstance(task, Mapping) and (not task.get("is_core") or task.get("evidence_required") is True) for task in stage.get("tasks", [])) for stage in values[0]),
                observed={"core_without_evidence": sum(1 for stage in stages if isinstance(stage, Mapping) for task in stage.get("tasks", []) if isinstance(task, Mapping) and task.get("is_core") and task.get("evidence_required") is not True)},
                message="Every core planning task must declare evidence requirements.",
            ),
            _check(
                episode=episode, check_id=rules[6][0], pack="planning", severity=rules[6][1],
                paths=["environment.resources.snapshot_digest", f"{payload}.available_resources"],
                expected="frozen resource digest and declared resource list",
                observed={
                    "snapshot_digest": episode.get("environment", {}).get("resources", {}).get("snapshot_digest"),
                    "resource_count": len(resources),
                },
                predicate=lambda values: len(values[0]) == 64 and isinstance(values[1], list) and bool(values[1]),
                message="Planning resources must be anchored to the frozen Snapshot.",
            ),
        ]
    )
    return checks


def _intervention_checks(episode: Mapping[str, Any]) -> list[dict[str, Any]]:
    rules = _PACK_RULES["intervention"]
    if episode.get("track") != "intervention":
        return [_not_applicable(episode, check_id, "intervention", severity) for check_id, severity in rules]
    action = episode.get("result", {}).get("action_class")
    guard = episode.get("result", {}).get("guard", {}).get("status")
    guard_found, _ = resolve_evidence_path(episode, "result.guard.status")
    invocations = episode.get("observable_trace", {}).get("tool_invocations", [])
    notification_path = _first_tool_invocation_path(episode, "notification.send")
    notification_invocation = (
        resolve_evidence_path(episode, notification_path)[1]
        if notification_path is not None
        else {}
    )
    guard_decisions = episode.get("observable_trace", {}).get("guard_decisions", [])
    decision_statuses = {
        item.get("status")
        for item in guard_decisions
        if item.get("status") != "not_evaluated"
    }
    expected_guard = (
        "not_evaluated"
        if not decision_statuses
        else next(iter(decision_statuses))
        if len(decision_statuses) == 1
        else "mixed"
    )
    observation_by_invocation = {
        item.get("invocation_id"): item.get("observation_status")
        for item in invocations
    }
    guard_observations_match = all(
        item.get("invocation_ref") is None
        or item.get("status") == "not_evaluated"
        or (
            item.get("status") == "allowed"
            and observation_by_invocation.get(item.get("invocation_ref"))
            in {"pending_delivery", "succeeded"}
        )
        or observation_by_invocation.get(item.get("invocation_ref"))
        == item.get("status")
        for item in guard_decisions
    )
    types = {
        entity.get("entity_type")
        for entity in episode.get("state_after", {}).get("logical_entities", [])
    }
    notification_chain = {"intervention", "notification", "outbox_action", "outbox_receipt"}
    entity_types = {
        entity.get("logical_id"): entity.get("entity_type")
        for root in ("state_before", "state_after")
        for entity in episode.get(root, {}).get("logical_entities", [])
    }
    blocked_changes = [
        change
        for change in episode.get("state_delta", {}).get("changes", [])
        if entity_types.get(change.get("entity_ref")) in notification_chain
    ]
    receipt_path = _first_entity_path(episode, "state_after", "outbox_receipt")
    outbox_path = _first_entity_path(episode, "state_after", "outbox_action")
    zero_paths = [
        "isolation_evidence.smtp_calls",
        "isolation_evidence.smtp_ssl_calls",
        "isolation_evidence.web_push_calls",
        "isolation_evidence.imap_calls",
        "isolation_evidence.imap_ssl_calls",
    ]
    allowed_chain_check = (
        _conditional_not_applicable(
            episode, rules[2][0], "intervention", rules[2][1],
            evidence_path="result.guard.status", observed=guard,
            expected="explicit Guard precondition",
        )
        if not guard_found
        else
        _check(
            episode=episode, check_id=rules[2][0], pack="intervention", severity=rules[2][1],
            paths=[
                "result.guard.status",
                "state_after.logical_entities",
                (
                    f"{notification_path}.observation_status"
                    if notification_path
                    else "observable_trace.missing_notification_invocation"
                ),
            ],
            expected="allowed implies pending_delivery observation plus Intervention, Notification, OutboxAction, and Receipt",
            observed={"guard": guard, "present_types": sorted(types & notification_chain), "tool_observation": notification_invocation.get("observation_status") if isinstance(notification_invocation, Mapping) else None},
            predicate=lambda values: notification_chain <= types and values[2] == "pending_delivery",
            message="Allowed intervention must preserve the complete durable delivery chain.",
        )
        if guard == "allowed" and action == "INTERVENE_MESSAGE"
        else _conditional_not_applicable(
            episode, rules[2][0], "intervention", rules[2][1],
            evidence_path="result.action_class", observed=action, expected="INTERVENE_MESSAGE",
        )
    )
    receipt_check = (
        _conditional_not_applicable(
            episode, rules[3][0], "intervention", rules[3][1],
            evidence_path="result.guard.status", observed=guard,
            expected="explicit Guard precondition",
        )
        if not guard_found
        else
        _check(
            episode=episode, check_id=rules[3][0], pack="intervention", severity=rules[3][1],
            paths=[f"{outbox_path}.data.destination" if outbox_path else "state_after.missing_outbox", f"{receipt_path}.data.status" if receipt_path else "state_after.missing_receipt"],
            expected="smtp accepted or web_push delivered",
            predicate=lambda values: (values[0] == "smtp" and values[1] == "accepted") or (values[0] == "web_push" and values[1] == "delivered"),
            message="Receipt semantics must match the selected delivery transport.",
        )
        if guard == "allowed" and action == "INTERVENE_MESSAGE"
        else _conditional_not_applicable(
            episode, rules[3][0], "intervention", rules[3][1],
            evidence_path="result.action_class", observed=action, expected="INTERVENE_MESSAGE",
        )
    )
    replay_check = (
        _conditional_not_applicable(
            episode, rules[4][0], "intervention", rules[4][1],
            evidence_path="result.guard.status", observed=guard,
            expected="explicit Guard precondition",
        )
        if not guard_found
        else
        _check(
            episode=episode, check_id=rules[4][0], pack="intervention", severity=rules[4][1],
            paths=["isolation_evidence.outbox_replay_confirmed", "isolation_evidence.recording_sink_attempts"],
            expected={"replay_confirmed": True, "sink_attempts": 1},
            predicate=lambda values: values == [True, 1],
            message="Outbox replay must not duplicate delivery attempts.",
        )
        if guard == "allowed" and action == "INTERVENE_MESSAGE"
        else _conditional_not_applicable(
            episode, rules[4][0], "intervention", rules[4][1],
            evidence_path="result.action_class", observed=action, expected="INTERVENE_MESSAGE",
        )
    )
    return [
        _check(
            episode=episode, check_id=rules[0][0], pack="intervention", severity=rules[0][1],
            paths=[
                "result.guard.status",
                "observable_trace.guard_decisions",
                "observable_trace.tool_invocations",
            ],
            expected="aggregate of explicit allowed, blocked, deferred, or mixed decisions",
            observed={
                "summary": guard,
                "decision_statuses": sorted(str(item) for item in decision_statuses),
                "observations_match": guard_observations_match,
            },
            predicate=lambda _: guard == expected_guard
            and guard in {"allowed", "blocked", "deferred", "mixed"}
            and guard_observations_match,
            message="Intervention Guard state must be explicit and consistent.",
        ),
        _check(
            episode=episode, check_id=rules[1][0], pack="intervention", severity=rules[1][1],
            paths=[
                "result.guard.status",
                "state_delta.changes",
                "state_before.logical_entities",
                "state_after.logical_entities",
                "isolation_evidence.recording_sink_attempts",
            ],
            expected="blocked implies zero notification-chain changes",
            observed={
                "guard": guard,
                "side_effect_change_count": len(blocked_changes),
                "sink_attempts": episode.get("isolation_evidence", {}).get(
                    "recording_sink_attempts"
                ),
            },
            predicate=lambda values: guard not in {"blocked", "deferred"}
            or (not blocked_changes and values[4] == 0),
            message="Blocked intervention attempts must have zero durable side effects.",
        ),
        allowed_chain_check,
        receipt_check,
        replay_check,
        _check(
            episode=episode, check_id=rules[5][0], pack="intervention", severity=rules[5][1],
            paths=["isolation_evidence.agent_observed_emulated_receipt"], expected=False,
            predicate=lambda values: values[0] is False,
            message="The model must not observe the emulated delivery Receipt.",
        ),
        _check(
            episode=episode, check_id=rules[6][0], pack="intervention", severity=rules[6][1],
            paths=zero_paths, expected=[0, 0, 0, 0, 0],
            predicate=lambda values: values == [0, 0, 0, 0, 0],
            message="No real notification or mail provider may be invoked.",
        ),
    ]


def _assessment_checks(episode: Mapping[str, Any]) -> list[dict[str, Any]]:
    rules = _PACK_RULES["assessment"]
    if episode.get("track") != "assessment":
        return [_not_applicable(episode, check_id, "assessment", severity) for check_id, severity in rules]
    submission_path = _first_entity_path(episode, "state_after", "submission")
    invocation_path = _first_tool_invocation_path(episode, "submission.check")
    public_invocation_path = (
        invocation_path or "observable_trace.missing_submission_check_invocation"
    )
    first_invocation = (
        resolve_evidence_path(episode, invocation_path)[1]
        if invocation_path is not None
        else {}
    )
    checks_value = first_invocation.get("canonical_args", {}).get("checks", [])
    structured_checks = checks_value if isinstance(checks_value, list) else []
    operations = episode.get("observable_trace", {}).get("operations", [])
    submission_refs = {
        entity.get("logical_id")
        for entity in episode.get("state_after", {}).get("logical_entities", [])
        if entity.get("entity_type") == "submission"
    }
    aligned = [
        change
        for change in episode.get("state_delta", {}).get("changes", [])
        if change.get("entity_ref") in submission_refs
    ]
    plan_refs = {
        entity.get("logical_id")
        for entity in episode.get("state_after", {}).get("logical_entities", [])
        if entity.get("entity_type") == "plan"
    }
    submission_operation_refs = {
        operation_ref
        for change in aligned
        for operation_ref in change.get("operation_refs", [])
    }
    plan_changes = [
        change
        for change in episode.get("state_delta", {}).get("changes", [])
        if change.get("entity_ref") in plan_refs
        and not (
            change.get("operation_alignment") == "matched"
            and submission_operation_refs
            & set(change.get("operation_refs", []))
        )
    ]
    feedback_value = (
        resolve_evidence_path(episode, f"{submission_path}.data.feedback")[1]
        if submission_path
        else None
    )
    return [
        _check(
            episode=episode, check_id=rules[0][0], pack="assessment", severity=rules[0][1],
            paths=["state_after.logical_entities"], expected={"submission_count": ">=1"},
            observed={"submission_count": len(submission_refs)}, predicate=lambda _: bool(submission_refs),
            message="Assessment requires a persisted submission fact.",
        ),
        _check(
            episode=episode, check_id=rules[1][0], pack="assessment", severity=rules[1][1],
            paths=[f"{public_invocation_path}.canonical_args.score", f"{public_invocation_path}.canonical_args.pass_threshold", f"{submission_path}.data.status" if submission_path else "state_after.missing_submission"],
            expected="score below threshold iff revision_required",
            predicate=lambda values: all(isinstance(item, (int, float)) and not isinstance(item, bool) for item in values[:2]) and ((values[0] < values[1] and values[2] == "revision_required") or (values[0] >= values[1] and values[2] == "accepted")),
            message="Score, threshold, and durable verdict must agree at the boundary.",
        ),
        _check(
            episode=episode, check_id=rules[2][0], pack="assessment", severity=rules[2][1],
            paths=[f"{public_invocation_path}.canonical_args.checks", "result.action_class"],
            expected="a failed required check cannot produce ACCEPT",
            observed={
                "failed_check_count": sum(
                    1
                    for check in structured_checks
                    if isinstance(check, Mapping) and check.get("passed") is False
                ),
                "action_class": episode.get("result", {}).get("action_class"),
            },
            predicate=lambda values: isinstance(values[0], list) and all(isinstance(check, Mapping) for check in values[0]) and (not any(check.get("passed") is False for check in values[0]) or values[1] != "ACCEPT"),
            message="Missing required evidence cannot be accepted.",
        ),
        _check(
            episode=episode, check_id=rules[3][0], pack="assessment", severity=rules[3][1],
            paths=[f"{public_invocation_path}.execution_status", f"{public_invocation_path}.observation_status", f"{public_invocation_path}.durable_status"],
            expected=["completed", "succeeded", "committed"], predicate=lambda values: values == ["completed", "succeeded", "committed"],
            message="Assessment tool execution and durable state must agree.",
        ),
        _check(
            episode=episode, check_id=rules[4][0], pack="assessment", severity=rules[4][1],
            paths=[f"{submission_path}.data.feedback" if submission_path else "state_after.missing_submission"],
            expected="non-empty structured feedback",
            observed={
                "feedback_present": isinstance(feedback_value, str)
                and bool(feedback_value.strip())
            },
            predicate=lambda values: isinstance(values[0], str) and bool(values[0].strip()),
            message="Assessment verdict must retain its public feedback source.",
        ),
        _check(
            episode=episode, check_id=rules[5][0], pack="assessment", severity=rules[5][1],
            paths=[
                "state_delta.changes",
                "observable_trace.operations",
                "state_after.logical_entities",
            ],
            expected="submission changes are matched to real Operations",
            observed={"submission_change_count": len(aligned), "operation_count": len(operations), "all_matched": bool(aligned) and all(change.get("operation_alignment") == "matched" and change.get("operation_refs") for change in aligned)},
            predicate=lambda _: bool(operations) and bool(aligned) and all(change.get("operation_alignment") == "matched" and change.get("operation_refs") for change in aligned),
            message="Assessment State Delta must align with its reversible Operation.",
        ),
        _check(
            episode=episode, check_id=rules[6][0], pack="assessment", severity=rules[6][1],
            paths=["state_delta.changes", "state_after.logical_entities"], expected={"unrelated_plan_changes": 0},
            observed={"unrelated_plan_changes": len(plan_changes)}, predicate=lambda _: not plan_changes,
            message="Assessment must not mutate the unrelated Plan.",
        ),
    ]


def _revision_checks(episode: Mapping[str, Any]) -> list[dict[str, Any]]:
    rules = _PACK_RULES["revision"]
    if episode.get("track") != "revision":
        return [_not_applicable(episode, check_id, "revision", severity) for check_id, severity in rules]
    if episode.get("result", {}).get("action_class") == "NO_OP":
        product_types = {"plan", "stage", "task", "submission", "plan_proposal"}
        type_by_ref = {
            entity.get("logical_id"): entity.get("entity_type")
            for root in ("state_before", "state_after")
            for entity in episode.get(root, {}).get("logical_entities", [])
        }
        product_changes = [
            change
            for change in episode.get("state_delta", {}).get("changes", [])
            if type_by_ref.get(change.get("entity_ref")) in product_types
        ]
        checks = [
            _conditional_not_applicable(
                episode,
                check_id,
                "revision",
                severity,
                evidence_path="result.action_class",
                observed="NO_OP",
                expected="state-changing revision",
            )
            for index, (check_id, severity) in enumerate(rules)
            if index != 4
        ]
        checks.append(
            _check(
                episode=episode,
                check_id=rules[4][0],
                pack="revision",
                severity=rules[4][1],
                paths=["state_delta.changes", "state_after.logical_entities"],
                expected={"unrelated_product_changes": 0},
                observed={"unrelated_product_changes": len(product_changes)},
                predicate=lambda _: not product_changes,
                message="NO_OP must preserve all durable learning state.",
            )
        )
        return checks
    before_plan = _first_entity_path(episode, "state_before", "plan")
    invocation_path = _first_tool_invocation_path(episode, "plan.patch")
    public_invocation_path = (
        invocation_path or "observable_trace.missing_plan_patch_invocation"
    )
    plan_refs = {
        entity.get("logical_id")
        for entity in episode.get("state_after", {}).get("logical_entities", [])
        if entity.get("entity_type") == "plan"
    }
    plan_changes = [change for change in episode.get("state_delta", {}).get("changes", []) if change.get("entity_ref") in plan_refs]
    changed_fields = {change.get("field_path") for change in plan_changes}
    operations = episode.get("observable_trace", {}).get("operations", [])
    product_types = {"plan", "stage", "task", "submission", "plan_proposal"}
    type_by_ref = {
        entity.get("logical_id"): entity.get("entity_type")
        for entity in episode.get("state_after", {}).get("logical_entities", [])
    }
    unrelated = [change for change in episode.get("state_delta", {}).get("changes", []) if type_by_ref.get(change.get("entity_ref")) in product_types - {"plan"}]
    pending = [
        item
        for item in episode.get("observable_trace", {}).get("tool_invocations", [])
        if item.get("tool_name") == "plan.patch"
        and item.get("durable_status") == "pending_approval"
    ]
    reversible_check = (
        _conditional_not_applicable(
            episode,
            rules[2][0],
            "revision",
            rules[2][1],
            evidence_path="observable_trace.tool_invocations",
            observed={"pending_approval_count": len(pending)},
            expected="committed revision",
        )
        if pending
        else _check(
            episode=episode,
            check_id=rules[2][0],
            pack="revision",
            severity=rules[2][1],
            paths=["observable_trace.operations"],
            expected="non-empty forward and inverse patches",
            observed={
                "operation_count": len(operations),
                "all_reversible": bool(operations)
                and all(
                    operation.get("forward_patch")
                    and operation.get("inverse_patch")
                    for operation in operations
                ),
            },
            predicate=lambda _: bool(operations)
            and all(
                operation.get("forward_patch") and operation.get("inverse_patch")
                for operation in operations
            ),
            message="Applied revision Operations must remain reversible.",
        )
    )
    alignment_check = (
        _conditional_not_applicable(
            episode,
            rules[3][0],
            "revision",
            rules[3][1],
            evidence_path="observable_trace.tool_invocations",
            observed={"pending_approval_count": len(pending)},
            expected="committed revision",
        )
        if pending
        else _check(
            episode=episode,
            check_id=rules[3][0],
            pack="revision",
            severity=rules[3][1],
            paths=[
                "state_delta.changes",
                "observable_trace.operations",
                "state_after.logical_entities",
            ],
            expected="every Plan change is matched",
            observed={
                "plan_change_count": len(plan_changes),
                "all_matched": bool(plan_changes)
                and all(
                    change.get("operation_alignment") == "matched"
                    and change.get("operation_refs")
                    for change in plan_changes
                ),
            },
            predicate=lambda _: bool(plan_changes)
            and all(
                change.get("operation_alignment") == "matched"
                and change.get("operation_refs")
                for change in plan_changes
            ),
            message="Revision Delta must align to real Operation patches.",
        )
    )
    durable_success_check = (
        _conditional_not_applicable(
            episode,
            rules[6][0],
            "revision",
            rules[6][1],
            evidence_path="result.layers.durable_status",
            observed=episode.get("result", {}).get("layers", {}).get("durable_status"),
            expected="committed revision",
        )
        if pending
        else _check(
            episode=episode,
            check_id=rules[6][0],
            pack="revision",
            severity=rules[6][1],
            paths=["result.layers.run_status", "result.layers.durable_status"],
            expected=["completed", "committed"],
            predicate=lambda values: values == ["completed", "committed"],
            message="Successful reversible revision must reach a committed terminal state.",
        )
    )
    return [
        _check(
            episode=episode, check_id=rules[0][0], pack="revision", severity=rules[0][1],
            paths=[f"{public_invocation_path}.canonical_args.expected_version", f"{before_plan}.data.version" if before_plan else "state_before.missing_plan"],
            expected="expected_version equals state_before version", predicate=lambda values: values[0] == values[1],
            message="Optimistic expected version must match the captured pre-state.",
        ),
        _check(
            episode=episode, check_id=rules[1][0], pack="revision", severity=rules[1][1],
            paths=[
                "state_delta.changes",
                f"{public_invocation_path}.canonical_args",
                "state_after.logical_entities",
            ],
            expected="only explicitly requested Plan fields plus managed version fields",
            observed={"changed_fields": sorted(str(value) for value in changed_fields)},
            predicate=lambda values: all(
                (
                    path.removeprefix("data.") in values[1]
                    and values[1][path.removeprefix("data.")] is not None
                )
                or path in {"data.version", "data.updated_at"}
                for path in changed_fields
            ),
            message="Revision must remain inside the requested change scope.",
        ),
        reversible_check,
        alignment_check,
        _check(
            episode=episode, check_id=rules[4][0], pack="revision", severity=rules[4][1],
            paths=["state_delta.changes", "state_after.logical_entities"], expected={"unrelated_product_changes": 0},
            observed={"unrelated_product_changes": len(unrelated)}, predicate=lambda _: not unrelated,
            message="Unrelated durable learning state must remain unchanged.",
        ),
        _check(
            episode=episode, check_id=rules[5][0], pack="revision", severity=rules[5][1],
            paths=["result.layers.durable_status", "observable_trace.tool_invocations"],
            expected="pending approval is not reported as committed",
            observed={"pending_approval_count": len(pending), "durable_status": episode.get("result", {}).get("layers", {}).get("durable_status")},
            predicate=lambda values: not pending or values[0] in {"pending", "deferred"},
            message="Approval-required revisions must not be committed early.",
        ),
        durable_success_check,
    ]


def _trace_checks(episode: Mapping[str, Any]) -> list[dict[str, Any]]:
    trace = episode.get("observable_trace", {})
    turns = trace.get("model_turns", [])
    invocations = trace.get("tool_invocations", [])
    events = trace.get("run_events", [])
    operations = trace.get("operations", [])
    invocation_ids = {item.get("invocation_id") for item in invocations}
    referenced = [ref for turn in turns for ref in turn.get("tool_call_refs", [])]
    result_digests = all(item.get("result_digest") == sha256_digest(item.get("result")) for item in invocations)
    event_digests = all(item.get("payload_digest") == sha256_digest(item.get("payload")) for item in events)
    patch_digests = all(item.get("patch_digest") == sha256_digest({"forward_patch": item.get("forward_patch"), "inverse_patch": item.get("inverse_patch")}) for item in operations)
    no_tools = not invocations
    no_tool_action = episode.get("result", {}).get("action_class") in {"WAIT", "NO_OP"}
    run_paths = _entity_paths(episode, "state_after", "agent_run")
    approval_paths = _entity_paths(episode, "state_after", "run_approval")
    run_status = episode.get("result", {}).get("layers", {}).get("run_status")
    durable_status = episode.get("result", {}).get("layers", {}).get(
        "durable_status"
    )
    exportable_run_state = run_status in {
        "completed",
        "failed",
        "cancelled",
        "needs_reconciliation",
    } or (
        run_status == "waiting_approval"
        and durable_status in {"pending", "deferred"}
        and bool(approval_paths)
    )
    checkpoint_absent = all("checkpoint" not in (resolve_evidence_path(episode, f"{path}.data")[1] or {}) for path in run_paths)
    return [
        _check(episode=episode, check_id="trace.model_ordinals", pack="trace", severity="critical", paths=["observable_trace.model_turns"], expected="contiguous ordinals", observed=[item.get("ordinal") for item in turns], predicate=lambda _: [item.get("ordinal") for item in turns] == list(range(1, len(turns) + 1)), message="Model turn ordinals must be contiguous."),
        _check(episode=episode, check_id="trace.tool_refs", pack="trace", severity="critical", paths=["observable_trace.model_turns", "observable_trace.tool_invocations"], expected="all tool refs resolve", observed={"refs": referenced, "invocation_ids": sorted(str(value) for value in invocation_ids)}, predicate=lambda _: set(referenced).issubset(invocation_ids), message="Model tool-call references must resolve to captured invocations."),
        _check(episode=episode, check_id="trace.invocation_event_order", pack="trace", severity="minor", paths=["observable_trace.run_events", "observable_trace.tool_invocations"], expected="contiguous event and invocation order", observed={"event_ordinals": [item.get("ordinal") for item in events], "invocation_ordinals": [item.get("ordinal") for item in invocations]}, predicate=lambda _: [item.get("ordinal") for item in events] == list(range(1, len(events) + 1)) and [item.get("ordinal") for item in invocations] == list(range(1, len(invocations) + 1)), message="Trace collections must preserve stable Runtime order."),
        _check(episode=episode, check_id="trace.result_digests", pack="trace", severity="critical", paths=["observable_trace.tool_invocations", "observable_trace.run_events"], expected=True, observed={"tool_results": result_digests, "events": event_digests}, predicate=lambda _: result_digests and event_digests, message="Tool results and Run events must have recomputable digests."),
        _check(episode=episode, check_id="trace.operation_patches", pack="trace", severity="critical", paths=["observable_trace.operations"], expected=True, observed={"operation_count": len(operations), "digests_valid": patch_digests}, predicate=lambda _: patch_digests, message="Operation patch digests must be recomputable."),
        _check(episode=episode, check_id="trace.terminal_state", pack="trace", severity="critical", paths=["result.layers.run_status", "result.layers.durable_status", "state_after.logical_entities"], expected="terminal or durable approval-pause state", observed={"run_status": run_status, "durable_status": durable_status, "agent_run_count": len(run_paths), "run_approval_count": len(approval_paths)}, predicate=lambda _: exportable_run_state, message="Episode must preserve a terminal or explicitly approval-paused Runtime state."),
        _check(episode=episode, check_id="trace.no_tool_complete", pack="trace", severity="major", paths=["observable_trace.tool_invocations", "result.action_class", "completeness.status"], expected="no-tool WAIT/NO_OP remains complete", observed={"tool_invocation_count": len(invocations), "action_class": episode.get("result", {}).get("action_class"), "completeness": episode.get("completeness", {}).get("status")}, predicate=lambda values: not no_tools or (no_tool_action and values[2] == "complete"), message="A no-tool WAIT or NO_OP remains a valid complete Episode."),
        _check(episode=episode, check_id="trace.checkpoint_independent", pack="trace", severity="critical", paths=["state_after.logical_entities", "result.layers.run_status"], expected="terminal state excludes checkpoint; approval pause has durable RunApproval", observed={"agent_run_count": len(run_paths), "checkpoint_absent": checkpoint_absent, "run_approval_count": len(approval_paths)}, predicate=lambda _: bool(run_paths) and checkpoint_absent and (run_status != "waiting_approval" or bool(approval_paths)), message="Exported state must remain explainable without publishing a Runtime checkpoint."),
    ]


def _isolation_checks(episode: Mapping[str, Any]) -> list[dict[str, Any]]:
    mode = episode.get("environment", {}).get("model", {}).get("invocation_mode")
    expected_network = "disabled" if mode == "stub" else "model_provider_only"
    external_paths = [
        "isolation_evidence.network_calls",
        "isolation_evidence.smtp_calls",
        "isolation_evidence.smtp_ssl_calls",
        "isolation_evidence.web_push_calls",
        "isolation_evidence.imap_calls",
        "isolation_evidence.imap_ssl_calls",
        "isolation_evidence.subprocess_calls",
    ]
    return [
        _check(episode=episode, check_id="isolation.temporary_database", pack="isolation", severity="critical", paths=["environment.runtime.database_mode", "isolation_evidence.temporary_database", "isolation_evidence.database_inside_worker_root"], expected=["temporary_fixture", True, True], predicate=lambda values: values == ["temporary_fixture", True, True], message="Runtime database must be a worker-contained temporary fixture."),
        _check(episode=episode, check_id="isolation.production_database_denied", pack="isolation", severity="critical", paths=["environment.isolation.production_database_access", "isolation_evidence.repository_runtime_data_access", "isolation_evidence.outside_sqlite_access"], expected=[False, False, 0], predicate=lambda values: values == [False, False, 0], message="Production and repository Runtime data access must remain denied."),
        _check(episode=episode, check_id="isolation.network_mode", pack="isolation", severity="critical", paths=["environment.model.invocation_mode", "environment.isolation.network_access"], expected=expected_network, predicate=lambda values: values[1] == ("disabled" if values[0] == "stub" else "model_provider_only"), message="Network mode must match the declared model invocation mode."),
        _check(episode=episode, check_id="isolation.fake_outbox", pack="isolation", severity="critical", paths=["environment.isolation.notification_mode"], expected="fake_outbox", predicate=lambda values: values[0] == "fake_outbox", message="Evaluation delivery must retain the production Outbox plus recording sink."),
        _check(episode=episode, check_id="isolation.no_sqlite_publish", pack="isolation", severity="critical", paths=["isolation_evidence.published_sqlite_files"], expected=0, predicate=lambda values: values[0] == 0, message="No SQLite, WAL, or SHM file may be published."),
        _check(episode=episode, check_id="isolation.no_routing_material", pack="isolation", severity="critical", paths=["isolation_evidence.routing_material_exported", "isolation_evidence.agent_observed_emulated_receipt"], expected=[False, False], predicate=lambda values: values == [False, False], message="Routing material and emulated Receipts must remain outside public/model-visible facts."),
        _check(episode=episode, check_id="isolation.background_disabled", pack="isolation", severity="critical", paths=["isolation_evidence.background_services_started", "isolation_evidence.env_file_read"], expected=[False, False], predicate=lambda values: values == [False, False], message="Background services and repository env loading must remain disabled."),
        _check(episode=episode, check_id="isolation.external_calls_zero", pack="isolation", severity="critical", paths=external_paths, expected=[0] * len(external_paths), predicate=lambda values: values == [0] * len(external_paths), message="Stub evaluation must make zero external provider calls."),
    ]


def evaluate_rules(episode: Mapping[str, Any]) -> dict[str, Any]:
    """Evaluate stable structured facts; no Judge score or language heuristic exists."""

    checks = [
        *_common_checks(episode),
        *_planning_checks(episode),
        *_intervention_checks(episode),
        *_assessment_checks(episode),
        *_revision_checks(episode),
        *_trace_checks(episode),
        *_isolation_checks(episode),
    ]
    pack_order = {name: index for index, name in enumerate(("common", "planning", "intervention", "assessment", "revision", "trace", "isolation"))}
    checks.sort(key=lambda item: (pack_order[item["rule_pack"]], item["check_id"]))
    hard_gates = [
        item["check_id"]
        for item in checks
        if item["status"] == "fail" and item["severity"] == "critical"
    ]
    status = (
        "invalid_input"
        if any(item["status"] == "invalid_input" for item in checks)
        else "fail"
        if any(item["status"] == "fail" for item in checks)
        else "pass"
    )
    formal = bool(episode.get("provenance", {}).get("formal_evaluation_result", False))
    result = {
        "schema_version": "rule-result-v1",
        "evaluator_version": EVALUATOR_VERSION,
        "episode_id": str(episode.get("episode_id") or "invalid-episode"),
        "episode_sha256": str(
            episode.get("provenance", {}).get("episode_sha256")
            or sha256_digest(episode)
        ),
        "rule_pack_version": RULE_PACK_VERSION,
        "rule_pack_sha256": RULE_PACK_SHA256,
        "checks": checks,
        "hard_gates": hard_gates,
        "dimension_signals": {
            "attempted_tool_calls": sum(
                len(item.get("invocation_refs", []))
                for item in episode.get("result", {}).get("layers", {}).get("model_attempts", [])
            ),
            "guard_status": episode.get("result", {}).get("guard", {}).get("status", "missing"),
            "final_effect_count": len(
                episode.get("result", {}).get("layers", {}).get("final_effects", [])
            ),
            "durable_status": episode.get("result", {}).get("layers", {}).get("durable_status", "missing"),
            "hard_gate_count": len(hard_gates),
        },
        "status": status,
        "formal_evaluation_result": formal,
        "result_sha256": "0" * 64,
    }
    result["result_sha256"] = rule_result_digest(result)
    return result


def _common_checks_v2(
    episode: Mapping[str, Any], reference: Mapping[str, Any]
) -> list[dict[str, Any]]:
    """Validate v3 integrity and linkage without deciding behavioral correctness."""

    return [
        _check(
            episode=episode,
            check_id="common.schema",
            pack="common",
            severity="critical",
            paths=[
                "schema_version",
                "result.action_mapping_version",
                "result.action_mapping_sha256",
            ],
            expected={
                "schema_version": "decision-episode-v3",
                "action_mapping_version": ACTION_MAPPING_VERSION,
                "action_mapping_sha256": ACTION_MAPPING_SHA256,
            },
            predicate=lambda values: values
            == ["decision-episode-v3", ACTION_MAPPING_VERSION, ACTION_MAPPING_SHA256],
            message="Rules v2 accept DecisionEpisode v3 only.",
        ),
        _check(
            episode=episode,
            check_id="common.episode_digest",
            pack="common",
            severity="critical",
            paths=["provenance.episode_sha256"],
            expected=decision_episode_digest(episode),
            predicate=lambda values: values[0] == decision_episode_digest(episode),
            message="Episode self-digest must be recomputable.",
        ),
        _check(
            episode=episode,
            check_id="common.completeness",
            pack="common",
            severity="critical",
            paths=[
                "completeness.status",
                "completeness.evidence_error_codes",
                "completeness.decision_correctness_evaluated",
            ],
            expected=["complete", [], False],
            predicate=lambda values: values == ["complete", [], False],
            message="Only evidence-complete Episodes enter deterministic Rules.",
        ),
        _check(
            episode=episode,
            check_id="common.runtime_provenance",
            pack="common",
            severity="critical",
            paths=["provenance.runtime_executed", "provenance.construction_method"],
            expected=[True, "runtime_recorded"],
            predicate=lambda values: values == [True, "runtime_recorded"],
            message="v3 provenance must describe an executed Runtime recording.",
        ),
        _check(
            episode=episode,
            check_id="common.provider_attribution",
            pack="common",
            severity="critical",
            paths=[
                "environment.provider_attestation.invocation_mode",
                "environment.provider_attestation.attribution_status",
                "provenance.formal_evaluation_result",
            ],
            expected="formal requires eligible real attribution",
            predicate=lambda values: (
                values == ["stub", "ineligible_stub", False]
                or values == ["real", "eligible", True]
                or values == ["real", "eligible", False]
                or values == ["real", "invalid", False]
            ),
            message="Provider attribution is necessary but not sufficient for formal status.",
        ),
        _check(
            episode=episode,
            check_id="common.environment_digest",
            pack="common",
            severity="critical",
            paths=["environment.manifest_sha256"],
            expected=environment_manifest_digest(episode["environment"]),
            predicate=lambda values: values[0]
            == environment_manifest_digest(episode["environment"]),
            message="Environment manifest digest must be recomputable.",
        ),
        _check(
            episode=episode,
            check_id="common.reference_linkage",
            pack="common",
            severity="critical",
            paths=["case_spec_sha256", "judge_reference_sha256", "track"],
            expected={
                "case_spec_sha256": reference.get("case_spec_sha256"),
                "judge_reference_sha256": reference.get("reference_sha256"),
                "track": reference.get("track"),
            },
            predicate=lambda values: values
            == [
                reference.get("case_spec_sha256"),
                reference.get("reference_sha256"),
                reference.get("track"),
            ],
            message="Episode and JudgeReference digests and track must match.",
        ),
        _check(
            episode=episode,
            check_id="common.action_envelope",
            pack="common",
            severity="critical",
            paths=["result.action_class"],
            expected={"allowed_action_classes": reference["allowed_action_classes"]},
            predicate=lambda values: values[0] in reference["allowed_action_classes"],
            message="Observed action must satisfy the CaseSpec action envelope.",
        ),
    ]


def _predicate_passes(value: Any, operator: str, expected: Any) -> bool:
    if operator == "equals":
        return value == expected
    if operator == "not_equals":
        return value != expected
    if operator == "contains":
        return expected in value
    if operator == "not_contains":
        return expected not in value
    if operator == "exists":
        return bool(expected)
    if operator == "not_exists":
        return not bool(expected)
    if operator == "greater_than_or_equal":
        return value >= expected
    if operator == "less_than_or_equal":
        return value <= expected
    raise ValueError("unsupported predicate")


def _case_predicate_checks(
    episode: Mapping[str, Any], reference: Mapping[str, Any]
) -> list[dict[str, Any]]:
    checks: list[dict[str, Any]] = []
    constraints = sorted(reference["constraints"], key=lambda item: item["constraint_id"])
    for constraint in constraints:
        if constraint["evaluation"] != "deterministic_rule":
            continue
        for index, predicate in enumerate(constraint["predicates"], 1):
            found, observed = resolve_evidence_path(episode, predicate["path"])
            if predicate["operator"] == "not_exists":
                passed = not found
            elif predicate["operator"] == "exists":
                passed = found == bool(predicate["expected_value"])
            elif not found:
                passed = False
            else:
                try:
                    passed = _predicate_passes(
                        observed,
                        predicate["operator"],
                        predicate["expected_value"],
                    )
                except (TypeError, ValueError):
                    passed = False
            evidence_paths = (
                [predicate["path"]] if found else [constraint["evidence_paths"][0]]
            )
            checks.append(
                {
                    "check_id": f"case.{constraint['constraint_id']}.{index:02d}",
                    "rule_pack": episode["track"],
                    "status": "pass" if passed else "fail",
                    "severity": constraint["criticality"],
                    "evidence_paths": evidence_paths,
                    "observed": observed if found else {"present": False},
                    "expected": {
                        "operator": predicate["operator"],
                        "value": predicate["expected_value"],
                    },
                    "reason_code": (
                        "case_constraint_satisfied"
                        if passed
                        else "case_constraint_violated"
                    ),
                    "message": constraint["public_statement"],
                }
            )
    return checks


def _common_checks_v3(
    episode: Mapping[str, Any], reference: Mapping[str, Any]
) -> list[dict[str, Any]]:
    """Validate v4 evidence and links without treating behavior as structure."""

    allowed = list(reference["allowed_action_classes"])
    return [
        _check(
            episode=episode,
            check_id="common.schema",
            pack="common",
            severity="critical",
            paths=[
                "schema_version",
                "result.action_mapping_version",
                "result.action_mapping_sha256",
            ],
            expected={
                "schema_version": "decision-episode-v4",
                "action_mapping_version": ACTION_MAPPING_VERSION_V2,
                "action_mapping_sha256": ACTION_MAPPING_SHA256_V2,
            },
            predicate=lambda values: values
            == [
                "decision-episode-v4",
                ACTION_MAPPING_VERSION_V2,
                ACTION_MAPPING_SHA256_V2,
            ],
            message="Rules v3 accept the active DecisionEpisode v4 contract only.",
        ),
        _check(
            episode=episode,
            check_id="common.episode_digest",
            pack="common",
            severity="critical",
            paths=["provenance.episode_sha256"],
            expected=decision_episode_digest(episode),
            predicate=lambda values: values[0] == decision_episode_digest(episode),
            message="Episode self-digest must be recomputable.",
        ),
        _check(
            episode=episode,
            check_id="common.completeness",
            pack="common",
            severity="critical",
            paths=[
                "completeness.status",
                "completeness.evidence_error_codes",
                "completeness.decision_correctness_evaluated",
            ],
            expected=["complete", [], False],
            predicate=lambda values: values == ["complete", [], False],
            message="Only evidence-complete Episodes enter deterministic Rules.",
        ),
        _check(
            episode=episode,
            check_id="common.runtime_provenance",
            pack="common",
            severity="critical",
            paths=["provenance.runtime_executed", "provenance.construction_method"],
            expected=[True, "runtime_recorded"],
            predicate=lambda values: values == [True, "runtime_recorded"],
            message="v4 provenance must describe an executed Runtime recording.",
        ),
        _check(
            episode=episode,
            check_id="common.provider_attribution",
            pack="common",
            severity="critical",
            paths=[
                "environment.provider_attestation.invocation_mode",
                "environment.provider_attestation.attribution_status",
                "provenance.provider_eligible",
                "provenance.formal_evaluation_result",
            ],
            expected="artifact Provider eligibility mirrors attribution; artifact is never formal",
            predicate=lambda values: (
                values == ["stub", "ineligible_stub", False, False]
                or values == ["real", "eligible", True, False]
                or values == ["real", "invalid", False, False]
            ),
            message="Provider attribution is separate from Benchmark trust and capability publication.",
        ),
        _check(
            episode=episode,
            check_id="common.environment_digest",
            pack="common",
            severity="critical",
            paths=["environment.manifest_sha256"],
            expected=environment_manifest_digest(episode["environment"]),
            predicate=lambda values: values[0]
            == environment_manifest_digest(episode["environment"]),
            message="Environment manifest digest must be recomputable.",
        ),
        _check(
            episode=episode,
            check_id="common.reference_linkage",
            pack="common",
            severity="critical",
            paths=["case_spec_sha256", "judge_reference_sha256", "track"],
            expected={
                "case_spec_sha256": reference.get("case_spec_sha256"),
                "judge_reference_sha256": reference.get("reference_sha256"),
                "track": reference.get("track"),
                "predicate_semantics": "constraint-proposition-v1",
            },
            predicate=lambda values: values
            == [
                reference.get("case_spec_sha256"),
                reference.get("reference_sha256"),
                reference.get("track"),
            ]
            and reference.get("predicate_semantics")
            == "constraint-proposition-v1",
            message="Episode, JudgeReference, track, and predicate semantics must match.",
        ),
        _check(
            episode=episode,
            check_id="common.action_envelope",
            pack="common",
            severity="critical",
            paths=["result.action_classes"],
            expected={"allowed_action_classes": allowed},
            predicate=lambda values: bool(values[0])
            and set(values[0]).issubset(set(allowed)),
            message="Every observed action must satisfy the CaseSpec action envelope.",
        ),
        _check(
            episode=episode,
            check_id="common.action_classification",
            pack="common",
            severity="critical",
            paths=["result.classification_issues", "result.action_classes"],
            expected={"classification_issues": []},
            predicate=lambda values: values[0] == [],
            message=(
                "Action declarations, observed effects, and state changes must be "
                "classified without hiding scoreable behavior."
            ),
        ),
    ]


def _evaluate_case_predicate(
    episode: Mapping[str, Any], predicate: Mapping[str, Any]
) -> tuple[bool, bool, Any]:
    found, observed = resolve_evidence_path(episode, predicate["path"])
    operator = predicate["operator"]
    expected = predicate["expected_value"]
    if operator == "exists":
        matches = found == bool(expected)
    elif operator == "not_exists":
        matches = (not found) == bool(expected)
    elif not found:
        matches = False
    else:
        try:
            matches = _predicate_passes(observed, operator, expected)
        except (TypeError, ValueError):
            matches = False
    return found, matches, observed


def _case_predicate_checks_v3(
    episode: Mapping[str, Any], reference: Mapping[str, Any]
) -> list[dict[str, Any]]:
    """Apply constraint-proposition-v1 exactly once per deterministic constraint."""

    if reference.get("predicate_semantics") != "constraint-proposition-v1":
        raise ValueError("unsupported CaseSpec predicate semantics")
    checks: list[dict[str, Any]] = []
    constraints = sorted(reference["constraints"], key=lambda item: item["constraint_id"])
    for constraint in constraints:
        if constraint["evaluation"] != "deterministic_rule":
            continue
        observations = []
        resolved_paths: list[str] = []
        predicate_results: list[bool] = []
        for predicate in constraint["predicates"]:
            found, matches, observed = _evaluate_case_predicate(episode, predicate)
            if found:
                resolved_paths.append(predicate["path"])
            predicate_results.append(matches)
            observations.append(
                {
                    "path": predicate["path"],
                    "present": found,
                    "matches": matches,
                    "value": observed if found else None,
                }
            )
        proposition_holds = all(predicate_results)
        passed = (
            proposition_holds
            if constraint["kind"] == "must_satisfy"
            else not proposition_holds
        )
        checks.append(
            {
                "check_id": f"case.{constraint['constraint_id']}",
                "rule_pack": episode["track"],
                "status": "pass" if passed else "fail",
                "severity": constraint["criticality"],
                "evidence_paths": sorted(set(resolved_paths))
                or ["result.action_classes"],
                "observed": {
                    "constraint_kind": constraint["kind"],
                    "proposition_holds": proposition_holds,
                    "predicates": observations,
                },
                "expected": {
                    "predicate_semantics": "constraint-proposition-v1",
                    "required_proposition_value": constraint["kind"]
                    == "must_satisfy",
                },
                "reason_code": (
                    "case_constraint_satisfied"
                    if passed
                    else "case_constraint_violated"
                ),
                "message": constraint["public_statement"],
            }
        )
    return checks


def _behavioralize_v3_track_checks(
    episode: Mapping[str, Any], checks: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    """Treat absent behavior in a structurally valid v3 Episode as a failure."""

    fallback = ["result.action_class", "state_after.logical_entities"]
    for check in checks:
        if check["status"] != "invalid_input":
            continue
        check.update(
            {
                "status": "fail",
                "evidence_paths": fallback,
                "observed": {"required_behavior_present": False},
                "reason_code": "required_behavior_missing",
                "message": (
                    "Required decision behavior is absent from a structurally valid Episode."
                ),
            }
        )
    return checks


def _trace_checks_v2(episode: Mapping[str, Any]) -> list[dict[str, Any]]:
    trace = episode.get("observable_trace", {})
    calls = trace.get("model_calls", [])
    invocations = trace.get("tool_invocations", [])
    events = trace.get("run_events", [])
    operations = trace.get("operations", [])
    invocation_ids = {item.get("invocation_id") for item in invocations}
    referenced = [ref for call in calls for ref in call.get("tool_call_refs", [])]
    response_digests = all(
        call.get("status") != "completed"
        or call.get("response_sha256")
        == sha256_digest(
            {
                "assistant_text": call.get("assistant_text") or "",
                "tool_call_refs": call.get("tool_call_refs", []),
            }
        )
        for call in calls
    )
    result_digests = all(
        item.get("result_digest") == sha256_digest(item.get("result"))
        for item in invocations
    ) and all(
        item.get("payload_digest") == sha256_digest(item.get("payload"))
        for item in events
    )
    patch_digests = all(
        item.get("patch_digest")
        == sha256_digest(
            {
                "forward_patch": item.get("forward_patch"),
                "inverse_patch": item.get("inverse_patch"),
            }
        )
        for item in operations
    )
    run_paths = _entity_paths(episode, "state_after", "agent_run")
    approval_paths = _entity_paths(episode, "state_after", "run_approval")
    run_status = episode.get("result", {}).get("layers", {}).get("run_status")
    durable_status = episode.get("result", {}).get("layers", {}).get(
        "durable_status"
    )
    exportable = run_status in {
        "completed",
        "failed",
        "cancelled",
        "needs_reconciliation",
    } or (
        run_status == "waiting_approval"
        and durable_status in {"pending", "deferred"}
        and bool(approval_paths)
    )
    checkpoint_absent = all(
        "checkpoint"
        not in (resolve_evidence_path(episode, f"{path}.data")[1] or {})
        for path in run_paths
    )
    checks = [
        (
            "trace.model_ordinals",
            "critical",
            ["observable_trace.model_calls"],
            [item.get("ordinal") for item in calls]
            == list(range(1, len(calls) + 1)),
            "Model calls must use contiguous ordinals.",
        ),
        (
            "trace.tool_refs",
            "critical",
            ["observable_trace.model_calls", "observable_trace.tool_invocations"],
            set(referenced).issubset(invocation_ids),
            "Model tool references must resolve.",
        ),
        (
            "trace.invocation_event_order",
            "minor",
            ["observable_trace.run_events", "observable_trace.tool_invocations"],
            [item.get("ordinal") for item in events]
            == list(range(1, len(events) + 1))
            and [item.get("ordinal") for item in invocations]
            == list(range(1, len(invocations) + 1)),
            "Runtime collections must preserve stable order.",
        ),
        (
            "trace.result_digests",
            "critical",
            [
                "observable_trace.model_calls",
                "observable_trace.tool_invocations",
                "observable_trace.run_events",
            ],
            response_digests and result_digests,
            "Model, tool, and event digests must be recomputable.",
        ),
        (
            "trace.operation_patches",
            "critical",
            ["observable_trace.operations"],
            patch_digests,
            "Operation patches must be recomputable.",
        ),
        (
            "trace.terminal_state",
            "critical",
            [
                "result.layers.run_status",
                "result.layers.durable_status",
                "state_after.logical_entities",
            ],
            exportable,
            "Runtime must reach an exportable terminal state.",
        ),
        (
            "trace.no_tool_complete",
            "major",
            [
                "observable_trace.tool_invocations",
                "result.action_class",
                "completeness.status",
            ],
            bool(invocations)
            or episode.get("completeness", {}).get("status") == "complete",
            "No-tool behavior remains a valid complete Episode.",
        ),
        (
            "trace.checkpoint_independent",
            "critical",
            ["state_after.logical_entities", "result.layers.run_status"],
            bool(run_paths)
            and checkpoint_absent
            and (run_status != "waiting_approval" or bool(approval_paths)),
            "Published state must not depend on a private checkpoint.",
        ),
    ]
    return [
        _check(
            episode=episode,
            check_id=check_id,
            pack="trace",
            severity=severity,
            paths=paths,
            expected=True,
            predicate=lambda _values, passed=passed: passed,
            observed=passed,
            message=message,
        )
        for check_id, severity, paths, passed, message in checks
    ]


def _isolation_checks_v2(episode: Mapping[str, Any]) -> list[dict[str, Any]]:
    invocation_mode = episode["environment"]["provider_attestation"][
        "invocation_mode"
    ]
    projected = {
        **episode,
        "environment": {
            **episode["environment"],
            "model": {"invocation_mode": invocation_mode},
        },
    }
    checks = _isolation_checks(projected)
    for check in checks:
        check["evidence_paths"] = [
            (
                "environment.provider_attestation.invocation_mode"
                if path == "environment.model.invocation_mode"
                else path
            )
            for path in check["evidence_paths"]
        ]
    return checks


def _isolation_checks_v3(episode: Mapping[str, Any]) -> list[dict[str, Any]]:
    checks = _isolation_checks_v2(episode)
    checks.append(
        _check(
            episode=episode,
            check_id="isolation.prohibited_file_access",
            pack="isolation",
            severity="critical",
            paths=["isolation_evidence.prohibited_file_access"],
            expected=0,
            predicate=lambda values: values == [0],
            message="Every prohibited file access counter must remain zero.",
        )
    )
    return checks


def evaluate_rules_v2(
    episode: Mapping[str, Any], reference: Mapping[str, Any]
) -> dict[str, Any]:
    """Evaluate v3 facts; structurally valid wrong decisions remain scoreable."""

    track_checks = [
        *_planning_checks(episode),
        *_intervention_checks(episode),
        *_assessment_checks(episode),
        *_revision_checks(episode),
    ]
    checks = [
        *_common_checks_v2(episode, reference),
        *_behavioralize_v3_track_checks(episode, track_checks),
        *_case_predicate_checks(episode, reference),
        *_trace_checks_v2(episode),
        *_isolation_checks_v2(episode),
    ]
    pack_order = {
        name: index
        for index, name in enumerate(
            (
                "common",
                "planning",
                "intervention",
                "assessment",
                "revision",
                "trace",
                "isolation",
            )
        )
    }
    checks.sort(key=lambda item: (pack_order[item["rule_pack"]], item["check_id"]))
    hard_gates = [
        item["check_id"]
        for item in checks
        if item["status"] == "fail" and item["severity"] == "critical"
    ]
    status = (
        "invalid_input"
        if any(item["status"] == "invalid_input" for item in checks)
        else "fail"
        if any(item["status"] == "fail" for item in checks)
        else "pass"
    )
    result = {
        "schema_version": "rule-result-v2",
        "evaluator_version": EVALUATOR_VERSION_V2,
        "episode_id": episode["episode_id"],
        "episode_sha256": episode["provenance"]["episode_sha256"],
        "case_spec_sha256": episode["case_spec_sha256"],
        "judge_reference_sha256": reference["reference_sha256"],
        "rule_pack_version": RULE_PACK_VERSION_V2,
        "rule_pack_sha256": RULE_PACK_SHA256_V2,
        "checks": checks,
        "hard_gates": hard_gates,
        "dimension_signals": {
            "decision_call_count": len(
                episode["observable_trace"]["decision_call_refs"]
            ),
            "guard_status": episode["result"]["guard"]["status"],
            "final_effect_count": len(episode["result"]["layers"]["final_effects"]),
            "durable_status": episode["result"]["layers"]["durable_status"],
            "semantic_constraint_count": sum(
                item["evaluation"] == "semantic_judge"
                for item in reference["constraints"]
            ),
            "hard_gate_count": len(hard_gates),
        },
        "status": status,
        "formal_evaluation_result": bool(
            episode["provenance"]["formal_evaluation_result"]
        ),
        "result_sha256": "0" * 64,
    }
    result["result_sha256"] = rule_result_digest(result)
    return result


def _active_track_checks(
    episode: Mapping[str, Any], reference: Mapping[str, Any]
) -> list[dict[str, Any]]:
    """Apply write requirements only to decisions that require those writes.

    The reviewed envelope authorizes abstention; captured effects independently
    prove that it remained an abstention. A declaration alone cannot waive a gate.
    """

    checks = [
        *_planning_checks(episode, allow_pending_proposal=True),
        *_intervention_checks(episode),
        *_assessment_checks(episode),
        *_revision_checks(episode),
    ]
    track = episode["track"]
    non_writing = {
        "planning": {"REQUEST_USER_INPUT"},
        "intervention": {"WAIT", "REQUEST_USER_INPUT", "PROPOSE_PLAN_ADJUSTMENT"},
        "assessment": {"INSUFFICIENT_EVIDENCE", "REQUEST_CLARIFICATION"},
        "revision": {"NO_OP", "PROPOSE_CHANGE", "REQUEST_APPROVAL"},
    }[track]
    actions = set(episode["result"]["action_classes"])
    abstention = bool(actions) and actions <= non_writing
    approved = actions <= set(reference["allowed_action_classes"])
    # Agent/session/audit rows may change even when learning state is untouched.
    product_types = {
        "plan", "stage", "task", "submission", "plan_proposal", "quiz",
        "review", "intervention", "notification", "outbox_action", "outbox_receipt",
    }
    types = {
        entity["logical_id"]: entity["entity_type"]
        for root in ("state_before", "state_after")
        for entity in episode[root]["logical_entities"]
    }
    changes = [
        change for change in episode["state_delta"]["changes"]
        if types.get(change["entity_ref"]) in product_types
    ]
    if abstention and approved:
        checks = [
            _conditional_not_applicable(
                episode, check["check_id"], track, check["severity"],
                evidence_path="result.action_classes", observed=sorted(actions),
                expected="a decision requiring a persisted effect",
            ) if check["rule_pack"] == track else check
            for check in checks
        ]
        checks.append(_check(
            episode=episode, check_id=f"{track}.abstention_preserves_state",
            pack=track, severity="critical",
            paths=["state_delta.changes", "observable_trace.operations"],
            expected={"product_changes": 0, "operations": 0},
            observed={"product_changes": len(changes), "operations": len(episode["observable_trace"]["operations"])},
            predicate=lambda _: not changes and not episode["observable_trace"]["operations"],
            message="A question, deferral or proposal must preserve durable learning state.",
        ))
    if track == "intervention" and actions == {"INTERVENE_QUIZ_OR_REVIEW"}:
        invocations = episode["observable_trace"]["tool_invocations"]
        materialized = [item for item in invocations if item["tool_name"] in {"quiz.create", "review.schedule"} and item["durable_status"] == "committed"]
        checks.append(_check(
            episode=episode, check_id="intervention.quiz_or_review_present", pack=track,
            severity="critical", paths=["observable_trace.tool_invocations"],
            expected="at least one persisted quiz or review", predicate=lambda _: bool(materialized),
            message="A quiz/review intervention must materialize its declared artifact.",
        ))
        if episode["result"]["guard"]["status"] == "not_evaluated" and not any(item["tool_name"] == "notification.send" for item in invocations):
            checks = [
                _conditional_not_applicable(episode, item["check_id"], track, item["severity"],
                                            evidence_path="observable_trace.tool_invocations",
                                            observed="quiz/review creation without notification delivery",
                                            expected="notification Guard evaluation")
                if item["check_id"] == "intervention.guard_complete" else item
                for item in checks
            ]
    # Delivery count is a Case quality constraint, not an idempotency invariant.
    for check in checks:
        if check["check_id"] == "intervention.replay_idempotent" and check["status"] != "not_applicable":
            evidence = episode["isolation_evidence"]
            count = sum(entity_type == "outbox_action" for entity_type in types.values())
            check.update(
                status="pass" if evidence["outbox_replay_confirmed"] and evidence["recording_sink_attempts"] == count else "fail",
                expected={"replay_confirmed": True, "sink_attempts": count},
            )
    return _behavioralize_v3_track_checks(episode, checks)


def evaluate_rules_v3(
    episode: Mapping[str, Any],
    reference: Mapping[str, Any],
    *,
    input_runtime_manifest_sha256: str,
    input_runtime_formal_evaluation_result: bool,
    input_runtime_trusted_benchmark_run: bool = False,
    evaluation_protocol_release_sha256: str = "0" * 64,
    benchmark_release_id: str = "unbound-engineering-release",
    benchmark_release_sha256: str = "0" * 64,
    runtime_run_id: str = "unbound-engineering-run",
    provider_eligible: bool = False,
    selection_mode: str = "adhoc_filter",
    worktree_clean: bool = False,
) -> dict[str, Any]:
    """Evaluate active v4 facts with scoreable behavior and monotonic formality."""

    checks = [
        *_common_checks_v3(episode, reference),
        *_active_track_checks(episode, reference),
        *_case_predicate_checks_v3(episode, reference),
        *_trace_checks_v2(episode),
        *_isolation_checks_v3(episode),
    ]
    pack_order = {
        name: index
        for index, name in enumerate(
            (
                "common",
                "planning",
                "intervention",
                "assessment",
                "revision",
                "trace",
                "isolation",
            )
        )
    }
    checks.sort(key=lambda item: (pack_order[item["rule_pack"]], item["check_id"]))
    hard_gates = [
        item["check_id"]
        for item in checks
        if item["status"] == "fail" and item["severity"] == "critical"
    ]
    status = (
        "invalid_input"
        if any(item["status"] == "invalid_input" for item in checks)
        else "fail"
        if any(item["status"] == "fail" for item in checks)
        else "pass"
    )
    protocol_eligible = bool(episode["provenance"]["protocol_eligible"])
    trusted = bool(
        input_runtime_trusted_benchmark_run
        and selection_mode == "inherited"
        and worktree_clean
        and protocol_eligible
        and provider_eligible
    )
    result = {
        "schema_version": "rule-result-v3",
        "evaluator_version": EVALUATOR_VERSION_V3,
        "episode_id": episode["episode_id"],
        "episode_sha256": episode["provenance"]["episode_sha256"],
        "case_spec_sha256": episode["case_spec_sha256"],
        "judge_reference_sha256": reference["reference_sha256"],
        "rule_pack_version": RULE_PACK_VERSION_V3,
        "rule_pack_sha256": RULE_PACK_SHA256_V3,
        "checks": checks,
        "hard_gates": hard_gates,
        "dimension_signals": {
            "decision_call_count": len(
                episode["observable_trace"]["decision_call_refs"]
            ),
            "guard_status": episode["result"]["guard"]["status"],
            "final_effect_count": len(episode["result"]["layers"]["final_effects"]),
            "action_count": len(episode["result"]["action_classes"]),
            "classification_issue_count": len(
                episode["result"]["classification_issues"]
            ),
            "durable_status": episode["result"]["layers"]["durable_status"],
            "semantic_constraint_count": sum(
                item["evaluation"] == "semantic_judge"
                for item in reference["constraints"]
            ),
            "hard_gate_count": len(hard_gates),
        },
        "status": status,
        "formal_evaluation_result": False,
        "evaluator_implementation_version": SOURCE_BUNDLE_VERSION,
        "evaluator_implementation_sha256": RULE_IMPLEMENTATION_SHA256_V3,
        "evaluation_protocol_release_id": "evaluation-protocol-release-1.0",
        "evaluation_protocol_release_sha256": evaluation_protocol_release_sha256,
        "benchmark_release_id": benchmark_release_id,
        "benchmark_release_sha256": benchmark_release_sha256,
        "runtime_run_id": runtime_run_id,
        "input_runtime_manifest_sha256": input_runtime_manifest_sha256,
        "input_runtime_formal_evaluation_result": False,
        "input_episode_formal_evaluation_result": False,
        "input_runtime_trusted_benchmark_run": bool(
            input_runtime_trusted_benchmark_run
        ),
        "selection_mode": selection_mode,
        "worktree_clean": bool(worktree_clean),
        "protocol_eligible": protocol_eligible,
        "provider_eligible": bool(provider_eligible),
        "trusted_benchmark_run": trusted,
        "result_sha256": "0" * 64,
    }
    result["result_sha256"] = rule_result_digest(result)
    return result
