"""Offline AI self-audit of E6 inventories, independent arithmetic and costs."""
import json
from collections import Counter
from pathlib import Path

from learning_agent_eval.canonical import sha256_digest
from learning_agent_eval.integrity import (
    aggregate_result_digest,
    artifact_manifest_digest,
    decision_episode_digest,
    judge_result_digest,
    rule_result_digest,
)
from learning_agent_eval.rubric import DIMENSION_WEIGHTS
from learning_agent_eval.semantic_adjudication import verify_reviewed_csv

p = Path(__file__).parent


def read(path):
    return json.loads(path.read_text())


checks = {}
runtime = read(p / "runtime/run-manifest.json")
raw_manifest = read(p / "aggregate/run-manifest.json")
final_manifest = read(p / "adjudicated/run-manifest.json")
for name, relative in (
    ("runtime", "runtime/run-manifest.json"), ("rules", "rules/rule-manifest.json"),
    ("judge", "judge/run-manifest.json"), ("raw", "aggregate/run-manifest.json"),
    ("reviewed", "adjudicated/run-manifest.json"),
):
    manifest = read(p / relative)
    checks[f"manifest_digest:{name}"] = artifact_manifest_digest(manifest) == manifest["manifest_sha256"]

plan = read(p / "run-plan-v2.json")
checks["fixed_case_order"] = runtime["selected_case_ids"] == plan["execution"]["ordered_case_ids"]
checks["fixed_48_terminals"] = len(runtime["terminals"]) == 48
checks["fixed_12_per_track"] = Counter(t["track"] for t in runtime["terminals"]) == Counter(plan["execution"]["expected_track_counts"])
checks["protocol_bound"] = runtime["evaluation_protocol_release_sha256"] == plan["protocol_release_sha256"]
checks["benchmark_bound"] = runtime["benchmark_release_sha256"] == plan["benchmark_release_sha256"]
checks["source_commit_clean"] = runtime["worktree_clean"] and runtime["git_commit"] == "b0b0d02ced10c3c6387a6541656a7b693571e312"
episodes, judges, aggregates = {}, {}, []
for terminal in runtime["terminals"]:
    case, identity = terminal["case_id"], terminal["artifact_id"]
    if terminal["terminal_kind"] != "episode":
        continue
    episode = read(p / "runtime/episodes" / f"{identity}.json")
    rule = read(p / "rules/rules" / f"{identity}.json")
    judge = read(p / "judge/judge-results" / f"{identity}.json")
    aggregate = read(p / "adjudicated/episodes" / f"{identity}.json")
    checks[f"episode_digest:{case}"] = decision_episode_digest(episode) == terminal["artifact_sha256"]
    checks[f"rule_digest:{case}"] = rule_result_digest(rule) == rule["result_sha256"]
    checks[f"judge_digest:{case}"] = judge_result_digest(judge) == judge["result_sha256"]
    checks[f"aggregate_digest:{case}"] = aggregate_result_digest(aggregate) == aggregate["result_sha256"]
    checks[f"raw_rule_result_preserved:{case}"] = aggregate == read(p / "aggregate/episodes" / f"{identity}.json")
    if aggregate["status"] == "complete":
        raw = sum(DIMENSION_WEIGHTS[d["dimension_id"]] * d["level"] / 2 for d in judge["dimensions"])
        cap = 39 if rule["hard_gates"] else 69 if any(c["status"] == "fail" and c["severity"] == "major" for c in rule["checks"]) else 100
        checks[f"independent_arithmetic:{case}"] = aggregate["raw_score"] == raw and aggregate["final_score"] == min(raw, cap)
    else:
        checks[f"unscored_null:{case}"] = aggregate["raw_score"] is None and aggregate["final_score"] is None
    isolation = episode["isolation_evidence"]
    checks[f"isolation:{case}"] = (
        isolation["temporary_database"] and isolation["database_inside_worker_root"]
        and not any(isolation[k] for k in ("env_file_read", "repository_runtime_data_access", "outside_sqlite_access", "prohibited_file_access", "published_sqlite_files", "routing_material_exported", "smtp_calls", "smtp_ssl_calls", "web_push_calls", "imap_calls", "imap_ssl_calls"))
    )
    episodes[identity], judges[identity] = episode, judge
    aggregates.append(aggregate)
aggregates.sort(key=lambda a: a["episode_id"])
review_rows = verify_reviewed_csv(p / "adjudicated/reviewed-results.csv", aggregates, judges, episodes)
checks["review_csv_recomputed"] = len(review_rows) == len(aggregates)
checks["no_pending_semantic_reviews"] = not any(r["pending_candidates"] for r in review_rows)
checks["ai_role_honest"] = all(v["reviewer_role"] == "primary_ai_reviewer" for r in review_rows for v in r["reviews"])
# Runtime follows the frozen Case order; Aggregate serializes by artifact ID.
# Compare full rows by identity and retain a length/uniqueness check.
raw_terminals, reviewed_terminals = raw_manifest["runtime_terminals"], final_manifest["runtime_terminals"]
checks["runtime_inventory_not_filtered"] = (
    len(raw_terminals) == len(reviewed_terminals) == len(runtime["terminals"]) == 48
    and len({r["case_id"] for r in raw_terminals}) == 48
    and raw_terminals == reviewed_terminals
    and {r["case_id"]: r for r in raw_terminals} == {r["case_id"]: r for r in runtime["terminals"]}
)
summary = read(p / "report/summary.json")
checks["report_case_inventory"] = [r["case_id"] for r in summary["cases"]] == runtime["selected_case_ids"]
for track in plan["execution"]["expected_track_counts"]:
    selected = [r for r in review_rows if r["track"] == track]
    scored = [r for r in selected if r["reviewed_score"] is not None]
    expected_passes = sum(r["reviewed_outcome"] == "pass" for r in selected)
    observed = summary["tracks"][track]
    checks[f"report_counts:{track}"] = observed["expected_cases"] == 12 and observed["score_count"] == len(scored) and observed["pass_count"] == expected_passes and observed["pass_rate_all_cases"] == expected_passes / 12
    checks[f"report_mean:{track}"] = abs(observed["reviewed_score_mean"] - sum(r["reviewed_score"] for r in scored) / len(scored)) < 1e-9 if scored else observed["reviewed_score_mean"] is None
before, final = read(p / "budget-before.json"), read(p / "budget-final.json")
checks["original_330_requests_preserved"] = len(before["requests"]) == 330 and final["requests"][:330] == before["requests"]
checks["authorized_cumulative_limit"] = before["limit_micro_cny"] == 14_000_000 and final["limit_micro_cny"] == 19_000_000
checks["budget_not_exceeded"] = sum(r["charged_micro_cny"] for r in final["requests"]) <= final["limit_micro_cny"]
checks["no_active_reservations"] = not any(r["status"] == "reserved" for r in final["requests"])
for row in final["requests"][330:]:
    if row["status"] == "settled":
        usage = row["token_usage"]
        checks[f"usage_charge:{row['ticket']}"] = row["charged_micro_cny"] == usage["prompt_tokens"] + 4 * usage["completion_tokens"]
    else:
        checks[f"unknown_usage_reservation:{row['ticket']}"] = row["status"] == "unknown_usage_reserved" and row["charged_micro_cny"] == row["input_limit"] + 4 * row["output_limit"]
attempts = [json.loads(line) for line in (p / "judge-attempts.jsonl").read_text().splitlines()]
for index, attempt in enumerate(attempts):
    checks[f"judge_attempt_digest:{index}"] = sha256_digest({k: v for k, v in attempt.items() if k != "record_sha256"}) == attempt["record_sha256"]
checks["judge_paid_attempt_inventory"] = sorted(a["budget_ticket"] for a in attempts if a["provider_attempted"]) == sorted(r["ticket"] for r in final["requests"][436:])
checks["agent_paid_attempt_inventory"] = sum(len(e["environment"]["provider_attestation"]["calls"]) for e in episodes.values()) == len(final["requests"][330:436]) == 106
report = {
    "reviewer_role": "primary_ai_reviewer", "independent_human_review": False,
    "scope": "Artifact integrity, fixed denominators, arithmetic, fee and isolation self-audit; not proof that all frozen rules measure the intended capability.",
    "machine_formal_capability_result": final_manifest["formal_capability_result"],
    "method_revision_required": True,
    "checks_passed": sum(checks.values()), "checks_total": len(checks),
    "all_checks_passed": all(checks.values()), "checks": checks,
}
(p / "ai-audit.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({k: v for k, v in report.items() if k != "checks"}, ensure_ascii=False))
if not all(checks.values()):
    raise SystemExit("failed audit checks: " + str([k for k, v in checks.items() if not v]))
