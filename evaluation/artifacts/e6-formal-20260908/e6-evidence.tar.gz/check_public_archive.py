"""Read-only checks of the prospective public E6 evidence and unchanged sources."""
import hashlib,json,subprocess
from pathlib import Path
from dotenv import dotenv_values
from learning_agent_eval.privacy import privacy_issues
p=Path(__file__).parent
origin=Path('/root/workspace/tencent_rhinobird2026/learning_travel')
clone=Path('/tmp/learning-travel-e6-run-20260908')
ledger=Path('/root/.local/state/learning-travel/e4-hy3-20260905-osj4FCZZ-budget.json')
digest=lambda b:hashlib.sha256(b).hexdigest()
key=(dotenv_values(origin/'.env').get('OPENAI_API_KEY') or '').encode()
assert key
violations=[];files=0;json_values=0
for f in sorted(p.rglob('*')):
 if not f.is_file():continue
 files+=1;raw=f.read_bytes()
 if key in raw:violations.append({'file':str(f.relative_to(p)),'issue':'exact_credential_match'})
 if f.name=='.env' or f.suffix in ('.sqlite','.db','.sqlite3') or f.is_symlink():violations.append({'file':str(f.relative_to(p)),'issue':'prohibited_file'})
 if f.suffix in ('.json','.jsonl'):
  values=[json.loads(line) for line in raw.decode().splitlines()] if f.suffix=='.jsonl' else [json.loads(raw)]
  for value in values:
   json_values+=1
   violations.extend({'file':str(f.relative_to(p)),'issue':i.code,'path':i.path} for i in privacy_issues(value))
paths=['backend/app','evaluation/src','evaluation/releases','evaluation/resources','evaluation/case-design','evaluation/artifacts/e5-acceptance-20260906','evaluation/artifacts/e6-readiness-20260906']
unchanged=subprocess.check_output(['git','diff','--name-only','b0b0d02','--',*paths],cwd=origin,text=True)==''
dataset_changes=subprocess.check_output(['git','diff','--name-only','b0b0d02','--','evaluation/datasets/decisionbench-v1-e6-test'],cwd=origin,text=True).splitlines()
checks={'source_releases_case_design_old_archives_unchanged':unchanged,'frozen_dataset_only_readme_changed':dataset_changes==['evaluation/datasets/decisionbench-v1-e6-test/README.md'],'execution_clone_clean_b0b0d02':subprocess.check_output(['git','status','--porcelain'],cwd=clone,text=True)=='' and subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone,text=True).strip()=='b0b0d02ced10c3c6387a6541656a7b693571e312','clone_without_env_or_product_data':not (clone/'.env').exists() and not (clone/'data').exists(),'ledger_final_bytes_unchanged':ledger.read_bytes()==(p/'budget-final.json').read_bytes(),'ledger_final_sha_expected':digest(ledger.read_bytes())=='ce197264adea65dadcfb53a70c64cb8531e8a51499777671e26f60f266fb724c','public_privacy_scan_passed':not violations}
report={'scope':'prospective evidence in external output directory, exact key checked in memory only','files_checked':files,'json_values_checked':json_values,'violations':violations,'checks':checks,'all_checks_passed':all(checks.values()),'real_model_calls':0}
(p/'public-archive-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False))
assert report['all_checks_passed']
