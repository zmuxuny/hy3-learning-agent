"""Archive selected public E6 evidence with raw-byte hashes; no model calls."""
import hashlib,json,tarfile
from pathlib import Path
p=Path(__file__).parent
archive=Path('/root/workspace/tencent_rhinobird2026/learning_travel/evaluation/artifacts/e6-formal-20260908/e6-evidence.tar.gz')
directories=['runtime','rules','judge','aggregate','adjudicated','report','logs']
files=[f for d in directories for f in (p/d).rglob('*') if f.is_file()]
names=['budget-before.json','budget-after-authorization.json','budget-authorization.json','price-verification.json','budget-after-runtime.json','budget-final.json','budget-summary.json','run-plan-v2.json','run_stage.py','judge-attempts.jsonl','judge-attempt-summary.json','case-content-notes.json','case-content-notes-v1-partial-trace.json','semantic-decisions.json','semantic-decisions-v1-partial-trace.json','semantic-reviews.json','compile_semantic_reviews.py','build_case_analysis.py','case-analysis.json','unexecuted-call-audit.json','review-development-correction.json','audit_run.py','audit_run-v1-order-assumption.py','ai-audit.json','ai-audit-v1-order-assumption.json','audit-development-correction.json','check_review_tampering.py','review-tamper-check.json','check_public_archive.py','public-archive-check.json','summarize_e6_run.py','test_e6_summary.py','validation-summary.json','package_evidence.py']
files+= [p/n for n in names]
assert len(files)==len(set(files))
manifest={'manifest_version':'e6-public-evidence-files-v1','hash_type':'sha256_raw_file_bytes','files':{str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(files)},'excluded':'No env, product data, SQLite, private reasoning, capture, expanded Judge prompts or provider-private package. Invalid truncated text has hash/count only.'}
f=p/'evidence-manifest.json';f.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');files.append(f)
with tarfile.open(archive,'w:gz') as tar:
 for f in sorted(files):
  assert not f.is_symlink()
  tar.add(f,arcname=str(f.relative_to(p)),recursive=False)
print(json.dumps({'archive':str(archive),'files':len(files),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}))
