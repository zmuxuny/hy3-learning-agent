"""Bind manually authored decisions; never infer a verdict from a Judge label."""
import json
from pathlib import Path

from learning_agent_eval.semantic_adjudication import review_candidates, reviewed_results

p = Path(__file__).parent
runtime = json.loads((p / "runtime/run-manifest.json").read_text())
json.loads((p / "judge/run-manifest.json").read_text())  # Require finished batch.
decisions = json.loads((p / "semantic-decisions.json").read_text())
episodes = {f.stem: json.loads(f.read_text()) for f in (p / "runtime/episodes").glob("*.json")}
judges = {f.stem: json.loads(f.read_text()) for f in (p / "judge/judge-results").glob("*.json")}
reviews = []
for terminal in runtime["terminals"]:
    case_id, identity = terminal["case_id"], terminal["artifact_id"]
    if terminal["terminal_kind"] != "episode":
        continue
    episode, judge = episodes[identity], judges[identity]
    authored = decisions.get(case_id, {})
    candidates = review_candidates(judge)
    if set(candidates) - set(authored):
        raise ValueError(f"unreviewed_candidates:{case_id}:{sorted(set(candidates) - set(authored))}")
    for candidate, decision in authored.items():
        reviews.append({
            "episode_id": identity,
            "episode_sha256": episode["provenance"]["episode_sha256"],
            "judge_result_sha256": judge["result_sha256"],
            "candidate_id": candidate,
            "reviewer_role": "primary_ai_reviewer",
            **decision,
        })
if set(decisions) - {t["case_id"] for t in runtime["terminals"]}:
    raise ValueError("unknown_review_case")
reviewed_results([], judges, episodes, reviews)
with (p / "semantic-reviews.json").open("x") as handle:
    json.dump(reviews, handle, ensure_ascii=False, indent=2)
    handle.write("\n")
print(json.dumps({"bound_reviews": len(reviews), "confirmed": sum(r["verdict"] == "confirmed_critical" for r in reviews)}))
