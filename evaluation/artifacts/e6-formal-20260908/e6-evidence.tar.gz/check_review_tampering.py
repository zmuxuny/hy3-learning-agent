"""Reject edited scores and omitted failure rows in a copy of the actual E6 CSV."""
import csv,json,tempfile
from pathlib import Path
from learning_agent_eval.semantic_adjudication import verify_reviewed_csv
p=Path(__file__).parent
read=lambda f:json.loads(f.read_text())
episodes={d['episode_id']:d for d in map(read,(p/'runtime/episodes').glob('*.json'))}
judges={d['episode_id']:d for d in map(read,(p/'judge/judge-results').glob('*.json'))}
aggregates=sorted(map(read,(p/'adjudicated/episodes').glob('*.json')),key=lambda a:a['episode_id'])
with (p/'adjudicated/reviewed-results.csv').open() as f:
 reader=csv.DictReader(f);fields=reader.fieldnames;rows=list(reader)
results={}
with tempfile.TemporaryDirectory(prefix='learning-travel-e6-tamper-') as tmp:
 for mode in ('change_scored_value','drop_judge_error_row'):
  changed=[dict(r) for r in rows]
  if mode=='change_scored_value':
   target=next(r for r in changed if r['reviewed_score'])
   target['reviewed_score']=str(float(target['reviewed_score'])+1)
  else:
   index=next(i for i,r in enumerate(changed) if r['reviewed_outcome']=='judge_error')
   changed.pop(index)
  dest=Path(tmp)/f'{mode}.csv'
  with dest.open('w',newline='') as f:
   writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(changed)
  try:
   verify_reviewed_csv(dest,aggregates,judges,episodes)
  except ValueError as exc:
   results[mode]={'rejected':True,'reason':str(exc)}
  else:results[mode]={'rejected':False}
report={'scope':'offline copies of actual E6 reviewed CSV, original unchanged','real_model_calls':0,'checks':results,'all_checks_passed':all(r['rejected'] for r in results.values())}
(p/'review-tamper-check.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
assert report['all_checks_passed']
