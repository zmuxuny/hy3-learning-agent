"""Invoke a frozen CLI from an external clean clone, injecting only the Hy3 key."""
import json,os,subprocess,sys,time
from pathlib import Path
from dotenv import dotenv_values
origin=Path('/root/workspace/tencent_rhinobird2026/learning_travel')
clone=Path('/tmp/learning-travel-e6-run-20260908')
out=Path('/tmp/learning-travel-e6-output-20260908')
ledger='/root/.local/state/learning-travel/e4-hy3-20260905-osj4FCZZ-budget.json'
stage=sys.argv[1]
commands={
 'runtime':['run-agent','--dataset','evaluation/datasets/decisionbench-v1-e6-test','--manifest','evaluation/datasets/decisionbench-v1-e6-test/manifest.json','--output',str(out/'runtime'),'--model-mode','real','--allow-real-model','--budget-ledger',ledger],
 'rules':['evaluate-rules','--input',str(out/'runtime'),'--output',str(out/'rules')],
 'judge':['evaluate-judge','--episodes',str(out/'runtime'),'--rules',str(out/'rules'),'--output',str(out/'judge'),'--judge-mode','real','--allow-real-judge','--budget-ledger',ledger],
 'aggregate':['aggregate-results','--episodes',str(out/'runtime'),'--rules',str(out/'rules'),'--judges',str(out/'judge'),'--output',str(out/'aggregate')],
 'adjudicated':['aggregate-results','--episodes',str(out/'runtime'),'--rules',str(out/'rules'),'--judges',str(out/'judge'),'--output',str(out/'adjudicated'),'--semantic-reviews',str(out/'semantic-reviews.json')],
}
env=os.environ.copy();env['PYTHONPATH']=str(clone/'evaluation/src')
if stage in ('runtime','judge'):
 env['OPENAI_API_KEY']=dotenv_values(origin/'.env').get('OPENAI_API_KEY') or env.get('OPENAI_API_KEY','')
 assert env['OPENAI_API_KEY']
else:env.pop('OPENAI_API_KEY',None)
started=time.time()
with (out/'logs'/f'{stage}.log').open('x') as log:
 result=subprocess.run([sys.executable,'-m','learning_agent_eval',*commands[stage]],cwd=clone,env=env,stdout=log,stderr=subprocess.STDOUT)
record={'stage':stage,'exit_code':result.returncode,'seconds':round(time.time()-started,3),'command':['python','-m','learning_agent_eval',*commands[stage]],'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=clone,text=True).strip()}
(out/'logs'/f'{stage}-execution.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
raise SystemExit(result.returncode)
