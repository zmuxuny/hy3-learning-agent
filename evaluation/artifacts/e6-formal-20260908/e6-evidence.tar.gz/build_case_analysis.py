"""Join AI content observations to complete public traces and frozen scores."""
import json
from collections import Counter
from pathlib import Path

from learning_agent_eval.canonical import sha256_digest
from learning_agent_eval.validator import resolve_evidence_path

p = Path(__file__).parent


def read(path):
    return json.loads(path.read_text())


manifest = read(p / "runtime/run-manifest.json")
notes = read(p / "case-content-notes.json")
unexecuted = read(p / "unexecuted-call-audit.json")["rows"]
rows = []
for terminal in manifest["terminals"]:
    case, identity = terminal["case_id"], terminal["artifact_id"]
    episode = read(p / "runtime/episodes" / f"{identity}.json")
    rule = read(p / "rules/rules" / f"{identity}.json")
    judge = read(p / "judge/judge-results" / f"{identity}.json")
    paths = ["result", "observable_trace.model_calls", "observable_trace.tool_invocations", "state_delta"]
    assert all(resolve_evidence_path(episode, path)[0] for path in paths)
    rows.append({
        "case_id": case,
        "case_spec_sha256": terminal["case_spec_sha256"],
        "episode_id": identity,
        "episode_sha256": terminal["artifact_sha256"],
        "rule_result_sha256": rule["result_sha256"],
        "judge_result_sha256": judge["result_sha256"],
        "track": episode["track"],
        "reviewer_role": "primary_ai_reviewer",
        "content_observation": notes[case],
        "evidence_paths": paths,
        "classification_issues": episode["result"]["classification_issues"],
        "action_class": episode["result"]["action_class"],
        "run_status": episode["result"]["layers"]["run_status"],
        "durable_status": episode["result"]["layers"]["durable_status"],
        "guard_status": episode["result"]["guard"]["status"],
        "actual_hard_gates": rule["hard_gates"],
        "rule_failures": [{k: c[k] for k in ("check_id", "severity", "reason_code")} for c in rule["checks"] if c["status"] == "fail"],
        "tool_failures": [{"index": i, "tool": t["tool_name"], "status": t["execution_status"], "observation": t["observation_status"]} for i, t in enumerate(episode["observable_trace"]["tool_invocations"]) if t["execution_status"] == "failed"],
        "returned_unexecuted_calls": [item for item in unexecuted if item["episode_sha256"] == terminal["artifact_sha256"]],
    })
assert len(rows) == 48 and set(notes) == {r["case_id"] for r in rows}
document = {
    "analysis_version": "e6-ai-content-analysis-v2-full-returned-trace",
    "reviewer_role": "primary_ai_reviewer",
    "independent_human_review": False,
    "purpose": "Posthoc attribution; does not replace frozen scores or supply independent gold labels.",
    "review_correction_record": "review-development-correction.json",
    "method_revision_required": True,
    "method_findings": [
        {"finding": "in_app receipt rules require an external delivery chain", "cases": ["formal-f02-i", "formal-f04-i", "formal-f10-i"]},
        {"finding": "deferred assessment has zero submission changes/Operations but hits alignment and verdict gates", "cases": [r["case_id"] for r in rows if r["track"] == "assessment" and r["run_status"] == "waiting_approval"]},
        {"finding": "returned but unexecuted proposal content must be distinguished from absent proposal entities", "cases": ["formal-f01-p", "formal-f07-p", "formal-f10-p", "formal-f12-p"]},
        {"finding": "AI review identifies UTC/local quiet-hour mistakes despite Judge D1/D7 level 2; original scores retained, not independent gold labels", "cases": ["formal-f09-i", "formal-f12-i"]},
    ],
    "observed_counts": {
        "cases": 48,
        "rule_hard_gate_cases": sum(bool(r["actual_hard_gates"]) for r in rows),
        "classification_issue_cases": sum(bool(r["classification_issues"]) for r in rows),
        "classification_issue_counts": dict(Counter(issue for row in rows for issue in row["classification_issues"])),
        "run_status_counts": dict(Counter(row["run_status"] for row in rows)),
        "failed_tool_invocations": sum(len(row["tool_failures"]) for row in rows),
        "returned_unexecuted_calls": len(unexecuted),
    },
    "rows": rows,
}
document["analysis_sha256"] = sha256_digest(document)
with (p / "case-analysis.json").open("x") as handle:
    json.dump(document, handle, ensure_ascii=False, indent=2)
    handle.write("\n")
print(json.dumps(document["observed_counts"]))
