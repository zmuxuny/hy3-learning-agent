import json,hashlib
from pathlib import Path
root=Path('/root/workspace/tencent_rhinobird2026/learning_travel');out=Path('/tmp/learning-travel-mainline-0tqjp9d1')
from learning_agent_eval.learning_quality import METHOD,METHOD_SHA256
from learning_agent_eval.canonical import canonical_json_bytes,sha256_digest
cal=root/'evaluation/datasets/learning-quality-validation-v1'
design=dict(version='learning-quality-experiment-v1',method=METHOD,method_sha256=METHOD_SHA256,method_commit='ee9151e',
 product='Restored bf06d36 prompt; application evaluated here through archived real trajectories from 35e77cf, not regenerated current product',
 validation=dict(suite_sha256=sha256_digest(json.loads((cal/'suite.json').read_text())),labels_sha256=sha256_digest(json.loads((cal/'private-labels.json').read_text())),
   groups=8,outputs=24,repeats=3,slots=72,targets={'strict_triplet_ordering':'>=75% of complete groups','good_above_severe':'>=90%','mean_population_score_sd':'<=5'},
   execution_order='repeat 1,2,3; within each repeat fixed family then tier; two independent family shards'),
 full=dict(suite_sha256=sha256_digest(json.loads((out/'full/suite.json').read_text())),slots=48,real_episodes=47,runtime_failures=1,repeats=1,
   execution_order='two fixed id halves, each lexical order',meaning='same-method replay of all original real outputs, including historical runtime failure'),
 retries=0,review='Every response and deduction checked against source evidence; original automatic ratings retained separately from any adjudication',
 selection='Development controls already seen. Constructed calibration is a small purpose-built validation set, not a representative population.',
 comparison='E7 product comparison suspended; no product score improvement claim',
 budget='Unique existing ledger; no new authorization, no hidden retries. Prior development failures preserved.')
(out/'design.json').write_bytes(canonical_json_bytes(design))
print(METHOD_SHA256)
