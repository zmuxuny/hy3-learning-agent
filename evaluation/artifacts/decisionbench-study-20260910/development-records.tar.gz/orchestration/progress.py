from pathlib import Path
import json
from collections import Counter
root=Path(__file__).parent
for name in ['dev-final','dev-corrected','validation-results-0','validation-results-1','full-results-0','full-results-1']:
 p=root/name/'results.json'
 if p.exists():
  s=json.loads(p.read_text());rows=s['rows'];print(name,len(rows),dict(Counter(r['status'] for r in rows)),[(r['id'],r.get('score')) for r in rows[-2:]])
