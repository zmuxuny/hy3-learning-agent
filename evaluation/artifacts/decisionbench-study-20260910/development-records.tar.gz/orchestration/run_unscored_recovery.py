import sys
from pathlib import Path
from dotenv import load_dotenv
load_dotenv('/root/workspace/tencent_rhinobird2026/learning_travel/.env',override=True)
sys.path.insert(0,str(Path.cwd()/'evaluation/scripts'))
from recover_quality_unscored import recover
recover(Path('/tmp/learning-travel-mainline-0tqjp9d1/final-experiment'),Path('/root/.local/state/learning-travel/e4-hy3-20260905-osj4FCZZ-budget.json'),int(sys.argv[1]),4)
