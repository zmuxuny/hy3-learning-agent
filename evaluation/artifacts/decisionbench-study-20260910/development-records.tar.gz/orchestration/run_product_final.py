import sys,json
from pathlib import Path
from dotenv import load_dotenv
load_dotenv('/root/workspace/tencent_rhinobird2026/learning_travel/.env',override=True)
from learning_agent_eval.active_runtime import run_active_runtime,episode_id_for_case
from learning_agent_eval.canonical import canonical_json_bytes
root=Path('/tmp/learning-travel-mainline-0tqjp9d1');dataset=Path('evaluation/datasets/decisionbench-learning-v1/application')
track=sys.argv[1];cases=sorted([json.loads(p.read_text()) for p in (dataset/'cases').glob('*.json') if json.loads(p.read_text())['track']==track],key=lambda x:x['case_id'])
rows=[];out=root/'product-final';out.mkdir(exist_ok=True)
for case in cases:
 row={'id':case['case_id'],'track':track,'attempts':[]};rows.append(row)
 for attempt in [1,2]:
  target=out/(case['case_id']+f'-attempt-{attempt}')
  try:
   result=run_active_runtime(dataset=dataset,manifest=dataset/'manifest.json',output=target,episode_ids={episode_id_for_case(case)},model_mode='real',allow_real_model=True,worker_timeout_seconds=600,budget_ledger='/root/.local/state/learning-travel/e4-hy3-20260905-osj4FCZZ-budget.json')
   failures=list(getattr(result,'failure_ids',()));row['attempts'].append({'number':attempt,'output':target.name,'status':'runtime_failure' if failures else 'complete'})
  except Exception as exc:
   row['attempts'].append({'number':attempt,'output':target.name,'status':'execution_error','error':type(exc).__name__+': '+str(exc)[:300]})
  (out/(track+'.json')).write_bytes(canonical_json_bytes(rows))
  print(row['id'],row['attempts'][-1],flush=True)
  if row['attempts'][-1]['status']=='complete':break
