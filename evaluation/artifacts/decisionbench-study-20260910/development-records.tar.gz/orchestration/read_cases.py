import json,pathlib,sys,re
w=pathlib.Path('/tmp/learning-travel-mainline-0tqjp9d1/final-experiment');track=sys.argv[1];start=int(sys.argv[2]);end=int(sys.argv[3])
for n in range(start,end+1):
 identity=f'formal-i{n:02}-{track}';e=json.loads((w/'full/evidence'/f'{identity}.json').read_text());print('\nCASE',identity);print('TRIGGER',e['trigger']['objective']);seen=set()
 for i,call in enumerate(e['observable_trace']['model_calls']):
  for j,m in enumerate(call.get('visible_context',{}).get('messages',[])):
   if m.get('role')=='user':
    text=m['payload'].get('content','')
    text=re.sub(r"'available_resource_catalog':.*?(?=\n- Quiet hours)",'[重复资源目录省略]',text,flags=re.S)
    if text not in seen:print('USER',i,j,text);seen.add(text)
  if call.get('assistant_text'):print('ASSISTANT',i,call['assistant_text'])
  if call.get('returned_tool_calls'):print('CALLS',i,json.dumps(call['returned_tool_calls'],ensure_ascii=False))
 print('EFFECT',json.dumps({k:v for k,v in e['result'].get('layers',{}).items() if k in ['durable_status','run_status','final_effects']},ensure_ascii=False));print('BUSINESS DELTA',json.dumps([c for c in e['state_delta']['changes'] if c.get('entity_ref') in {v['logical_id'] for v in e['state_after']['logical_entities'] if v['entity_type'] in ['plan','task','submission','notification','intervention']}],ensure_ascii=False))
 for p in w.glob('*results*/results.json'):
  for r in json.loads(p.read_text())['rows']:
   if r['id']==identity:
    recovery=w/'ingestion-recovery'/f'full-{identity}-1/results.json'
    if recovery.exists():r=json.loads(recovery.read_text())
    print('RATING',r['status'],r.get('score'),json.dumps({k:v for k,v in (r.get('rating') or {}).items() if k!='checks'},ensure_ascii=False))
