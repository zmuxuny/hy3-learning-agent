from pathlib import Path
import json,sys,shutil
sys.path.insert(0,str(Path.cwd()/'evaluation/scripts'))
from learning_agent_eval.active_rules import evaluate_active_rules
from prepare_learning_quality import export
from learning_agent_eval.canonical import canonical_json_bytes
r=Path('/tmp/learning-travel-mainline-0tqjp9d1');stage=r/'product-export';stage.mkdir(exist_ok=True);out=r/'final-experiment/full';out.mkdir(parents=True,exist_ok=True)
(out/'evidence').mkdir(exist_ok=True);(out/'sources').mkdir(exist_ok=True);specs=[];selection=[]
for p in sorted((r/'product-final').glob('*.json')):
 for row in json.loads(p.read_text()):
  chosen=next((a for a in row['attempts'] if a['status']=='complete'),None);base=r/'product-final'
  if chosen is None:
   recovery=json.loads((r/'product-final-recovery/assessment.json').read_text());rr=next(x for x in recovery if x['id']==row['id']);chosen=next(a for a in rr['attempts'] if a['status']=='complete');base=r/'product-final-recovery'
  case=row['id'];run=stage/case;run.mkdir(exist_ok=True)
  if (run/'runtime').is_symlink():(run/'runtime').unlink()
  shutil.copytree(base/chosen['output'],run/'runtime',dirs_exist_ok=True)
  evaluate_active_rules(input_path=run/'runtime',output=run/'rules')
  exported=stage/(case+'-public');export(run,exported,'current-real-application')
  ss=json.loads((exported/'suite.json').read_text());assert len(ss)==1;specs.extend(ss)
  shutil.copytree(exported/'evidence',out/'evidence',dirs_exist_ok=True)
  shutil.copytree(exported/'sources',out/'sources'/case)
  selection.append({'id':case,'source':str((base/chosen['output']).relative_to(r)),'attempt':chosen['number']})
(out/'suite.json').write_bytes(canonical_json_bytes(sorted(specs,key=lambda x:x['id'])))
(out/'selection.json').write_bytes(canonical_json_bytes(selection));print('selected',len(specs))
