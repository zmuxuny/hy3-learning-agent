import sys,json
from pathlib import Path
from dotenv import load_dotenv
load_dotenv('/root/workspace/tencent_rhinobird2026/learning_travel/.env',override=True)
sys.path.insert(0,'/tmp/learning-travel-mainline-0tqjp9d1/final-source/evaluation/scripts')
from run_learning_quality import run
from learning_agent_eval.learning_quality import METHOD_SHA256
root=Path('/tmp/learning-travel-mainline-0tqjp9d1');kind=sys.argv[1];shard=int(sys.argv[2])
design=json.loads((root/'design.json').read_text());assert design['method_sha256']==METHOD_SHA256
suite=root/'full/suite.json' if kind=='full' else Path('/root/workspace/tencent_rhinobird2026/learning_travel/evaluation/datasets/learning-quality-validation-v1/suite.json')
rows=json.loads(suite.read_text());ids=[r['id'] for r in rows];half=len(ids)//2;chosen=ids[:half] if shard==0 else ids[half:]
run(suite,root/f'{kind}-results-{shard}',Path('/root/.local/state/learning-travel/e4-hy3-20260905-osj4FCZZ-budget.json'),chosen,1 if kind=='full' else 3)
