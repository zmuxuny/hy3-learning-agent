import sys,json
from pathlib import Path
from dotenv import load_dotenv
load_dotenv('/root/workspace/tencent_rhinobird2026/learning_travel/.env',override=True)
sys.path.insert(0,str(Path.cwd()/'evaluation/scripts'))
from run_learning_quality import run
root=Path('/tmp/learning-travel-mainline-0tqjp9d1')
groups=[['formal-i02-p','formal-i04-p','formal-i09-p'],['formal-i02-i','formal-i12-i','formal-i01-r'],['formal-i03-r','formal-i11-a','formal-i07-a']]
i=int(sys.argv[1]);run(root/'full/suite.json',root/f'dev3-{i}',Path('/root/.local/state/learning-travel/e4-hy3-20260905-osj4FCZZ-budget.json'),groups[i])
