import json,sys
from pathlib import Path
sys.path.insert(0,'/root/workspace/tencent_rhinobird2026/learning_travel/evaluation/src')
from learning_agent_eval.learning_quality import validate_rating,aggregate
root=Path(__file__).parent;kind=sys.argv[1];start=int(sys.argv[2]) if len(sys.argv)>2 else 0;end=int(sys.argv[3]) if len(sys.argv)>3 else 99
old=json.loads((root/'e6/ai_case_notes113.json').read_text())
base=root/'full' if kind=='full' else Path('/root/workspace/tencent_rhinobird2026/learning_travel/evaluation/datasets/learning-quality-validation-v1')
rows=[]
for shard in [0,1]:
 p=root/f'{kind}-results-{shard}/results.json'
 if p.exists():rows.extend(json.loads(p.read_text())['rows'])
for row in sorted(rows,key=lambda r:(r['id'],r['repeat']))[start:end]:
 print('\nCASE',row['id'],'REPEAT',row['repeat'],'STATUS',row['status'])
 if kind=='full':print('PRIOR SOURCE REVIEW',old[row['id']])
 if not row.get('reply',{}).get('content'):continue
 e=json.loads((base/'evidence'/f"{row['id']}.json").read_text())
 try:r=validate_rating(json.loads(row['reply']['content']),e)
 except ValueError as exc:print('INVALID',exc);continue
 print('SCORE',aggregate(r,e),'LEVELS',[d['level'] for d in r['dimensions']])
 print('CHECKS',json.dumps(r['checks'],ensure_ascii=False))
 print('DEDUCTIONS',json.dumps([d for d in r['dimensions'] if d['level']<2],ensure_ascii=False))
 print('SEVERITY',r['severity'],r['severity_reason'])
