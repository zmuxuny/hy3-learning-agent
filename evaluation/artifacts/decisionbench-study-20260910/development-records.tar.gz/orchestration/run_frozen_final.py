import sys,json
from pathlib import Path
from dotenv import load_dotenv
load_dotenv('/root/workspace/tencent_rhinobird2026/learning_travel/.env',override=True)
sys.path.insert(0,str(Path.cwd()/'evaluation/scripts'))
from run_learning_quality import run
from learning_agent_eval.learning_quality import METHOD_SHA256
r=Path('/tmp/learning-travel-mainline-0tqjp9d1/final-experiment');kind=sys.argv[1];shard=int(sys.argv[2]);design=json.loads((r/'design.json').read_text());assert design['method_sha256']==METHOD_SHA256
suite=r/kind/'suite.json';rows=json.loads(suite.read_text());size=len(rows)//4;ids=[s['id'] for s in rows[shard*size:(shard+1)*size]]
run(suite,r/f'{kind}-results-{shard}',Path('/root/.local/state/learning-travel/e4-hy3-20260905-osj4FCZZ-budget.json'),ids,design[kind]['repeats'])
