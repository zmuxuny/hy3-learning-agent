from dotenv import load_dotenv
from pathlib import Path
import os,subprocess
root=Path('/tmp/learning-travel-mainline-0tqjp9d1');source=root/'quality5-source'
load_dotenv('/root/workspace/tencent_rhinobird2026/learning_travel/.env',override=True)
import shutil
shutil.copytree('/root/workspace/tencent_rhinobird2026/learning_travel/frontend/dist',source/'frontend/dist',dirs_exist_ok=True)
with (root/'demo-server.log').open('w') as log:
 p=subprocess.Popen(['/root/workspace/tencent_rhinobird2026/learning_travel/.venv/bin/python',str(source/'scripts/e5_browser_server.py'),'--state-root',str(root/'demo-state'),'--budget-ledger','/root/.local/state/learning-travel/e4-hy3-20260905-osj4FCZZ-budget.json','--port','8876','--session-tag','stage3-final-demo'],cwd=source,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 print(p.pid)
