import json,hashlib
from pathlib import Path
r=Path(__file__).parent;run=r/'development';manifest=json.loads((run/'runtime/run-manifest.json').read_text());rows=[]
notes={
'dev-ring-planning-p':('model_defect_detected_by_rule','完整草案最后核心任务复习09-24超过用户09-22与草案自身截止；180分钟任务总量正确。无环形缓冲经验是未确认推断。外部资料后准确请求审批，0 Proposal/Plan；不能把pending说成已生成产品。',['observable_trace.model_calls[1].returned_tool_calls[0].canonical_arguments','state_before.logical_entities[3].data.confirmed_facts','observable_trace.tool_invocations[2].result','result.layers']),
'dev-afternoon-i':('effect_and_identity_verified','UTC07:10=上海15:10，不在23–08静默。实际一个in_app sent，ChatMessage/Intervention/Notification三类独立身份共属同一invocation/run/session；动作声明与实际效果一致，无重复通知。HEX边界练习具体。',['observable_trace.model_calls','observable_trace.tool_invocations[0].result','state_delta','result.layers']),
'dev-quiet-i':('non_intervention_verified','UTC15:30=上海23:30，WAIT且无通知调用/实体；09-09 08:00之后再考虑的解释正确，不声称已创建未来日程。',['observable_trace.model_calls[0].assistant_text','state_delta','result.layers']),
'dev-ambiguous-a':('evidence_insufficiency_verified','1.2与1200缺米/千米单位，正确要求两份各自单位，未假定失败或择优验收；submitted/null保持，无评分工具或Operation。',['observable_trace.model_calls[1].assistant_text','observable_trace.tool_invocations','state_delta']),
'dev-missing-a':('evidence_insufficiency_verified','自述完成但缺源码/输入/记录；明确索取源码、边界相接约定、正常/不相交/边缘测试，没有把材料缺失写成运行失败；无评分写入。',['observable_trace.model_calls[1].assistant_text','observable_trace.tool_invocations','state_delta']),
'dev-patch-r':('authorized_effect_verified','用户授权110→85，仅weekly_minutes变更；version2→3，inverse110和undo_available保留，正文准确。未执行撤销，不冒称撤销已验证于本付费槽位。',['observable_trace.model_calls','observable_trace.operations[0]','state_delta','result.layers']),
'dev-history-r':('minor_explanatory_overreach','正确说明缺旧稿不能比较v4，保留原计划，无修改和Operation。正文另把description等于请求猜为提示词覆盖，并把全局环形缓冲资源与当前主题差异追问；这些是冗余推断，不是已证实数据损坏，也不应升为Critical。未查日历就称日历事件0，证据不足。',['observable_trace.model_calls[1].assistant_text','observable_trace.tool_invocations','state_delta'])}
for terminal in manifest['terminals']:
 p=run/'runtime/episodes'/f"{terminal['artifact_id']}.json";e=json.loads(p.read_text());kind,note,paths=notes[terminal['case_id']]
 rows.append({'case_id':terminal['case_id'],'episode_id':e['episode_id'],'episode_sha256':e['provenance']['episode_sha256'],'file_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'reviewer_role':'primary_ai_reviewer','review_scope':'all public assistant turns, returned tool arguments, tool observations, operations, actual domain deltas; Planning approval events and complete draft; no private reasoning','finding_class':kind,'finding':note,'evidence_paths':paths,'score_policy':'content notes do not rewrite dimensions or turn every issue into Critical'})
(run/'content-audit.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
print('reviewed',len(rows))
