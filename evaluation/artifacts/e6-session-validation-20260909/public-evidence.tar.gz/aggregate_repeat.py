import json,os,subprocess,time
from pathlib import Path
r=Path(__file__).parent;c=r/'run-copy';run=r/'calibration';m=json.loads((run/'runtime/run-manifest.json').read_text());cmd=['/root/workspace/tencent_rhinobird2026/learning_travel/.venv/bin/python','-m','learning_agent_eval','aggregate-results','--episodes',str(run/'runtime'),'--rules',str(run/'rules'),'--judges',str(run/'repeat-judge'),'--output',str(run/'repeat-aggregate')]
for x in m['terminals']:
 if x['case_id'].endswith('-good'):cmd+=['--episode-id',x['artifact_id']]
start=time.time();env={**os.environ,'PYTHONPATH':str(c/'evaluation/src')+':'+str(c/'backend'),'PYTHONDONTWRITEBYTECODE':'1'}
with (r/'repeat-aggregate.log').open('x') as log:p=subprocess.run(cmd,cwd=c,env=env,stdout=log,stderr=subprocess.STDOUT)
(r/'repeat-aggregate.execution.json').write_text(json.dumps({'command':cmd,'seconds':time.time()-start,'exit_code':p.returncode},indent=2));print(p.returncode)
