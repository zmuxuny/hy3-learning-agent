import os,sys,json,subprocess,time
from pathlib import Path
r=Path(__file__).parent;c=r/'test-copy';label=sys.argv[1];env={**os.environ,'PYTHONPATH':str(c/'evaluation/src')+':'+str(c/'backend'),'PYTHONDONTWRITEBYTECODE':'1'}
cmd=['/root/workspace/tencent_rhinobird2026/learning_travel/.venv/bin/python','-m','pytest','-q','tests/test_e6_session_scope.py','tests/test_e6_deadline_runtime.py','tests/test_e6_deadline_constraints.py','tests/test_planning_card_snapshots.py','evaluation/tests/test_e6_audit_fixes.py','evaluation/tests/test_e6_final_repairs.py','evaluation/tests/test_e6_repairs.py','evaluation/tests/test_e6_message_identity.py','--basetemp',str(r/('pytest-'+label))]
start=time.time()
with (r/(label+'.log')).open('x') as log:p=subprocess.run(cmd,cwd=c,env=env,stdout=log,stderr=subprocess.STDOUT)
(r/(label+'.json')).write_text(json.dumps({'command':cmd,'exit_code':p.returncode,'seconds':time.time()-start},indent=2));print(p.returncode)
