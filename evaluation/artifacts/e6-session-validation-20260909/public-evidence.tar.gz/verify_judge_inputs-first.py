import json,hashlib
from pathlib import Path
from learning_agent_eval.blinding_v2 import build_blind_judge_input_v3
from learning_agent_eval.active_judge import build_provider_request_v3
from learning_agent_eval.judge_request_projection import unpack_shared_values
from learning_agent_eval.canonical import canonical_json_bytes
r=Path(__file__).parent;rows=[]
for batch in ['development','calibration']:
 for p in sorted((r/batch/'runtime/episodes').glob('*.json')):
  e=json.loads(p.read_text());identity=e['episode_id'];rules=json.loads((r/batch/'rules/rules'/p.name).read_text());ref=json.loads((r/batch/'runtime/judge-references'/p.name).read_text());blind=build_blind_judge_input_v3(e,rules,ref);req=build_provider_request_v3(blind);wire=json.loads(req['messages'][1]['content']);assert unpack_shared_values(wire)==blind.document
  rows.append({'batch':batch,'episode_id':identity,'episode_sha256':e['provenance']['episode_sha256'],'blind_input_sha256':blind.sha256,'lossless_roundtrip':True,'provider_request_bytes_without_transport_config':len(canonical_json_bytes(req)),'path_catalog_size':len(wire['evidence_path_catalog']),'draft_aid_present':len(req['messages'])>2,'retained_returned_tool_calls':all('returned_tool_calls' in c for c in blind.document['episode']['observable_trace']['model_calls'])})
(r/'judge-input-verification.json').write_text(json.dumps({'scope':'all 19 complete native blind requests, no model call; no truncation','rows':rows},indent=2));print('verified',len(rows),'max_request_bytes',max(x['provider_request_bytes_without_transport_config'] for x in rows))
