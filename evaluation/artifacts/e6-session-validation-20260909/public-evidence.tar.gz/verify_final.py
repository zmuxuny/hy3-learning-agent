import json,hashlib,subprocess,tarfile
from pathlib import Path
from learning_agent_eval.validator import validate_dataset,resolve_evidence_path
r=Path(__file__).parent;c=r/'run-copy';checks=[]
for batch in ['development','calibration']:
 for part in ['runtime','rules','judge','aggregate','adjudicated']+(['repeat-judge','repeat-aggregate'] if batch=='calibration' else []):
  report=validate_dataset(r/batch/part);assert report.ok,[(x.render()) for x in report.issues];checks.append(batch+'/'+part)
 for item in json.loads((r/batch/'content-audit.json').read_text()) if (r/batch/'content-audit.json').exists() else []:
  e=json.loads((r/batch/'runtime/episodes'/f"{item['episode_id']}.json").read_text());assert e['provenance']['episode_sha256']==item['episode_sha256'];assert all(resolve_evidence_path(e,p)[0] for p in item['evidence_paths'])
m=json.loads((r/'source-snapshot-manifest.json').read_text());assert hashlib.sha256((r/'source-eac64bc.tar.gz').read_bytes()).hexdigest()==m['sha256']
with tarfile.open(r/'source-eac64bc.tar.gz') as tar:
 for row in m['files']:
  b=tar.extractfile(row['path']).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
# Original immutable assets remain identical; additions are allowed, mutable README entry points are excluded.
repo=Path('/root/workspace/tencent_rhinobird2026/learning_travel');changes=subprocess.check_output(['git','diff','--name-status','--diff-filter=MD','f47e3a1','--','evaluation/artifacts','evaluation/releases','evaluation/schemas','evaluation/datasets'],cwd=repo,text=True).splitlines();allowed={'evaluation/releases/README.md','evaluation/artifacts/e6-completion-20260909/README.md','evaluation/artifacts/e6-audit-fixes-20260909/README.md'};assert all(x.split('\t')[-1] in allowed for x in changes),changes
result={'validated_directories':checks,'content_review_bindings_valid':True,'source_snapshot_members_verified':len(m['files']),'source_snapshot_sha256':m['sha256'],'immutable_assets_since_f47e3a1_unchanged':True,'old_archive_members_verified':6766,'old_archive_verification':'old-archive-verification.json','modified_old_mutable_entries':changes,'no_new_formal_benchmark_registration':True}
(r/'final-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print('validated',len(checks),'directories and',len(m['files']),'source members')
