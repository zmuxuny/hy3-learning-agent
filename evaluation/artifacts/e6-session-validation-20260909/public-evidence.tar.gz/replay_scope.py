import json,subprocess,importlib.util,hashlib
from pathlib import Path
from copy import deepcopy
from learning_agent_eval.rules import _draft_schedule_checks
r=Path(__file__).parent;repo=r/'run-copy';old=r/'baseline_rules.py';old.write_bytes(subprocess.check_output(['git','show','f47e3a1:evaluation/src/learning_agent_eval/rules.py'],cwd=repo));s=importlib.util.spec_from_file_location('learning_agent_eval._baseline_probe',old);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
p=next((r/'pytest-regressions-fixed').glob('test_other_session_cannot_caus0/collector-scope-episode.json'));fixture_sha=hashlib.sha256(p.read_bytes()).hexdigest();original=json.loads(p.read_text());run=original['observable_trace']['model_calls'][0]['run_id'];session=next(x['data']['session_ref'] for x in original['state_before']['logical_entities'] if x['logical_id']==run);rows=[]
for current,other,expected in [('2026-09-20','2026-09-10','pass'),('2026-09-10','2026-09-30','fail')]:
 for reverse in [False,True]:
  e=deepcopy(original)
  for x in e['state_before']['logical_entities']:
   if x['entity_type']=='planning_intake':x['data']['confirmed_facts'][0]['value']=current if x['data']['session_ref']==session else other
  if reverse:e['state_before']['logical_entities'].reverse()
  before=m._draft_schedule_checks(e);after=_draft_schedule_checks(e);assert after[0]['status']==expected
  rows.append({'current':current,'other':other,'reverse':reverse,'expected':expected,'baseline_checks':before,'new_checks':after})
actual=[]
for p in sorted((r/'frozen-evidence').glob('*/runtime/episodes/*.json')):
 e=json.loads(p.read_text())
 if e['track']!='planning':continue
 checks=_draft_schedule_checks(e);actual.append({'path':str(p.relative_to(r)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'checks':checks})
result={'scope':'isolated deterministic function replay, not new model experiment or replacement scores','protocol':'1.15','baseline':'f47e3a1','fixture_sha256':fixture_sha,'counterexamples':rows,'historical_planning':actual}
(r/'scope-replay.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print('counterexamples',[(x['baseline_checks'][0]['status'],x['new_checks'][0]['status']) for x in rows]);print('historical planning',len(actual),'invalid',sum(c['status']=='invalid_input' for x in actual for c in x['checks']))
