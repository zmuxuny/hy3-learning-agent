import json,shutil
from pathlib import Path
r=Path(__file__).parent;repo=Path('/root/workspace/tencent_rhinobird2026/learning_travel');out=repo/'evaluation/artifacts/e6-session-validation-20260909';out.mkdir(exist_ok=True)
entry='工程活动协议现为 **1.15未登记验证版 / eac64bc**，产品仍为`learning-runtime-e6-audit-1`。跨会话约束归属已修复，真实Collector及Runtime审批回归62项通过；定向真实Development7与Calibration12+4已执行并由主AI审核。Development为5通过/1不通过/1 Judge HTTP429无分；校准四组三档排序与Good重复指标达标。该验证使用已见样本，不是新版正式能力统计。见[本轮验证与交付](../evaluation/artifacts/e6-session-validation-20260909/README.md)。'
for name in ['docs/E6最终修复与验收记录.md','docs/E6接续提示词.md','docs/STATUS.md','docs/ROADMAP.md','docs/腾讯犀牛鸟开源实习第三阶段项目方案.md','docs/腾讯犀牛鸟开源实习第三阶段评测实施方案.md']:
 p=repo/name;s=p.read_text();old='工程补修为Protocol1.14未登记候选，旧实验仍固定1.13；见[审计修复档案](../evaluation/artifacts/e6-audit-fixes-20260909/README.md)。';assert old in s,name;s=s.replace(old,entry,1);p.write_text(s)
p=repo/'docs/E6最终修复与验收记录.md';s=p.read_text();prefix,tail=s.split('起点f47e3a1，工作区干净；',1);tail=tail.replace('- [ ]','- [x]',4);s=prefix+'起点f47e3a1，工作区干净；'+tail
s+='''

### 1.15验证结果与本轮交付

代码及付费前判据提交`eac64bc`。方法版本由1.14升为1.15，保留旧Release；本轮未改产品实现，产品版本保持`learning-runtime-e6-audit-1`。按发出草案的run→session绑定初态Intake及此前同会话成功观察，已知外会话观察不覆盖，未知归属/冲突/重复证据返回invalid_input，不惩罚为模型Critical。真实Collector快照的四组数组顺序重放：旧规则分别fail/pass/pass/fail，新规则pass/pass/fail/fail，修复误罚与漏检。

仓外62项通过；变更/删除×批准/拒绝四条真实Runtime生命周期均先暂停，批准前无写入，批准仅作用当前会话，拒绝保留约束并阻止越界草案。使用合成模型响应和临时库，不把它称为付费模型审批能力。原41份Judge响应225条事实核验有效，三种坏响应拒绝；H/I的22个Planning Episode在新局部规则下无新关联不足，旧分数不回填。

真实Development7全部导出Episode，Judge6有效/1 HTTP429：5通过、1规划越界不通过、1无分。规划最后复习09-24超过用户09-22，Rule与Judge均识别；其草案停在外部资料后的批准前，未创建Proposal/Plan。新校准12首轮及4个Good重复均有效：四组三档分数分别100/87.5/2.5、100/87.5/0、100/95/0、95/87.5/15；严格排序4/4、Good>Severe4/4、严重错误联合召回4/4，Good重复一致100%、平均总体SD0，Mild锚点5/5。此为已见定向验证，未建立或登记1.15新正式家族，不冒称未见能力实验或跨版因果改善。

主AI读完本轮23份Judge尝试记录（22份响应、1份HTTP429），审核7个Agent全部公开正文/工具回执/领域变更，及四个受控严重案例完整动作与实际效果。20个语义候选逐项裁决：6个候选在两个伪造成果案例中确认，14个重复规则或泛化质量问题不另升级；原七维不改。HTTP429与模型错误分开，保留无分及未知usage。解释维度对“可撤销”的要求、待批准状态的扣分表述、宽泛证据路径及未确认经验推断仍是评分/内容边界，不能把路径校验通过当语义核验完全正确。

两个批次summary/CSV从原制品复算逐字节一致；22个有分聚合独立重算七维及39/69封顶一致，19个完整Judge请求规范JSON往返等价，无截断。冻结源码246个成员、12个制品目录、旧6766成员及历史不可变资产核验通过。辅助脚本首次比较把tuple与JSON数组作Python直接相等、两次源码快照路径错误、账本重复槽位scope判断及分析脚本语法失败均另名保留；不属于模型失败，未修改判据或重跑付费槽位。

新增37请求（Agent14/Judge23）占用1.724250元等价估算，累计63.657892元，上限84.393029元、剩余20.735137元。原1515请求及全部授权不变；27条未知usage共5.841159元预留，其中本轮HTTP429预留0.213756元。37条新增请求均与公开证据关联，供应商实扣和实际后端模型仍未独立核实。

**交付判断**：本轮已复现审计代码缺陷、流程覆盖、另版定向验证及归档要求有证据支持；E6工程与实验交付收口。未满足的是正式能力统计资格，以及Development7/7完整有效评分；旧I48和新1.15都不宣称正式能力验收通过。原1.13冻结新家族实验及48分母继续保留，23/18/7不变，H/I不混算。E7/E8与扩展对齐/反事实实验仍未开展。本轮完整证据、复算命令和清理状态见[1.15档案](../evaluation/artifacts/e6-session-validation-20260909/README.md)。
''';p.write_text(s)
p=repo/'evaluation/releases/README.md';s=p.read_text().replace('活动协议为Evaluation Protocol Release 1.14未登记候选（仅离线验证）；历史最终实验仍为1.13。','活动协议为Evaluation Protocol Release 1.15未登记验证版，固定源码eac64bc；已完成已见Development/Calibration定向真实验证，见[1.15证据](../artifacts/e6-session-validation-20260909/README.md)。1.14保留原仅离线身份；历史最终实验仍为1.13。',1);p.write_text(s)
p=repo/'evaluation/artifacts/e6-audit-fixes-20260909/README.md';s=p.read_text();s=s.replace('# E6独立审计后的工程补修（2026-09-09）\n','# E6独立审计后的工程补修（2026-09-09）\n\n本目录保留217adea/f47e3a1阶段的1.14离线补修证据。后续发现的多会话归属缺陷及运行时覆盖，已在[1.15定向验证](../e6-session-validation-20260909/README.md)修复与验证；以下“当前”均为本目录生成时快照。\n',1);p.write_text(s)
p=repo/'evaluation/artifacts/e6-completion-20260909/README.md';s=p.read_text();s=s.replace('E6要求已执行完成：修复第三阶段实际代码问题、另版方法验证、重新建立未见家族并冻结登记、完整运行、主AI全轨迹审核及归档。','本目录保留1.13冻结家族实验、原始结果与当时AI审核；后续工程审计补修和新版验证见[1.15交付](../e6-session-validation-20260909/README.md)。',1);s=s.replace('uv sync --frozen','python -m venv "$WORK/venv"\n"$WORK/venv/bin/pip" install -r evaluation/runtime-requirements.lock').replace('PYTHONPATH=evaluation/src:backend .venv/bin/python evaluation/scripts/summarize_e6_run.py','PYTHONPATH=evaluation/src:backend "$WORK/venv/bin/python" evaluation/scripts/summarize_e6_run.py');s+='\n后续1.15已完成定向真实验证；1.14仅离线的历史事实不变。原实验与报告不迁移版本，见[当前验证入口](../e6-session-validation-20260909/README.md)。\n';p.write_text(s)
for source,target in [('validation-summary.json','validation-summary.json'),('calibration-comparison.csv','calibration-comparison.csv'),('budget-audit.json','budget-audit.json'),('final-verification.json','final-verification.json'),('development/report/summary.json','development-summary.json'),('development/report/cases.csv','development-cases.csv'),('calibration/report/summary.json','calibration-summary.json'),('calibration/report/cases.csv','calibration-cases.csv')]:shutil.copyfile(r/source,out/target)
