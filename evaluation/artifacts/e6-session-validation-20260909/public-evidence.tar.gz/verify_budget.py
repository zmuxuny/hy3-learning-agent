import json,hashlib
from pathlib import Path
from decimal import Decimal,ROUND_CEILING
from collections import Counter
r=Path(__file__).parent;p=Path('/root/.local/state/learning-travel/e4-hy3-20260905-osj4FCZZ-budget.json');before=json.loads((r/'budget-before.json').read_text());blob=p.read_bytes();after=json.loads(blob);(r/'budget-after.json').write_bytes(blob)
assert len(before['requests'])==1515;assert after['requests'][:1515]==before['requests'];assert {k:v for k,v in after.items() if k!='requests'}=={k:v for k,v in before.items() if k!='requests'}
rows=[]
for x in after['requests'][1515:]:
 assert x['status'] in ['settled','unknown_usage_reserved'],x['status']
 u=x['token_usage'];i,o=(u['prompt_tokens'],u['completion_tokens']) if u else (x['input_limit'],x['output_limit']);expected=int((Decimal(str(x['input_rate']))*i+Decimal(str(x['output_rate']))*o).to_integral_value(rounding=ROUND_CEILING));assert expected==x['charged_micro_cny'];rows.append({'ticket':x['ticket'],'scope':x['scope'],'call_id':x['call_id'],'status':x['status'],'charged_micro_cny':expected,'formula_verified':True})
old=sum(x['charged_micro_cny'] for x in before['requests']);total=sum(x['charged_micro_cny'] for x in after['requests']);assert total-old<=12000000;assert total<=after['limit_micro_cny'];unknown=[x for x in after['requests'] if x['status']=='unknown_usage_reserved']
result={'old_request_prefix_unchanged':True,'all_authorization_and_limits_unchanged':True,'baseline_requests':1515,'final_requests':len(after['requests']),'new_requests':len(rows),'baseline_charge_micro_cny':old,'new_charge_micro_cny':total-old,'total_charge_micro_cny':total,'limit_micro_cny':after['limit_micro_cny'],'remaining_micro_cny':after['limit_micro_cny']-total,'allocation_micro_cny':12000000,'within_allocation':True,'all_unknown_usage_count':len(unknown),'all_unknown_usage_reserved_micro_cny':sum(x['charged_micro_cny'] for x in unknown),'new_status_counts':dict(Counter(x['status'] for x in rows)),'ledger_sha256':hashlib.sha256(blob).hexdigest(),'pricing_status':'equivalent estimate, supplier CNY invoice not verified','rows':rows}
(r/'budget-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print({k:v for k,v in result.items() if k!='rows'})
