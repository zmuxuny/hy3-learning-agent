import json
from pathlib import Path
r=Path(__file__).parent;ledger=json.loads((r/'budget-after.json').read_text());new=ledger['requests'][1515:];seen=set();rows=[]
m=json.loads((r/'development/runtime/run-manifest.json').read_text())
for terminal in m['terminals']:
 e=json.loads((r/'development/runtime/episodes'/f"{terminal['artifact_id']}.json").read_text())
 for i,c in enumerate(e['observable_trace']['model_calls']):
  matches=[x for x in new if x['scope']==terminal['case_id'] and x['call_id']==c['call_id']];assert len(matches)==1;row=matches[0];assert row['token_usage']==c['token_usage'];assert row['ticket'] not in seen;seen.add(row['ticket']);rows.append({'ticket':row['ticket'],'episode_id':e['episode_id'],'episode_sha256':e['provenance']['episode_sha256'],'evidence_path':f'observable_trace.model_calls[{i}].token_usage','kind':'agent'})
for path in sorted(r.glob('*/*attempts.jsonl')):
 for line in path.read_text().splitlines():
  a=json.loads(line);ticket=a['budget_ticket'];assert ticket is not None and ticket not in seen;seen.add(ticket);row=next(x for x in new if x['ticket']==ticket);assert row['scope']=='judge';assert row['call_id']==a['episode_id']+':attempt:'+str(a['attempt']);rows.append({'ticket':ticket,'path':str(path.relative_to(r)),'record_sha256':a['record_sha256'],'kind':'judge','provider_failure_category':a['provider_failure_category'],'http_status':a['http_status']})
assert seen=={x['ticket'] for x in new}
(r/'billing-evidence-binding.json').write_text(json.dumps({'all_new_requests_bound':True,'agent_calls':sum(x['kind']=='agent' for x in rows),'judge_calls':sum(x['kind']=='judge' for x in rows),'rows':rows},indent=2));print('bound',len(rows))
