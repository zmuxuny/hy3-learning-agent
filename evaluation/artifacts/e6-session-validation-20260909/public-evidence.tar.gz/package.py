import json,hashlib,tarfile,io,subprocess
from pathlib import Path
r=Path(__file__).parent;repo=Path('/root/workspace/tencent_rhinobird2026/learning_travel');out=repo/'evaluation/artifacts/e6-session-validation-20260909';out.mkdir(exist_ok=True);paths=[]
for p in sorted(r.iterdir()):
 if p.is_file() and (p.suffix in ['.json','.log','.py'] or p.name.endswith('.tar.gz')):paths.append(p)
for dirname in ['development','calibration','pytest-regressions-first','pytest-regressions-diagnostic','pytest-regressions-fixed']:
 paths.extend(p for p in sorted((r/dirname).rglob('*')) if p.is_file() and p.suffix in ['.json','.jsonl','.csv','.log'])
rows=[];archive=out/'public-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for p in paths:
  name=str(p.relative_to(r));assert not any(x in ['.env','.git','data','__pycache__'] for x in p.relative_to(r).parts);b=p.read_bytes();info=tarfile.TarInfo(name);info.size=len(b);t.addfile(info,io.BytesIO(b));rows.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
manifest={'source_commit':'eac64bceaae5ffd7c939ca0da3a4fbce90db1b4d','archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':rows}
(out/'archive-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
with tarfile.open(archive) as t:
 for row in rows:
  b=t.extractfile(row['path']).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
print('verified',len(rows),'members',archive.stat().st_size,'bytes')
