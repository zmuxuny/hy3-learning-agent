import json,os,subprocess,time,sys,hashlib
from pathlib import Path
r=Path(__file__).parent;c=r/'run-copy';batch=sys.argv[1];run=r/batch;python='/root/workspace/tencent_rhinobird2026/learning_travel/.venv/bin/python';env={**os.environ,'PYTHONPATH':str(c/'evaluation/src')+':'+str(c/'backend'),'PYTHONDONTWRITEBYTECODE':'1'};rows=[]
def execute(label,args):
 start=time.time()
 with (r/(batch+'-'+label+'.log')).open('x') as log:p=subprocess.run([python,*args],cwd=c,env=env,stdout=log,stderr=subprocess.STDOUT)
 rows.append({'label':label,'arguments':args,'exit_code':p.returncode,'seconds':time.time()-start});(r/(batch+'-report-execution.json')).write_text(json.dumps(rows,indent=2));return p.returncode
for label,review in [('aggregate',False),('adjudicated',True)]:
 args=['-m','learning_agent_eval','aggregate-results','--episodes',str(run/'runtime'),'--rules',str(run/'rules'),'--judges',str(run/'judge'),'--output',str(run/label)]
 if review:args+=['--semantic-reviews',str(run/'semantic-reviews.json')]
 execute(label,args);assert (run/label/'run-manifest.json').exists()
for label in ['report','report-recomputed']:
 assert execute(label,['evaluation/scripts/summarize_e6_run.py','--dataset',f'evaluation/datasets/decisionbench-v1.15-validation/{batch}','--run',str(run),'--output',str(run/label)])==0
comp=[]
for name in ['summary.json','cases.csv']:
 a=(run/'report'/name).read_bytes();assert a==(run/'report-recomputed'/name).read_bytes();comp.append({'file':name,'sha256':hashlib.sha256(a).hexdigest(),'bytes':len(a),'byte_equal':True})
(run/'recompute-verification.json').write_text(json.dumps(comp,indent=2));print(batch,'byte-equal')
