import json,hashlib,subprocess,tarfile,io
from pathlib import Path
r=Path(__file__).parent;c=r/'run-copy';commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=c,text=True).strip();names=set()
for p in (c/'evaluation/releases/source-bundles/1.15').glob('*.json'):
 d=json.loads(p.read_text())
 for f in d['files']:
  b=subprocess.check_output(['git','show',commit+':'+f['relative_path']],cwd=c);assert len(b)==f['size'] and hashlib.sha256(b).hexdigest()==f['sha256'];names.add(f['relative_path'])
for prefix in ['evaluation/datasets/decisionbench-v1.15-validation','evaluation/schemas/protocol-1.15','evaluation/releases/source-bundles/1.15']:
 names.update(subprocess.check_output(['git','ls-tree','-r','--name-only',commit,prefix],cwd=c,text=True).splitlines())
names.update(['evaluation/releases/evaluation-protocol-release-1.15.json','evaluation/releases/schema-lock-1.15.json','tests/test_e6_session_scope.py','tests/test_e6_deadline_runtime.py','evaluation/pyproject.toml','evaluation/runtime-requirements.lock'])
rows=[]
with tarfile.open(r/'source-eac64bc.tar.gz','w:gz') as t:
 for name in sorted(names):
  b=subprocess.check_output(['git','show',commit+':'+name],cwd=c);info=tarfile.TarInfo(name);info.size=len(b);t.addfile(info,io.BytesIO(b));rows.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
result={'commit':commit,'scope':'union of all four Protocol1.15 component manifests, validation datasets/protocol schemas/binding metadata, two new regression tests and dependency locks','git_dependency':'Native provenance validation still requires original Git objects at this commit; this tar is a byte-inspection snapshot, not a substitute for Git history.','sha256':hashlib.sha256((r/'source-eac64bc.tar.gz').read_bytes()).hexdigest(),'files':rows}
(r/'source-snapshot-manifest.json').write_text(json.dumps(result,indent=2));print('files',len(rows))
