import os,sys,json,subprocess,time
from pathlib import Path
from dotenv import dotenv_values
r=Path(__file__).parent;c=r/'run-copy';label=sys.argv[1]
assert not (c/'.env').exists()
env={**os.environ,'PYTHONPATH':str(c/'evaluation/src')+':'+str(c/'backend'),'PYTHONDONTWRITEBYTECODE':'1'}
values=dotenv_values('/root/workspace/tencent_rhinobird2026/learning_travel/.env')
for k in ('OPENAI_API_KEY','OPENAI_API_BASE','OPENAI_MODEL_NAME'):
 if values.get(k):env[k]=values[k]
cmd=['/root/workspace/tencent_rhinobird2026/learning_travel/.venv/bin/python','-m','learning_agent_eval',*sys.argv[2:]]
start=time.time()
with (r/(label+'.log')).open('x') as log:p=subprocess.run(cmd,cwd=c,env=env,stdout=log,stderr=subprocess.STDOUT)
(r/(label+'.execution.json')).write_text(json.dumps({'command':cmd,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=c,text=True).strip(),'exit_code':p.returncode,'seconds':time.time()-start},indent=2));print(label,p.returncode)
