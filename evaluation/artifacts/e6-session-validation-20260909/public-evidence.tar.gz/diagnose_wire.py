import json,unicodedata
from pathlib import Path
from learning_agent_eval.blinding_v2 import build_blind_judge_input_v3
from learning_agent_eval.active_judge import build_provider_request_v3
from learning_agent_eval.judge_request_projection import unpack_shared_values
r=Path(__file__).parent;rows=[]
def diff(a,b,path):
 if a==b:return
 if isinstance(a,dict) and isinstance(b,dict):
  for k in a:diff(a[k],b[k],path+'.'+k)
 elif isinstance(a,(list,tuple)) and isinstance(b,(list,tuple)):
  if type(a)!=type(b):rows.append({'path':path,'original_type':type(a).__name__,'wire_type':type(b).__name__})
  for i,(x,y) in enumerate(zip(a,b)):diff(x,y,path+f'[{i}]')
 else:rows.append({'path':path,'original_type':type(a).__name__,'wire_type':type(b).__name__,'nfc_equivalent':isinstance(a,str) and isinstance(b,str) and unicodedata.normalize('NFC',a)==b})
for batch in ['development','calibration']:
 for p in (r/batch/'runtime/episodes').glob('*.json'):
  e=json.loads(p.read_text());ru=json.loads((r/batch/'rules/rules'/p.name).read_text());ref=json.loads((r/batch/'runtime/judge-references'/p.name).read_text());blind=build_blind_judge_input_v3(e,ru,ref);wire=json.loads(build_provider_request_v3(blind)['messages'][1]['content']);diff(blind.document,unpack_shared_values(wire),batch+'/'+p.stem)
(r/'wire-comparison-diagnostic.json').write_text(json.dumps({'first_check':'raw Python equality failed; use existing canonical JSON contract (NFC and sequence normalization), not changed evaluation criteria','differences':rows},indent=2));print(rows[:10],len(rows))
