import hashlib
import json
import re
from pathlib import Path

base = Path(__file__).resolve().parent
repo = Path('/root/workspace/tencent_rhinobird2026/learning_travel')
output = repo / 'evaluation/artifacts/e4-acceptance-20260906'
assert (base / 'checks/full-repo-final.json').is_file()


def load(path):
    return json.loads(path.read_text())


retained = {
    'full-repo-complete': (1, 'Complete pre-fix run exposed the notification-storm test assuming at least one immediate admission. All original results retained; test convergence is corrected in 4c9a632 and the complete suite rerun.'),
    'outbox-all-busy-counterexample': (1, 'Independent deterministic red probe: retryable writer exhaustion leaves no Outbox row, so the old immediate scalar_one assertion fails.'),
    'diff-check-before-lf': (2, 'Generated review worksheet initially used CRLF; builder and worksheet changed to LF before commit 946d735.'),
    'full-repo': (1, 'First full attempt deliberately interrupted after missing frontend dependency/build failures; interrupt teardown traceback retained.'),
    'diagnose-frontend': (1, 'Diagnostic reproduction confirmed missing vite/plugin packages in the first isolated clone.'),
    'frontend-and-release-setup': (1, 'Frontend checks passed after dependency copy; release check still needed a fresh dist build.'),
    'independent-bindings-and-blinding': (1, 'External check script incorrectly treated the app namespace as having __file__; corrected to the concrete runtime module and actual terminals field.'),
    'release-verification': (2, 'External invocation used a nonexistent --verify flag; actual committed-release verifier runs with no flag.'),
}
expected_domain_exits = {'calibration-rules': 2}
for round_name in ('a', 'b'):
    for stage, exit_code in [('runtime', 2), ('rules', 2), ('aggregate', 3)]:
        expected_domain_exits[f'smoke-{round_name}-{stage}'] = exit_code
checks = {}
for path in sorted((base / 'checks').glob('*.json')):
    record = load(path)
    payload = (base / 'checks' / record['log']).read_bytes()
    assert hashlib.sha256(payload).hexdigest() == record['log_sha256']
    label = path.stem
    if label in retained:
        expected, explanation = retained[label]
        category = 'retained_failed_validation_attempt'
    elif label in expected_domain_exits:
        expected, explanation = expected_domain_exits[label], 'Expected scored behavior or deliberate RuntimeFailure; artifacts remain valid.'
        category = 'expected_domain_exit'
    else:
        expected, explanation = 0, None
        category = 'passed'
    assert record['exit_code'] == expected, label
    checks[label] = {'raw_log_location': ('final-gates.json#checks/' + label + '/output' if label in {'doc-links-final', 'secret-scan-final', 'staged-diff-final'} else 'validation-logs.tar.gz#checks/' + record['log']), **record, 'classification': category, 'expected_exit_code': expected, 'explanation': explanation}

test_summaries = {}
for label in ('e4-targeted', 'evaluation-all', 'seams-and-frontend-recovery', 'outbox-retry-convergence', 'full-repo-final'):
    lines = (base / 'checks' / (label + '.txt')).read_text().splitlines()
    matches = [line for line in lines if re.search(r'\d+ passed.* in [\d.]+s', line)]
    assert len(matches) == 1, label
    line = matches[0]
    assert not any(word in line for word in ('failed', 'skipped', 'xfailed', 'xpassed'))
    test_summaries[label] = {'summary': line.strip('= '), 'source_commit': checks[label]['git_commit'], 'worktree_was_clean': not checks[label]['worktree_status']}
assert '269 passed' in test_summaries['evaluation-all']['summary']
assert '1350 passed' in test_summaries['full-repo-final']['summary']

archives = {}
for path in sorted(output.glob('*.tar.gz.inventory.json')):
    value = load(path)
    archive = path.with_name(path.name.removesuffix('.inventory.json'))
    sha = hashlib.sha256(archive.read_bytes()).hexdigest()
    assert sha == value.get('sha256', value.get('archive_sha256'))
    archives[archive.name] = {'sha256': sha, 'bytes': archive.stat().st_size, 'files': len(value['members']), 'inventory': path.name}

summary = {
    'date': '2026-09-06',
    'branch': 'fix/evaluation-audit-readiness',
    'handoff_commit': 'a875ea01f10d0c9c44cc946a3fbc2bfba4648958',
    'test_source_commit': '4c9a63228b4fb20d4a8e5dc5c0e6e279c96157ea',
    'runtime_and_evaluation_source_commit': '946d73541e935fcee40f2a60ae33ad7073f1587b',
    'followup_commit_scope': 'Documentation and archived acceptance evidence only; source-inventory.json binds 511 code/input/config files to 4c9a632; only the Outbox regression test differs from 946d735.',
    'status': ('e4_content_and_engineering_accepted' if all(name in checks for name in ('doc-links-final', 'secret-scan-final', 'staged-diff-final')) else 'e4_regression_passed_final_document_checks_pending'),
    'e5_started': False,
    'real_judge_calls': 0,
    'new_real_requests': 0,
    'production_registry_entries': 0,
    'formal_capability_result': False,
    'review': {'primary': 48, 'calibration': 24, 'sources': 8, 'per_case_records': 80, 'triplet_records': 8, 'reviewer_role': 'delegated_ai_reviewer', 'independent_human_review': False, 'shared_author_context': True, 'review_sha256': 'a2f6aef02cae4457aa59ce4306f64ca2b821fbee9bb860732ad43f74257254cd'},
    'test_summaries': test_summaries,
    'retained_complete_run': {'source_commit': '946d73541e935fcee40f2a60ae33ad7073f1587b', 'summary': '1 failed, 1348 passed, 2 warnings in 4344.99s', 'exception_type': 'sqlalchemy.exc.NoResultFound', 'failed_test': 'tests/hardening/test_h2_transaction_protocol.py::test_bounded_duplicate_notification_storm_delivers_one_receipt_and_transport'},
    'checks': checks,
    'archives': archives,
    'budget': load(output / 'environment-and-budget.json')['budget'],
    'bindings_report': 'independent-checks.json',
    'repeatability_report': 'two-smokes.json',
    'environment_report': 'environment-and-budget.json',
    'source_report': 'source-inventory.json',
    'final_gates_report': ('final-gates.json' if (output / 'final-gates.json').exists() else None),
    'ruff_report': 'ruff-baseline.json',
    'outbox_test_ruff_report': 'outbox-ruff-baseline.json',
    'outbox_failure_fixture_report': 'outbox-failure-fixture-summary.json',
    'scope_notes': [
        'The initial 18-test run preceded the LF-only generator/worksheet cleanup. The 269-test run includes those 18 cases at 946d735; the complete final repository run at 4c9a632 uses identical evaluation source and adds the Outbox contention test branch.',
        'The first complete 946d735 run is retained with its notification-storm failure. A deterministic busy-writer probe reproduced the premature Outbox-row assumption; four focused recovery cases passed after correcting the test. Product/evaluation execution code was not changed.',
        'The first incomplete full attempt lacked copied frontend dependencies and a dist build. Both were supplied offline before the successful full rerun. All failed validation attempts and interrupt tracebacks are retained.',
        'CI lint_typecheck means the exact repository gate: compileall, fatal Ruff rules and JavaScript syntax; it is not a mypy/pyright result.',
        'Archived final gate logs describe the snapshot before appending their own evidence. The final staged files are checked again before the local commit.',
        'Historical Primary remains 45 Episode plus 3 RuntimeFailure at its original input/source identities. No new real Primary run was performed on the revised exploratory inputs.',
        'The exact historical primary-s06-p malformed payload was not retained; its unique root cause cannot be reconstructed. The independently reproduced context-window diagnostic fix is covered by regression.',
    ],
    'remaining_project_deliverables': [
        'E5 Judge discrimination and repeated consistency, including a fixed process for semantic Critical suggestions.',
        'Unseen formal Primary test families; original E4 freeze/registry commitments remain open until E5 method stabilization and before E6.',
        'Formal four-track results, case/failure analysis and third-stage presentation connected to the existing 92.6-second product demo.',
        'Independent human agreement/Kappa and other explicitly listed extension experiments have not been performed by these AI content reviews.',
    ],
    'historical_artifacts_rewritten': False,
    'push_or_publish_performed': False,
    'cleanup_scope': 'Only /tmp/learning-travel-e4-acceptance-4E6ideiE and its owned clones/caches/databases are removed after archiving. Original ignored files and the private budget ledger are retained.',
}
(output / 'validation-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True) + '\n')
print(json.dumps({'status': summary['status'], 'test_summaries': test_summaries,
    'retained_complete_run': {'source_commit': '946d73541e935fcee40f2a60ae33ad7073f1587b', 'summary': '1 failed, 1348 passed, 2 warnings in 4344.99s', 'exception_type': 'sqlalchemy.exc.NoResultFound', 'failed_test': 'tests/hardening/test_h2_transaction_protocol.py::test_bounded_duplicate_notification_storm_delivers_one_receipt_and_transport'}, 'recorded_commands': len(checks), 'archives': len(archives)}, ensure_ascii=False))
