import hashlib
import json
import subprocess
import sys
from pathlib import Path

base=Path(__file__).resolve().parent
repo=base/'runtime-repo'
python=Path('/root/workspace/tencent_rhinobird2026/learning_travel/.venv/bin/python')
records=[]
for round_name in ('a','b'):
    root=base/('smoke-'+round_name)
    commands=[
      ('runtime',['run-agent','--dataset','evaluation/datasets/decisionbench-v4-engineering','--manifest','evaluation/datasets/decisionbench-v4-engineering/manifest.json','--output',str(root/'runtime')],2),
      ('runtime-validate',['validate-dataset','--dataset',str(root/'runtime')],0),
      ('rules',['evaluate-rules','--input',str(root/'runtime'),'--output',str(root/'rules')],2),
      ('rules-validate',['validate-dataset','--dataset',str(root/'rules')],0),
      ('judges',['evaluate-judge','--episodes',str(root/'runtime'),'--rules',str(root/'rules'),'--output',str(root/'judges'),'--judge-mode','stub','--stub-response','evaluation/fixtures/e311-fixed-judge-responses-v3.json'],0),
      ('judges-validate',['validate-dataset','--dataset',str(root/'judges')],0),
      ('aggregate',['aggregate-results','--episodes',str(root/'runtime'),'--rules',str(root/'rules'),'--judges',str(root/'judges'),'--output',str(root/'aggregates')],3),
      ('aggregate-validate',['validate-dataset','--dataset',str(root/'aggregates')],0),
    ]
    for name,args,expected in commands:
        label='smoke-'+round_name+'-'+name
        code=subprocess.call([sys.executable,str(base/'run_check.py'),label,str(repo),str(python),'-m','learning_agent_eval',*args])
        records.append({'label':label,'actual':code,'expected':expected})
        if code!=expected:
            raise SystemExit('unexpected_exit:'+label)
    manifest=json.loads((root/'runtime/run-manifest.json').read_text())
    assert len(manifest['terminals'])==12
    assert sum(t['terminal_kind']=='episode' for t in manifest['terminals'])==11
    assert sum(t['terminal_kind']=='failure' for t in manifest['terminals'])==1
    assert not manifest['formal_evaluation_result']

def inventory(root):
    return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file()}
a=inventory(base/'smoke-a');b=inventory(base/'smoke-b')
assert a==b, {'different_paths':sorted(set(a)^set(b)), 'different_files':[k for k in set(a)&set(b) if a[k]!=b[k]]}
summary={'git_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'rounds':2,'byte_identical_files':len(a),'per_round':{'terminals':12,'episodes':11,'failures':1},'real_judge_calls':0,'commands':records,'files':a}
(base/'two-smokes.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in {'files','commands'}}))
