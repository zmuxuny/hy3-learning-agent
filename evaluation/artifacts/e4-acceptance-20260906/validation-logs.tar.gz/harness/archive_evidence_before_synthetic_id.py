import gzip
import hashlib
import io
import json
import runpy
import sys
import tarfile
from pathlib import Path

base = Path(__file__).resolve().parent
repo = Path('/root/workspace/tencent_rhinobird2026/learning_travel')
output = repo / 'evaluation/artifacts/e4-acceptance-20260906'
patterns = runpy.run_path(str(repo / 'scripts/release-check.py'))['SECRET_PATTERNS']


def digest(payload):
    return hashlib.sha256(payload).hexdigest()


def archive(name, files):
    destination = output / name
    assert not destination.exists()
    records = []
    with destination.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
            with tarfile.open(mode='w', fileobj=compressed) as stream:
                for member, path in sorted(files.items()):
                    payload = path.read_bytes()
                    assert not any(pattern.search(payload) for pattern in patterns), member
                    info = tarfile.TarInfo(member)
                    info.size = len(payload)
                    info.mode = 0o644
                    info.mtime = 0
                    stream.addfile(info, io.BytesIO(payload))
                    records.append({'path': member, 'bytes': len(payload), 'sha256': digest(payload)})
    with tarfile.open(destination) as stream:
        contents = {m.name: stream.extractfile(m).read() for m in stream if m.isfile()}
    assert set(contents) == set(files)
    for item in records:
        assert digest(contents[item['path']]) == item['sha256']
    metadata = {'file': name, 'files': len(records), 'bytes': destination.stat().st_size, 'sha256': digest(destination.read_bytes()), 'uncompressed_bytes': sum(r['bytes'] for r in records), 'members': records, 'raw_members_secret_pattern_check': 'pass'}
    with destination.with_name(name + '.inventory.json').open('x') as stream:
        stream.write(json.dumps(metadata, indent=2, sort_keys=True) + '\n')
    print(json.dumps({k: v for k, v in metadata.items() if k != 'members'}))


mode = sys.argv[1]
if mode == 'runtime':
    for name, folders in [('calibration-runtime-and-rules-946d735.tar.gz', ['calibration-runtime', 'calibration-rules']), ('two-offline-full-chains-946d735.tar.gz', ['smoke-a', 'smoke-b'])]:
        files = {}
        for folder in folders:
            for path in sorted((base / folder).rglob('*')):
                if path.is_file():
                    assert path.suffix == '.json', path.name
                    files[str(path.relative_to(base))] = path
        archive(name, files)
elif mode == 'logs':
    assert (base / 'checks/full-repo-final.json').is_file()
    files = {str(p.relative_to(base)): p for p in (base / 'checks').glob('*') if p.is_file()}
    for name in ['run_check.py', 'check_release_and_corpus.py', 'collect_static_evidence.py', 'run_two_smokes.py', 'archive_evidence.py', 'finalize_evidence.py', 'finish_docs.py', 'test_outbox_all_busy_counterexample.py', 'outbox-failure-fixture-summary.json', 'outbox-ruff-baseline.json', 'preliminary-source-sha.json']:
        files['harness/' + name] = base / name
    for p in (base / 'hooks').iterdir():
        if p.is_file():
            files['harness/hooks/' + p.name] = p
    archive('validation-logs.tar.gz', files)
else:
    raise SystemExit('expected runtime or logs')
