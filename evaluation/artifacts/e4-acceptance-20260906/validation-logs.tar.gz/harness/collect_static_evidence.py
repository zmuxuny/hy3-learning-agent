import hashlib
import importlib.metadata
import json
import platform
import stat
import subprocess
import sys
import tarfile
from pathlib import Path

base = Path(__file__).resolve().parent
repo = Path.cwd()
original = Path('/root/workspace/tencent_rhinobird2026/learning_travel')


def digest(payload):
    return hashlib.sha256(payload).hexdigest()


def write(name, document):
    with (base / name).open('x') as stream:
        stream.write(json.dumps(document, ensure_ascii=False, indent=2, sort_keys=True) + '\n')


commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
paths = subprocess.check_output(['git', 'ls-files', '-z'], text=True).split('\0')
source_files = {}
for name in paths:
    if not name or name.startswith('evaluation/artifacts/'):
        continue
    path = repo / name
    if path.suffix not in {'.py', '.json', '.toml', '.ini', '.js', '.mjs', '.cjs', '.vue', '.csv', '.yaml', '.yml', '.sh'}:
        continue
    payload = path.read_bytes()
    assert payload == (original / name).read_bytes(), name
    assert payload == subprocess.check_output(['git', 'show', f'{commit}:{name}']), name
    source_files[name] = {'bytes': len(payload), 'sha256': digest(payload)}
write('source-inventory.json', {'test_source_commit': commit, 'main_and_test_clone_match': True, 'files': source_files})

baseline_root = base / 'ruff-baseline'
baseline_root.mkdir()
changed = ['evaluation/scripts/build_e4_candidates.py', 'evaluation/scripts/check_e4_candidates.py', 'evaluation/tests/test_e4_content_review.py']
baseline_paths = []
for name in changed:
    result = subprocess.run(['git', 'show', f'a875ea0:{name}'], capture_output=True)
    if result.returncode == 0:
        p = baseline_root / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(result.stdout)
        baseline_paths.append(name)
baseline = subprocess.run([sys.executable, '-m', 'ruff', 'check', '--output-format', 'json', *baseline_paths], cwd=baseline_root, capture_output=True, text=True)
current = subprocess.run([sys.executable, '-m', 'ruff', 'check', '--output-format', 'json', *changed], capture_output=True, text=True)
assert baseline.returncode in {0, 1} and current.returncode == 0
before, after = json.loads(baseline.stdout), json.loads(current.stdout)
assert not after
write('ruff-baseline.json', {'baseline_commit': 'a875ea01f10d0c9c44cc946a3fbc2bfba4648958', 'test_source_commit': commit, 'changed_files': changed, 'baseline_files': baseline_paths, 'baseline_findings': before, 'current_findings': after, 'new_findings': 0, 'scope': 'Modified Python files only; this is not a repository-wide default Ruff pass.'})

ledger = Path('/root/.local/state/learning-travel/e4-hy3-20260905-osj4FCZZ-budget.json')
payload = ledger.read_bytes()
assert digest(payload) == 'b7300434aaac02817b689845052340210f97da2e293e23e1425eb4ec53b1c025'
assert stat.S_IMODE(ledger.stat().st_mode) == 0o600
document = json.loads(payload)
requests = document['requests']
settled = sum(item['charged_micro_cny'] for item in requests if item['status'] == 'settled')
reserved = sum(item['charged_micro_cny'] for item in requests if item['status'] != 'settled')
budget = {'ledger_sha256': digest(payload), 'ledger_mode': '0600', 'unchanged_from_handoff': True, 'limit_micro_cny': document['limit_micro_cny'], 'requests': len(requests), 'new_real_requests': 0, 'usage_estimate_micro_cny': settled, 'unknown_usage_reserved_micro_cny': reserved, 'occupied_micro_cny': settled + reserved, 'remaining_micro_cny': document['limit_micro_cny'] - settled - reserved, 'unknown_usage_requests': sum(item['status'] != 'settled' for item in requests), 'is_actual_account_invoice': False}
assert (len(requests), settled, reserved) == (190, 4355213, 1042432)
assert ledger.read_bytes() == payload

frontend = repo / 'frontend'
locked = json.loads((frontend / 'package-lock.json').read_text())['packages']
installed = json.loads((frontend / 'node_modules/.package-lock.json').read_text())['packages']
assert set(installed) <= set(locked)
assert all(installed[k].get('version') == locked[k].get('version') for k in installed)
absent = set(locked) - set(installed) - {''}
assert all(locked[k].get('optional') is True for k in absent)
environment = {'python': platform.python_version(), 'platform': platform.platform(), 'node': subprocess.check_output(['node', '--version'], text=True).strip(), 'npm': subprocess.check_output(['npm', '--version'], text=True).strip(), 'packages': {name: importlib.metadata.version(name) for name in ('pytest', 'ruff', 'openai')}, 'frontend': {'installed_packages': len(installed), 'installed_versions_match_lock': True, 'absent_optional_packages': len(absent), 'fresh_offline_builds': ['frontend-build-full', 'frontend-build-runtime'], 'dist_files': {str(p.relative_to(frontend)): digest(p.read_bytes()) for p in sorted((frontend / 'dist').rglob('*')) if p.is_file()}}, 'isolation': {'original_env_and_data_copied': False, 'python_file_and_network_audit_hook': 'hooks/sitecustomize.py', 'node_network_guard': 'hooks/node-network-guard.cjs', 'node_guard_timing': 'Added after the first missing-dependency attempt; used by the complete rerun and successful frontend/release recovery.', 'npm_offline_for_complete_rerun': True}}
video = original / 'assets/demo/learning-agent-hy3-demo.mp4'
environment['existing_product_demo'] = {'path': str(video.relative_to(original)), 'sha256': digest(video.read_bytes()), 'probe': json.loads(subprocess.check_output(['ffprobe', '-v', 'error', '-show_entries', 'format=duration:stream=codec_type,width,height', '-of', 'json', str(video)], text=True))}
write('environment-and-budget.json', {'test_source_commit': commit, 'environment': environment, 'budget': budget})

root = original / 'evaluation/artifacts/e4-acceptance-20260906'
index = json.loads((root / 'inputs-at-handoff-a875ea0.tar.gz.inventory.json').read_text())
archive = root / 'inputs-at-handoff-a875ea0.tar.gz'
assert digest(archive.read_bytes()) == index['archive_sha256']
with tarfile.open(archive) as stream:
    members = {m.name: stream.extractfile(m).read() for m in stream if m.isfile()}
assert set(members) == set(index['members'])
for name, info in index['members'].items():
    assert info == {'bytes': len(members[name]), 'sha256': digest(members[name])}
    assert members[name] == subprocess.check_output(['git', 'show', f'a875ea0:{name}'])
print(json.dumps({'source_files_equal_to_test_commit': len(source_files), 'changed_python_ruff_baseline': len(before), 'changed_python_ruff_current': len(after), 'original_input_archive_members': len(members), 'budget': budget, 'frontend_installed_packages': len(installed)}, ensure_ascii=False))
