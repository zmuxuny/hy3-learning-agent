"""Record exact commands, outputs, source bytes and durations of E4 checks."""
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

base = Path(__file__).resolve().parent
label, cwd, *command = sys.argv[1:]
repo = Path(cwd)
logs = base / 'checks'; logs.mkdir(exist_ok=True)
log = logs / (label + '.txt')
metadata = logs / (label + '.json')
if log.exists() or metadata.exists(): raise RuntimeError('refuse_to_replace_check_evidence')
env = os.environ.copy()
env.update(PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=os.pathsep.join([str(base/'hooks'),str(repo/'backend'),str(repo/'evaluation/src')]),
    TMPDIR=str(base/'tmp'/label), TEMP=str(base/'tmp'/label), TMP=str(base/'tmp'/label),
    RUFF_CACHE_DIR=str(base/'ruff-cache'), OPENAI_API_KEY='test-key', OPENAI_API_BASE='http://127.0.0.1:9/v1',
    NODE_OPTIONS='--require=' + str(base/'hooks/node-network-guard.cjs'), npm_config_offline='true', npm_config_cache=str(base/'npm-cache'/label), npm_config_userconfig='/dev/null', ENABLE_SCHEDULER='false', ENABLE_EMAIL_REPLY_POLLING='false',
    DATABASE_URL='sqlite+aiosqlite:///' + str(base/'tmp'/label/'bootstrap.sqlite3'))
if label == 'lint_typecheck': env['PYTHONPYCACHEPREFIX'] = str(base/'bytecode')
(base/'tmp'/label).mkdir(exist_ok=True, parents=True)
started=time.time()
with log.open('xb') as stream:
    result = subprocess.run(command,cwd=repo,env=env,stdout=stream,stderr=subprocess.STDOUT)
record={'command':command,'cwd':str(repo),'exit_code':result.returncode,'elapsed_seconds':round(time.time()-started,2),
    'log':log.name,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),
    'git_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
    'worktree_status':subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).splitlines()}
metadata.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in record.items() if k != "worktree_status"},ensure_ascii=False))
print(log.read_text(errors='replace')[-9000:])
sys.exit(result.returncode)
