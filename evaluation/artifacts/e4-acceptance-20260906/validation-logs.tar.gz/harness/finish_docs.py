import json
from pathlib import Path

base = Path(__file__).resolve().parent
repo = Path('/root/workspace/tencent_rhinobird2026/learning_travel')
artifacts = repo / 'evaluation/artifacts/e4-acceptance-20260906'
summary = json.loads((artifacts / 'validation-summary.json').read_text())
assert summary['checks']['full-repo-final']['exit_code'] == 0
assert (artifacts / 'validation-logs.tar.gz').is_file()
full = summary['test_summaries']['full-repo-final']['summary']


def edit(name, replacements):
    path = repo / name
    text = path.read_text()
    for old, new in replacements:
        assert old in text, (name, old)
        text = text.replace(old, new)
    path.write_text(text)


edit('docs/E4验收工作记录.md', [
    ('本轮已按用户新指令恢复 E4 验收', '本轮已完成 E4 修复、AI 内容裁决、候选重建和最终回归，按用户要求暂停'),
    ('当前先做离线内容与工程验收；是否需要新的真实批次按 E4 未闭合证据决定，不为凑成功数重试。', '本轮离线内容与工程验收已完成，没有新增真实调用；旧终态保留，修订 Primary 仍为探索输入。'),
    ('| 全仓最终，`4c9a632` | 最终回归进行中，结束后填入实际结果 |', f'| 全仓最终，`4c9a632` | {full}；退出 0，0 failed/skip/xfail |'),
    ('| 工程门禁 | 实际 CI `lint_typecheck` 通过；最终链接、Secret、依赖及 diff 检查随文档收口 |', '| 工程门禁 | 实际 CI `lint_typecheck` 和 pip 检查通过；三个 E4 Python 文件默认 Ruff 为 0 条，通知测试文件修改前后均为 16 条、没有新增；链接/Secret/diff 正在最终收口 |'),
    ('最终命令、耗时、原始日志、当前 Calibration 和两轮全链将一并保存在本轮证据目录。', '最终命令、耗时、原始日志、当前 Calibration 和两轮全链已保存在本轮证据目录，详见 [验证清单](../evaluation/artifacts/e4-acceptance-20260906/validation-summary.json)。两条全仓 warning 为既有 Starlette/httpx 弃用提示和 Python 3.14 tar 提取行为预告。'),
    ('当前只完成 E4 修复、数据内容与工程验收的收口工作；', '本轮 E4 修复、数据内容与工程验收已完成；'),
])

edit('README.md', [('AI 逐例内容裁决与候选重建，最终回归进行中。', 'AI 逐例内容裁决、候选重建和最终回归，已按要求暂停。')])
edit('evaluation/README.md', [
    ('的 AI 内容裁决与候选重建，最终回归进行中；', '的 AI 内容裁决、候选重建和最终回归，已在 E4 后暂停；'),
    ('AI 内容裁决和绑定重建，最终回归进行中。', 'AI 内容裁决、绑定重建和最终回归，已在 E4 后暂停。'),
])
edit('docs/第三阶段开发交接.md', [
    ('## 当前接续点：E4 内容裁决与绑定已完成，最终回归中', '## 当前停止点：E4 内容与工程验收完成'),
    ('候选已重建，最终源码回归中。', f'候选已重建，通知并发测试修正提交为 `4c9a632`；最终全仓 {full}，全部 evaluation 269 passed。'),
])
edit('docs/腾讯犀牛鸟开源实习第三阶段项目方案.md', [
    ('最终软件回归中。', 'E4 内容与工程验收已完成，按要求暂停。'),
    ('AI逐例裁决/绑定已完成，最终回归中', 'AI逐例裁决、绑定与最终回归已完成，暂停于E4'),
])
edit('docs/腾讯犀牛鸟开源实习第三阶段评测实施方案.md', [
    ('候选重建，最终回归中；', '候选重建及最终回归，已在E4后暂停；'),
    ('当前候选绑定已重建，最终源码回归中。', '当前候选绑定与最终源码回归已完成，已在E4后暂停。'),
    ('AI裁决/绑定已完成，最终回归中', 'AI裁决、绑定与最终回归已完成，暂停于E4'),
    ('- [ ] 当前Calibration Runtime/Rules/盲化、最终源码回归和两轮stub全链收口；', '- [x] 当前Calibration Runtime/Rules/盲化、最终源码回归和两轮stub全链收口；'),
])
edit('docs/ROADMAP.md', [('- [ ] E4（最终回归中）：', '- [x] E4（内容与工程验收完成，已暂停）：')])

path = repo / 'docs/STATUS.md'
text = path.read_text().replace('最终回归进行中，未进入E5。', '最终回归已通过，按要求暂停，未进入E5。')
start = text.index('## 2026-09-06 E4 内容验收与最终回归')
end = text.index('## 2026-09-06 E4 接续交接（上一检查点）')
text = text[:start] + f'''## 2026-09-06 E4 内容与工程验收完成

48 Primary、24 Calibration、8 来源的 80 条 AI 内容记录及 8 组三档裁决已绑定最终 Case/资源摘要，身份为 `delegated_ai_reviewer`。修订了条件行动包络、静默/日限额初态、受保护实验和 Mild 缺陷；候选已重建。全部 evaluation 269 passed；最终 `4c9a632` 全仓 {full}。两轮离线全链的 64 个输出文件逐字节一致，当前 Calibration 为 24 Episode + 0 Failure。

首次完整回归的通知测试假设经独立反例复现后已修正，两个分支均在最终整轮通过；原 1348 passed + 1 failed 的整轮日志保留。全部原模型失败和历史证据保持原貌，旧真实 Primary 仍为 45 Episode + 3 Failure。当前输入标为探索候选，没有新增真实 Primary 运行。

E4 修复、复核、重建和回归已完成，按用户要求暂停。原正式冻结/登记承诺留待 E5 方法稳定后、E6 前；真实 Judge、方法验证与正式结果尚未执行。本轮新增真实请求为 0，原 14 元账本仍占用 5.397645 元。方案审视、精确验证与剩余缺口见 [E4 验收工作记录](E4验收工作记录.md)及 [验证清单](../evaluation/artifacts/e4-acceptance-20260906/validation-summary.json)。

''' + text[end:]
path.write_text(text)

edit('evaluation/artifacts/e4-acceptance-20260906/README.md', [
    ('最终全仓回归仍在运行，结束后追加完整命令、耗时及原始日志。', f'最终 `4c9a632` 全仓 {full}。完整命令与耗时见 [验证清单](validation-summary.json)，原始日志及验证脚本见 [日志归档](validation-logs.tar.gz)与[逐成员清单](validation-logs.tar.gz.inventory.json)。'),
    ('最终完整回归在 `4c9a632` 重新执行，旧完整批次不会被成功结果替换。', '最终完整回归在 `4c9a632` 通过，旧完整批次与独立 red 反例完整保留。'),
])
print(full)
