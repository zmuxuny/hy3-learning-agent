import hashlib
import io
import json
import shutil
import subprocess
import tarfile
from collections import Counter
from pathlib import Path

from learning_agent_eval.blinding_v2 import build_blind_judge_input_v3
from learning_agent_eval.source_bundles import build_source_bundle
from learning_agent_eval.validator import validate_dataset

base = Path(__file__).resolve().parent
repo = Path.cwd()

def load(path): return json.loads(path.read_text())
def raw_sha(payload): return hashlib.sha256(payload).hexdigest()
def plain_sha(value): return raw_sha(json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',',':')).encode())
summary = {'git_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()}

import learning_agent_eval
import importlib.util
app_origin = Path(importlib.util.find_spec("app.runtime.agent").origin)
assert Path(learning_agent_eval.__file__).is_relative_to(repo/'evaluation/src')
assert app_origin.is_relative_to(repo/'backend')
summary['import_origins']={'app':str(app_origin.relative_to(repo)), 'learning_agent_eval':str(Path(learning_agent_eval.__file__).relative_to(repo))}
lock=load(repo/'evaluation/releases/schema-lock-v1.json')
for item in lock['entries']:
    p=repo/item['relative_path']
    assert raw_sha(p.read_bytes()) == item['raw_sha256']
    assert p.read_bytes() == subprocess.check_output(['git','show','a875ea0:'+item['relative_path']])
summary['schemas']=dict(Counter(x['status'] for x in lock['entries']))
summary['schema_bytes_equal_handoff']=len(lock['entries'])
protocol=load(repo/'evaluation/releases/evaluation-protocol-release-1.0.json')
assert plain_sha({k:v for k,v in protocol.items() if k!='release_sha256'})==protocol['release_sha256']
summary['protocol_release_sha256']=protocol['release_sha256']
assert load(repo/'evaluation/releases/trusted-benchmark-registry-v1.json')['entries']==[]
summary['production_registry_entries']=0
source_counts={}
for component in ('runtime','rules','judge','aggregate'):
    bundle=load(repo/f'evaluation/releases/source-bundles/{component}.json')
    assert plain_sha({k:v for k,v in bundle.items() if k!='bundle_sha256'})==bundle['bundle_sha256']
    roots=['evaluation/src/learning_agent_eval'] + (['backend/app'] if component=='runtime' else [])
    with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive','HEAD','--',*roots]))) as tar:
        git_files={m.name:tar.extractfile(m).read() for m in tar if m.isfile() and m.name.endswith('.py')}
    assert set(git_files)=={f['relative_path'] for f in bundle['files']}
    for f in bundle['files']:
        payload=(repo/f['relative_path']).read_bytes()
        assert payload==git_files[f['relative_path']] and len(payload)==f['size'] and raw_sha(payload)==f['sha256']
    source_counts[component]=len(git_files)
summary['source_files']=source_counts

probe=base/'source-mutation-probe';probe.mkdir()
for folder in ('evaluation/src/learning_agent_eval','backend/app'):
    shutil.copytree(repo/folder,probe/folder,ignore=shutil.ignore_patterns('__pycache__'))
components=('aggregate','judge','rules','runtime')
def digests(): return {c:build_source_bundle(c,project_root=probe)['bundle_sha256'] for c in components}
initial=digests(); p=probe/'evaluation/src/learning_agent_eval/action_protocol.py'; original=p.read_bytes();p.write_bytes(original+b'\n# E4 source-byte mutation probe\n')
assert all(digests()[c]!=initial[c] for c in components);p.write_bytes(original)
(probe/'unrelated.md').write_text('Unrelated source-binding probe\n');assert digests()==initial
p=probe/'backend/app/tools/registry.py';p.write_bytes(p.read_bytes()+b'\n# E4 product-byte mutation probe\n')
changed=digests();assert {c for c in components if changed[c]!=initial[c]}=={'runtime'}
summary['real_source_mutations']=['action_protocol: all four changed','unrelated Markdown: none changed','product registry: runtime only changed']

data=repo/'evaluation/datasets/decisionbench-v1-candidate'
for name in ('primary','calibration'):
    assert validate_dataset(data/name).ok
    suite=load(data/name/'manifest.json');benchmark=load(data/name/'benchmark-release.json')
    assert suite['evaluation_protocol_release_sha256']==benchmark['evaluation_protocol_release_sha256']==protocol['release_sha256']
summary['reviewed_suites']={'primary':48,'calibration':24}

runtime=base/'calibration-runtime';rules=base/'calibration-rules'
assert validate_dataset(runtime).ok and validate_dataset(rules).ok
manifest=load(runtime/'run-manifest.json');terminals=manifest['terminals']
assert len(terminals)==24 and len({t['case_id'] for t in terminals})==24
assert all(t['terminal_kind']=='episode' for t in terminals)
cases={load(p)['case_spec_sha256']:load(p) for p in (data/'calibration/cases').glob('*.json')}
stats={q:{'episodes':0,'hard_gates':0,'model_calls':0} for q in ('good','mild','severe')}
blinding=[]
hidden=('calibration-c','primary-s','assistant_case_author','delegated_ai_reviewer','pending_human_review','content-review.json','quality_label','mutation_source','reviewer_role','adjudication_note')
for path in sorted((runtime/'episodes').glob('*.json')):
    episode=load(path);eid=episode['episode_id'];case=cases[episode['case_spec_sha256']];q=case['private_annotations']['quality_label']
    rule=load(rules/'rules'/f'{eid}.json');reference=load(runtime/'judge-references'/f'{eid}.json')
    projection=build_blind_judge_input_v3(episode,rule,reference)
    for view in [projection.document]+[call['visible_context'] for call in episode['observable_trace']['model_calls']]:
        text=json.dumps(view,ensure_ascii=False)
        assert not any(marker in text for marker in hidden), eid
    assert bool(rule['hard_gates']) == (q=='severe')
    stats[q]['episodes']+=1;stats[q]['hard_gates']+=bool(rule['hard_gates']);stats[q]['model_calls']+=len(episode['observable_trace']['model_calls'])
    blinding.append({'episode_id':eid,'case_sha256':case['case_spec_sha256'],'blind_projection_sha256':projection.sha256})
summary['calibration']={'unique_terminals':24,'failures':0,'quality_counts':stats,'agent_contexts_and_judge_projections_checked':24,'blinding':blinding,'real_judge_calls':0}

archives=[]
for index in sorted((repo/'evaluation/artifacts/e4-candidate-20260905').glob('*.inventory.json')):
    inventory=load(index);archive=index.with_name(index.name.removesuffix('.inventory.json'))
    assert raw_sha(archive.read_bytes())==inventory['sha256']
    with tarfile.open(archive) as tar:
        files={m.name:tar.extractfile(m).read() for m in tar if m.isfile()}
    assert set(files)=={m['path'] for m in inventory['members']}
    for m in inventory['members']:
        assert len(files[m['path']])==m['bytes'] and raw_sha(files[m['path']])==m['sha256']
    archives.append({'archive':archive.name,'files':len(files),'sha256':inventory['sha256']})
assert subprocess.run(['git','diff','--exit-code','a875ea0','--','evaluation/artifacts/e4-candidate-20260905','evaluation/artifacts/e4-handoff-20260905'],capture_output=True).returncode==0
summary['history_archives']=archives
(base/'independent-checks.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in {'calibration','history_archives'}},ensure_ascii=False))
print('calibration',stats,'verified_historical_archives',len(archives))
