const net = require('node:net');
const dns = require('node:dns');
function allowed(host) {
  return host == null || host === 'localhost' || host === '::1' || /^127\./.test(host);
}
function denied() { const error = new Error('e4_non_loopback_network_blocked'); error.code = 'EACCES'; throw error; }
const connect = net.Socket.prototype.connect;
net.Socket.prototype.connect = function (...args) {
  let options = args[0];
  if (Array.isArray(options)) options = options[0];
  const host = typeof options === 'object' ? options.host : (typeof args[1] === 'string' ? args[1] : undefined);
  if (!allowed(host)) denied();
  return connect.apply(this, args);
};
for (const method of ['lookup', 'resolve', 'resolve4', 'resolve6', 'resolveAny', 'resolveCname']) {
  const original = dns[method];
  dns[method] = function (host, ...args) { if (!allowed(host)) denied(); return original.call(this, host, ...args); };
}
