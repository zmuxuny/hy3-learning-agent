"""Additional process guard for isolated E4 validation."""
import ipaddress
import os
import sys
from pathlib import Path

original = Path('/root/workspace/tencent_rhinobird2026/learning_travel')
forbidden = [original / name for name in ('.env', '.env.local', 'data', 'learning_companion.db', 'backend/data', 'backend/learning_companion.db')]

def audit(event, args):
    if event == 'open' and isinstance(args[0], (str, bytes, os.PathLike)):
        path = Path(os.fsdecode(args[0])).resolve()
        if any(path == target or path.is_relative_to(target) for target in forbidden):
            raise PermissionError('e4_original_runtime_file_blocked')
    if event == 'socket.getaddrinfo':
        host = args[0]
    elif event in {'socket.connect', 'socket.connect_ex'} and isinstance(args[1], tuple):
        host = args[1][0]
    else:
        return
    if isinstance(host, bytes): host = host.decode('ascii')
    if host in {'localhost', None}: return
    try:
        if ipaddress.ip_address(host).is_loopback: return
    except ValueError:
        pass
    raise PermissionError('e4_non_loopback_network_blocked')

sys.addaudithook(audit)
