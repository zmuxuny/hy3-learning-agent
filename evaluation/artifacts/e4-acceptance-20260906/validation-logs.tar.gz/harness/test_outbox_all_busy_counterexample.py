import importlib.util
import sys
from pathlib import Path

import pytest

spec = importlib.util.spec_from_file_location(
    'e4_original_h2',
    Path.cwd() / 'tests/hardening/test_h2_transaction_protocol.py',
)
original = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = original
spec.loader.exec_module(original)
sqlite_factory = original.sqlite_factory


@pytest.mark.asyncio
async def test_original_storm_with_retryable_initial_writer_exhaustion(sqlite_factory, monkeypatch):
    async def busy_writer(_self, **_kwargs):
        raise original.DatabaseBusyError('Deterministic initial writer exhaustion probe.')

    monkeypatch.setattr(original.NotificationService, 'send', busy_writer)
    await original.test_bounded_duplicate_notification_storm_delivers_one_receipt_and_transport(
        sqlite_factory, monkeypatch
    )
