"""Synthetic compatibility probes; every generated response uses the shared ledger."""
import asyncio,json,os,subprocess,time
from pathlib import Path
from datetime import datetime,timezone
from openai import AsyncOpenAI
from learning_agent_eval.canonical import canonical_json_bytes
from learning_agent_eval.model_budget import ModelBudget
from learning_agent_eval.provider_config import configured_endpoint
from learning_agent_eval.active_runtime import run_active_runtime
from learning_agent_eval.active_rules import evaluate_active_rules
from learning_agent_eval.active_judge import evaluate_active_judges
from learning_agent_eval.case_specs import episode_id_for_case

root=Path('/tmp/learning-provider-_obi7pa1');ledger=Path('/root/.local/state/learning-travel/e4-hy3-20260905-osj4FCZZ-budget.json');endpoint=configured_endpoint();budget=ModelBudget(ledger);clone=Path.cwd();assert not subprocess.check_output(['git','status','--porcelain'],text=True);commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
write=lambda p,d:p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
async def probes():
 async with AsyncOpenAI(api_key=os.environ['OPENAI_API_KEY'],base_url=endpoint.api_base,max_retries=0,timeout=90) as client:
  for name,extra in [('tool_call',{'tools':[{'type':'function','function':{'name':'echo','description':'Echo a word.','parameters':{'type':'object','properties':{'word':{'type':'string'}},'required':['word'],'additionalProperties':False}}}],'tool_choice':{'type':'function','function':{'name':'echo'}}}),('stream',{'stream':True,'stream_options':{'include_usage':True}})]:
   body={'model':'hy3','messages':[{'role':'user','content':'Call echo with word ready.' if name=='tool_call' else 'Reply with the single word READY.'}],'max_tokens':2048,'temperature':0,'reasoning_effort':'high',**extra}
   ticket=budget.reserve(scope='provider_compatibility',call_id=name,input_limit=len(canonical_json_bytes(body))+2048,output_limit=2048);usage=None;record={'probe':name,'api_base':endpoint.api_base,'source_commit':commit,'budget_ticket':ticket,'request':body,'started_at':datetime.now(timezone.utc).isoformat(),'formal':False};outcome='provider_error'
   try:
    reply=await client.chat.completions.create(**body)
    if name=='stream':
     text=[];count=0
     async for chunk in reply:
      count+=1
      if chunk.usage:usage={k:getattr(chunk.usage,k) for k in ['prompt_tokens','completion_tokens','total_tokens']}
      if chunk.choices and chunk.choices[0].delta.content:text.append(chunk.choices[0].delta.content)
     record.update(content=''.join(text),chunk_count=count,passed='READY' in ''.join(text));outcome='complete'
    else:
     if reply.usage:usage={k:getattr(reply.usage,k) for k in ['prompt_tokens','completion_tokens','total_tokens']}
     calls=[{'id':x.id,'name':x.function.name,'arguments':x.function.arguments} for x in reply.choices[0].message.tool_calls or []]
     record.update(response_model=reply.model,provider_request_id=reply.id,tool_calls=calls,finish_reason=reply.choices[0].finish_reason,passed=bool(calls) and calls[0]['name']=='echo' and json.loads(calls[0]['arguments'])=={'word':'ready'});outcome='complete'
   except Exception as exc:record.update(passed=False,error_type=type(exc).__name__,http_status=getattr(exc,'status_code',None))
   finally:
    budget.settle(ticket,usage);budget.record_outcome(ticket,outcome=outcome);record.update(usage=usage,completed_at=datetime.now(timezone.utc).isoformat());write(root/f'probe-{name}.json',record);print(name,record['passed'],flush=True)
asyncio.run(probes())
dataset=clone/'evaluation/datasets/decisionbench-v1.6-regression/development';case=json.loads((dataset/'cases/case-0001.json').read_text());selected=episode_id_for_case(case);t=time.monotonic()
try:
 run_active_runtime(dataset=dataset,manifest=dataset/'manifest.json',output=root/'smoke/runtime',episode_ids={selected},model_mode='real',allow_real_model=True,budget_ledger=ledger)
 evaluate_active_rules(input_path=root/'smoke/runtime',output=root/'smoke/rules')
 if list((root/'smoke/runtime/episodes').glob('*.json')):
  evaluate_active_judges(episodes=root/'smoke/runtime',rules=root/'smoke/rules',output=root/'smoke/judge',judge_mode='real',allow_real_judge=True,budget_ledger=ledger)
 write(root/'smoke-execution.json',{'source_commit':commit,'case_id':case['case_id'],'episode_id':selected,'api_base':endpoint.api_base,'seconds':time.monotonic()-t,'finished':True,'formal':False});print('smoke_finished',flush=True)
except Exception as exc:
 write(root/'smoke-execution.json',{'source_commit':commit,'case_id':case['case_id'],'error_type':type(exc).__name__,'seconds':time.monotonic()-t,'formal':False});print('smoke_failed',type(exc).__name__,flush=True)
