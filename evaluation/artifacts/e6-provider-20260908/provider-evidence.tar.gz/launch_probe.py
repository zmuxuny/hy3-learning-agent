import os,subprocess
from pathlib import Path
from dotenv import dotenv_values
root=Path('/tmp/learning-provider-_obi7pa1');clone=root/'run-copy';repo=Path('/root/workspace/tencent_rhinobird2026/learning_travel');d=dotenv_values(repo/'.env');env={**os.environ,'PYTHONPATH':str(clone/'evaluation/src')+':'+str(clone/'backend'),'PYTHONDONTWRITEBYTECODE':'1'}
for k in ['OPENAI_API_BASE','OPENAI_API_KEY','MODEL_NAME']:env[k]=d[k]
with (root/'probe-execution.log').open('x') as log:
 p=subprocess.run([str(repo/'.venv/bin/python'),str(root/'probe_provider.py')],cwd=clone,env=env,stdout=log,stderr=subprocess.STDOUT)
print({'exit_code':p.returncode})
