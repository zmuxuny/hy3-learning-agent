import re,json
from pathlib import Path
root=Path('/tmp/learning-e6-repair-hoxki28l');rows=[]
for p in sorted([*root.glob('*.log'),*root.glob('logs/*regression*.log'),*root.glob('logs/*offline*.log')]):
 text=p.read_text(errors='replace'); matches=re.findall(r'^.*\b\d+ (?:passed|failed|error)[^\n]*$',text,re.M);meta=p.with_suffix('.execution.json');rows.append({'path':str(p.relative_to(root)),'summary_lines':matches[-4:],'execution':json.loads(meta.read_text()) if meta.exists() else None,'note':'Keep original failures and corrected runs; overlapping tests must not be summed.'})
p=Path('evaluation/artifacts/e6-repair-20260908/method-validation/regression-index.json');p.write_text(json.dumps({'version':'e6-repair-regression-index-v1','rows':rows},ensure_ascii=False,indent=2)+'\n');print(json.dumps([{'path':r['path'],'summary':r['summary_lines'][-1:] } for r in rows],ensure_ascii=False))
