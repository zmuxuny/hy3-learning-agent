import io,tarfile,subprocess,json,hashlib
from pathlib import Path
root=Path.cwd(); out=Path('/tmp/learning-e6-repair-hoxki28l/source-snapshots');out.mkdir(exist_ok=True);rows=[]
for short in ['267127d','4e6c1c1','2e7a4db','1ae8cd2','c25da44','1f1f35f']:
 sha=subprocess.check_output(['git','rev-parse',short],text=True).strip(); tracked=subprocess.check_output(['git','ls-tree','-r','--name-only',sha],text=True).splitlines(); prefixes=('tests/','backend/','evaluation/src/','evaluation/scripts/','evaluation/tests/','scripts/e6_approval_probe.py'); paths=[p for p in tracked if p.startswith(prefixes) or p in ('pyproject.toml','uv.lock','evaluation/pyproject.toml')]; data=subprocess.check_output(['git','archive',sha,'--',*paths]); target=out/short;target.mkdir(exist_ok=True)
 with tarfile.open(fileobj=io.BytesIO(data)) as tar:tar.extractall(target,filter='data')
 rows.append({'commit':sha,'file_count':sum(p.is_file() for p in target.rglob('*')),'archive_input_sha256':hashlib.sha256(data).hexdigest(),'purpose':'tracked public implementation and tests only; no .env, data, git internals or old artifacts'})
(out/'manifest.json').write_text(json.dumps(rows,indent=2)+'\n');print(rows)
