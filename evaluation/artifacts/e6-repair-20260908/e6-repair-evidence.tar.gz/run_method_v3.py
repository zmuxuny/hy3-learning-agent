import argparse,json,subprocess,sys
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
root=Path(__file__).parent;p=argparse.ArgumentParser();p.add_argument('part',choices=['cal','dev','controlled']);a=p.parse_args()
def call(name,cmd,paid=False,allowed=(0,2)):
 args=[sys.executable,str(root/'invoke.py'),'--clone',str(root/'run-v3'),'--log',str(root/'logs'/f'{name}-v3.log')]+(['--paid'] if paid else [])+['--',*cmd]
 result=subprocess.run(args)
 if result.returncode not in allowed:raise RuntimeError(f'{name} failed: {result.returncode}')
old=json.loads((root/'logs'/f'{a.part if a.part!="controlled" else "controlled"}-runtime-v1.execution.json').read_text())
cmd=[x.replace('method-v1','method-v3').replace('development-v1','development-v3').replace('decisionbench-v1.1','decisionbench-v1.3') for x in old['command'][1:]]
call(a.part+'-runtime',cmd,old['paid_enabled'])
runtime=root/'method-v3'/({'cal':'runtime','dev':'dev-runtime','controlled':'controlled-runtime'}[a.part]);rules=runtime.parent/({'cal':'rules','dev':'dev-rules','controlled':'controlled-rules'}[a.part])
call(a.part+'-rules',['-m','learning_agent_eval','evaluate-rules','--input',str(runtime),'--output',str(rules)])
ledger='/root/.local/state/learning-travel/e4-hy3-20260905-osj4FCZZ-budget.json'
if a.part=='cal':
 pass
elif a.part=='controlled':
 def judge(n):call(f'controlled-judge-r{n}',['-m','learning_agent_eval','evaluate-judge','--episodes',str(runtime),'--rules',str(rules),'--output',str(root/f'method-v3/controlled-judge-r{n}'),'--judge-mode','real','--allow-real-judge','--budget-ledger',ledger],True)
 with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(judge,[1,2,3]))

if a.part=='dev':
 call('dev-judge',['-m','learning_agent_eval','evaluate-judge','--episodes',str(runtime),'--rules',str(rules),'--output',str(root/'method-v3/dev-judge'),'--judge-mode','real','--allow-real-judge','--budget-ledger',ledger],True)
