"""Read-only request accounting; never modifies or releases the shared ledger."""
import argparse,json,hashlib
from pathlib import Path
from collections import Counter
p=argparse.ArgumentParser();p.add_argument('--final',action='store_true');a=p.parse_args();root=Path('/tmp/learning-e6-repair-hoxki28l'); ledger=Path('/root/.local/state/learning-travel/e4-hy3-20260905-osj4FCZZ-budget.json');data=ledger.read_bytes();d=json.loads(data);start=json.loads((root/'budget-start.json').read_text());req=d['requests'];used={};errors=[]
def assign(ticket,source,usage=None,check_usage=False):
 if ticket in used:errors.append({'duplicate_ticket':ticket,'source':source});return
 if not 491<=ticket<=len(req):errors.append({'out_of_turn_ticket':ticket,'source':source});return
 if check_usage and req[ticket-1]['token_usage']!=usage:errors.append({'usage_mismatch':ticket,'source':source})
 used[ticket]=source
for group in ['method-v1','method-v2','method-v3','method-v4','formal']:
 for f in sorted((root/group).rglob('*attempts.jsonl')):
  if any(x.startswith('.') for x in f.relative_to(root).parts):continue
  for i,line in enumerate(f.read_text().splitlines(),1):
   row=json.loads(line);ticket=row.get('budget_ticket')
   if ticket is not None:assign(ticket,f'{f.relative_to(root)}:{i}')
for group in ['product-experience-v1','product-plan-experience-v1','product-plan-experience-v2']:
 f=root/group/'public-calls.jsonl'
 for i,line in enumerate(f.read_text().splitlines(),1):
  row=json.loads(line);assign(row['budget_ticket'],f'{f.relative_to(root)}:{i}',row['token_usage'],True)
for group in ['method-v1','method-v2','method-v3','formal']:
 folder=root/group/('runtime' if group=='formal' else 'dev-runtime');manifest=folder/'run-manifest.json'
 if not manifest.exists():continue
 m=json.loads(manifest.read_text())
 for t in m['terminals']:
  f=folder/('episodes' if t['terminal_kind']=='episode' else 'failures')/(t['artifact_id']+'.json');e=json.loads(f.read_text());calls=e.get('observable_trace',{}).get('model_calls',[])
  for call in calls:
   candidates=[r for r in req[490:] if r['ticket'] not in used and r['scope']==t['case_id'] and r['call_id']==call['call_id'] and r['token_usage']==call['token_usage']]
   if len(candidates)!=1:errors.append({'agent_request_match_count':len(candidates),'source':str(f.relative_to(root)),'call_id':call['call_id']});continue
   assign(candidates[0]['ticket'],f"{f.relative_to(root)}:{call['call_id']}")
for r in req:
 u=r['token_usage']
 if u is not None and r['charged_micro_cny']!=u['prompt_tokens']*d['input_rate']+u['completion_tokens']*d['output_rate']:errors.append({'cost_arithmetic':r['ticket']})
occupied=sum(r['charged_micro_cny'] for r in req);unmatched=[r['ticket'] for r in req[490:] if r['ticket'] not in used]
if a.final and (unmatched or any(r['status']=='reserved' for r in req)):errors.append({'final_incomplete_accounting':unmatched})
assert req[:490]==start['requests'] and d['authorization_adjustments']==start['authorization_adjustments'] and d['limit_micro_cny']==34609982
parts={}
for label,rows in [('historical',req[:490]),('this_turn',req[490:]),('method_and_experience',req[490:771]),('formal',req[771:])]:
 parts[label]={'requests':len(rows),'occupied_micro_cny':sum(r['charged_micro_cny'] for r in rows),'settled_micro_cny':sum(r['charged_micro_cny'] for r in rows if r['status']=='settled'),'states':dict(Counter(r['status'] for r in rows)),'outcomes':dict(Counter(r.get('outcome','agent_no_separate_outcome') for r in rows))}
report={'version':'e6-repair-request-accounting-v1','final':a.final,'ledger_sha256':hashlib.sha256(data).hexdigest(),'ledger_path':str(ledger),'historical_490_unchanged':True,'authorization_unchanged':True,'limit_micro_cny':d['limit_micro_cny'],'occupied_micro_cny':occupied,'remaining_micro_cny':d['limit_micro_cny']-occupied,'within_limit':occupied<=d['limit_micro_cny'],'cloud_bill_verified':False,'parts':parts,'artifact_matched_requests':len(used),'unmatched_requests':unmatched,'errors':errors,'matches':[{'ticket':ticket,'source':source} for ticket,source in sorted(used.items())]}
(root/('budget-audit-final.json' if a.final else 'budget-audit-progress.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
if a.final:(root/'budget-final.json').write_bytes(data)
print(json.dumps({k:report[k] for k in ['final','occupied_micro_cny','remaining_micro_cny','artifact_matched_requests','unmatched_requests','errors']},ensure_ascii=False))
raise SystemExit(1 if errors else 0)
