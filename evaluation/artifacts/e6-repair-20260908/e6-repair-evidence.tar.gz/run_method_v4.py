import argparse,json,subprocess,sys
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
root=Path(__file__).parent;p=argparse.ArgumentParser();p.add_argument('part',choices=['cal','dev','controlled']);a=p.parse_args()
def call(name,cmd,paid=False,allowed=(0,2)):
 args=[sys.executable,str(root/'invoke.py'),'--clone',str(root/'run-v4'),'--log',str(root/'logs'/f'{name}-v4.log')]+(['--paid'] if paid else [])+['--',*cmd]
 result=subprocess.run(args)
 if result.returncode not in allowed:raise RuntimeError(f'{name} failed: {result.returncode}')
old=json.loads((root/'logs'/f'{a.part if a.part!="controlled" else "controlled"}-runtime-v1.execution.json').read_text())
cmd=[x.replace('method-v1','method-v4').replace('development-v1','development-v4').replace('decisionbench-v1.1','decisionbench-v1.4') for x in old['command'][1:]]
if a.part=='cal':
 import hashlib
 dataset=Path('/tmp/learning-e6-repair-hoxki28l/run-v4/evaluation/datasets/decisionbench-v1.4-regression/calibration')
 for f in (dataset/'cases').glob('*.json'):
  c=json.loads(f.read_text())
  if c['track']=='assessment' and c['private_annotations']['quality_label'] in ['good','mild']:
   cmd.extend(['--episode-id','episode-'+c['case_spec_sha256'][:24]])
call(a.part+'-runtime',cmd,old['paid_enabled'])
runtime=root/'method-v4'/({'cal':'runtime','dev':'dev-runtime','controlled':'controlled-runtime'}[a.part]);rules=runtime.parent/({'cal':'rules','dev':'dev-rules','controlled':'controlled-rules'}[a.part])
call(a.part+'-rules',['-m','learning_agent_eval','evaluate-rules','--input',str(runtime),'--output',str(rules)])
ledger='/root/.local/state/learning-travel/e4-hy3-20260905-osj4FCZZ-budget.json'
if a.part=='cal':
 call('focused-judge',[str(root/'focused_judge_v4.py'),'--root',str(root/'method-v4'),'--ledger',ledger],True)
elif a.part=='controlled':
 def judge(n):call(f'controlled-judge-r{n}',['-m','learning_agent_eval','evaluate-judge','--episodes',str(runtime),'--rules',str(rules),'--output',str(root/f'method-v4/controlled-judge-r{n}'),'--judge-mode','real','--allow-real-judge','--budget-ledger',ledger],True)
 with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(judge,[1,2,3]))
