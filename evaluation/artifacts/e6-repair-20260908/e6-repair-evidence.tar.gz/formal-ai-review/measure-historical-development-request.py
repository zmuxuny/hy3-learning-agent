#!/usr/bin/env python3
from pathlib import Path
p=Path(__file__).with_name('reproduce-judge-input-rejection.py');exec(compile(p.read_text().split('attempts=')[0].replace("source-snapshots/1f1f35f","source-snapshots/1ae8cd2"),str(p),'exec'))
rows=[]
for ep in sorted((ROOT/'method-v3/dev-runtime/episodes').glob('*.json')):
 episode=load(ep);blind=build_blind_judge_input_v3(episode,load(ROOT/'method-v3/dev-rules/rules'/ep.name),load(ROOT/'method-v3/dev-runtime/judge-references'/ep.name));req=build_provider_request_v3(blind);rows.append({'episode_id':episode['episode_id'],'case_key':episode['scenario_family_id']+'-'+episode['track'],'wire_bytes':size(body(req)),'input_bound':size(body(req))+2048,'blind_sha256':blind.sha256})
report={'frozen_source_commit':'1ae8cd2','method':'historical actual Development source reconstruction, no network or budget','judge_prompt_sha256':JUDGE_PROMPT_SHA256_V3,'records':rows,'max_input_bound':max(r['input_bound']for r in rows),'input_limit':INPUT_LIMIT};(OUT/'historical-development-request-sizes.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(report['max_input_bound'])
