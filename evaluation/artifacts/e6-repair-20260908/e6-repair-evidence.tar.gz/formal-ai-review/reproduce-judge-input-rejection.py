#!/usr/bin/env python3
"""ZERO NETWORK, ZERO LEDGER ACCESS. Frozen 1f1f35f request reproduction.
Run with project .venv/bin/python. Outputs only beside this script.
"""
import copy,hashlib,json,sys,urllib.request
from pathlib import Path
ROOT=Path('/tmp/learning-e6-repair-hoxki28l');SRC=ROOT/'source-snapshots/1f1f35f';OUT=ROOT/'formal-ai-review'
sys.path.insert(0,str(SRC/'evaluation/src'))
from learning_agent_eval.active_judge import build_provider_request_v3,OpenAICompatibleHy3JudgeProviderV3
from learning_agent_eval.blinding_v2 import build_blind_judge_input_v3
from learning_agent_eval.canonical import canonical_json_bytes
from learning_agent_eval.judge_request_projection import evidence_catalog,pack_shared_values,unpack_shared_values
from learning_agent_eval.model_budget import INPUT_LIMIT
from learning_agent_eval.rubric import JUDGE_CONFIG_DOCUMENT_V3,JUDGE_PROMPT_SHA256_V3
from learning_agent_eval.runtime_metadata import HY3_MODEL
class OfflineBudgetBoundary(BaseException):pass
class NoLedger:
 def reserve(self,**kwargs):raise OfflineBudgetBoundary()
def no_network(*a,**k):raise AssertionError('network_forbidden')
urllib.request.urlopen=no_network
load=lambda p:json.loads(p.read_text());size=lambda d:len(canonical_json_bytes(d));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def body(req):return {'model':HY3_MODEL,'messages':req['messages'],'temperature':JUDGE_CONFIG_DOCUMENT_V3['temperature'],'reasoning_effort':JUDGE_CONFIG_DOCUMENT_V3['reasoning_effort'],'response_format':req['response_format'],'max_tokens':JUDGE_CONFIG_DOCUMENT_V3['max_tokens'],'n':1}
def enum_nodes(x,path='$'):
 out=[]
 if isinstance(x,dict):
  if 'enum'in x and isinstance(x['enum'],list)and any(isinstance(v,str)and v.startswith('observable_trace')for v in x['enum']):out.append((path,x))
  for k,v in x.items():out+=enum_nodes(v,path+'.'+k)
 elif isinstance(x,list):
  for i,v in enumerate(x):out+=enum_nodes(v,f'{path}[{i}]')
 return out
def compact_enum(req):
 q=copy.deepcopy(req);schema=q['response_format']['json_schema']['schema'];nodes=enum_nodes(schema);catalog=nodes[0][1]['enum'] if nodes else []
 for _,node in nodes:
  assert node['enum']==catalog
  node.clear();node['$ref']='#/$defs/EvidencePath'
 if nodes:schema.setdefault('$defs',{})['EvidencePath']={'type':'string','enum':catalog}
 return q
attempts=[json.loads(l)for l in(ROOT/'formal/judge-attempts.jsonl').read_text().splitlines()];attempt_by={x['episode_id']:x for x in attempts if x['attempt']==1}
rows=[]
scopes=[('formal',ROOT/'formal/runtime',ROOT/'formal/rules'),('development-v3',ROOT/'method-v3/dev-runtime',ROOT/'method-v3/dev-rules'),('calibration-v2',ROOT/'method-v2/runtime',ROOT/'method-v2/rules')]
for scope,runtime,rules in scopes:
 for ep in sorted((runtime/'episodes').glob('*.json')):
  episode=load(ep); rp=rules/'rules'/ep.name;refp=runtime/'judge-references'/ep.name;rule=load(rp);reference=load(refp)
  blind=build_blind_judge_input_v3(episode,rule,reference);req=build_provider_request_v3(blind);wire=canonical_json_bytes(body(req));packed=pack_shared_values(blind.document);assert unpack_shared_values(packed)==blind.document
  catalog=evidence_catalog(blind.document['episode']); nodes=enum_nodes(req['response_format']); candidate=compact_enum(req);cw=canonical_json_bytes(body(candidate))
  provider=OpenAICompatibleHy3JudgeProviderV3.__new__(OpenAICompatibleHy3JudgeProviderV3);provider.budget=NoLedger();provider.calls=0;provider.scope='offline';provider._api_key='never-used'
  try:provider.complete(req);raise AssertionError('unexpected_return')
  except ValueError as e:exc={'type':'ValueError','message':str(e),'budget_reserve_reached':False,'provider_calls_counter':provider.calls}
  except OfflineBudgetBoundary:exc={'type':'OfflineBudgetBoundary','message':'input check passed; stopped before any ledger access','budget_reserve_reached':True,'provider_calls_counter':provider.calls}
  attempt=attempt_by.get(episode['episode_id']) if scope=='formal'else None
  doc=blind.document;row={'scope':scope,'case_key':episode['scenario_family_id']+'-'+episode['track'],'episode_id':episode['episode_id'],'episode_bytes':ep.stat().st_size,'source_files':[{'path':str(p.relative_to(ROOT)),'sha256':sha(p)}for p in[ep,rp,refp]],'blind_input_sha256':blind.sha256,'attempt_blind_sha_matches':attempt['blind_input_sha256']==blind.sha256 if attempt else None,'attempt_validation_codes':attempt['validation_error_codes']if attempt else None,'blind_document_bytes':size(doc),'packed_document_bytes':size(packed),'packing_lossless_roundtrip':True,'wire_bytes':len(wire),'wire_sha256':hashlib.sha256(wire).hexdigest(),'input_bound':len(wire)+2048,'input_limit':INPUT_LIMIT,'exceeds_by':max(0,len(wire)+2048-INPUT_LIMIT),'actual_offline_exception':exc,'max_output_tokens':JUDGE_CONFIG_DOCUMENT_V3['max_tokens'],'catalog_paths':len(catalog),'catalog_json_bytes':size(catalog),'schema_enum_copies':len(nodes),'enum_node_locations':[n[0]for n in nodes],'schema_bytes':size(req['response_format']),'messages_bytes':size(req['messages']),'system_content_utf8_bytes':len(req['messages'][0]['content'].encode()),'user_content_utf8_bytes':len(req['messages'][1]['content'].encode()),'blind_sections_bytes':{k:size(v)for k,v in doc.items()},'episode_sections_bytes':{k:size(v)for k,v in doc['episode'].items()},'shared_enum_candidate':{'wire_bytes':len(cw),'input_bound':len(cw)+2048,'saved_bytes':len(wire)-len(cw),'passes_input_limit':len(cw)+2048<=INPUT_LIMIT,'same_path_set':True,'network_validation':False}}
  rows.append(row)
report={'reviewer':'second development AI; not independent human','frozen_source_commit':'1f1f35f','judge_prompt_sha256':JUDGE_PROMPT_SHA256_V3,'offline_safety':'Provider __new__ skips credential/ledger init; NoLedger reserve raises before any ledger access; urlopen replaced with fatal sentinel; no provider request or budget mutation.','input_limit_semantics':'Frozen provider conservatively uses canonical UTF-8 wire bytes +2048 as input-token upper bound, not tokenizer token count; compares to 196608 before reserve and network.','records':rows,'source_file_hashes':[{'path':str(p.relative_to(ROOT)),'sha256':sha(p)}for p in[SRC/'evaluation/src/learning_agent_eval/active_judge.py',SRC/'evaluation/src/learning_agent_eval/judge_request_projection.py',SRC/'evaluation/src/learning_agent_eval/model_budget.py',SRC/'evaluation/src/learning_agent_eval/blinding_v2.py',SRC/'evaluation/src/learning_agent_eval/rubric.py']]}
(OUT/'judge-input-offline-measurements.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
for scope,_,_ in scopes:
 rs=[r for r in rows if r['scope']==scope];bad=[r for r in rs if r['exceeds_by']];print(scope,len(rs),'max',max(r['input_bound']for r in rs),'rejected',len(bad))
 for r in bad:print(r['case_key'],'wire',r['wire_bytes'],'bound',r['input_bound'],'catalog',r['catalog_paths'],r['catalog_json_bytes'],'enums',r['schema_enum_copies'],'enumcandidate',r['shared_enum_candidate'])
