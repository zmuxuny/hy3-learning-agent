"""Offline unregistered candidate. No frozen source edits, no provider calls.
Same shared-json-v1 transport, lower exact-sharing threshold and shared path enum.
"""
from collections import Counter
from copy import deepcopy
from learning_agent_eval.canonical import canonical_json
from learning_agent_eval.judge_request_projection import evidence_catalog
from learning_agent_eval.active_judge import build_provider_request_v3

def pack_shared_values_candidate(document):
    counts = Counter()

    def count(value):
        encoded = canonical_json(value)
        if len(encoded.encode("utf-8")) >= 256:
            counts[encoded] += 1
        if isinstance(value, dict):
            for child in value.values():
                count(child)
        elif isinstance(value, list):
            for child in value:
                count(child)

    count(document)
    names, shared = {}, {}

    def children(value):
        if isinstance(value, dict):
            if set(value) in ({"$shared"}, {"$literal"}):
                return {"$literal": [[key, pack(child)] for key, child in value.items()]}
            return {key: pack(value[key]) for key in sorted(value)}
        if isinstance(value, list):
            return [pack(child) for child in value]
        return value

    def pack(value):
        encoded = canonical_json(value)
        if counts[encoded] > 1:
            if encoded not in names:
                name = f"v{len(names) + 1}"
                names[encoded] = name
                shared[name] = children(value)
            return {"$shared": names[encoded]}
        return children(value)

    packed = pack(document)
    return {"encoding": "shared-json-v1", "shared_values": shared, "document": packed}



def build_candidate_request(blind_input):
    request = deepcopy(build_provider_request_v3(blind_input))
    schema = request['response_format']['json_schema']['schema']
    catalog = evidence_catalog(blind_input.document['episode'])
    def share(node):
        if isinstance(node, dict):
            for key, value in list(node.items()):
                if key == 'evidence_paths' and isinstance(value, dict):
                    assert value['items'] == {'type': 'string', 'enum': catalog}
                    value['items'] = {'$ref': '#/$defs/EvidencePath'}
                else:
                    share(value)
        elif isinstance(node, list):
            for value in node:
                share(value)
    share(schema)
    schema.setdefault('$defs', {})['EvidencePath'] = {'type': 'string', 'enum': catalog}
    request['messages'][1]['content'] = canonical_json({
        **pack_shared_values_candidate(blind_input.document),
        'evidence_path_catalog': catalog,
    })
    return request
