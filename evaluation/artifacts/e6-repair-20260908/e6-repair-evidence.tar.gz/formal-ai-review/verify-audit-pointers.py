import json,re,hashlib
from pathlib import Path
root=Path('/tmp/learning-e6-repair-hoxki28l');p=root/'formal-ai-review/runtime-content-audit.json';r=json.loads(p.read_text());errors=[];n=0
for c in r['cases']:
 d=json.loads((root/c['episode_file']).read_text())
 paths=set(c['public_evidence_paths'])
 for m in c['model_calls']:paths.update([m['public_text_path'],m['visible_context_path'],m['returned_tool_calls_path']]+m['visible_tool_message_paths']);paths.update(t['argument_path']for t in m['returned_tools'])
 def walk(v,k=''):
  if isinstance(v,dict):
   for k,x in v.items():walk(x,k)
  elif isinstance(v,list):
   for x in v:walk(x,k)
  elif isinstance(v,str) and ('path'in k or k=='model_visible_original_paths') and v.startswith(('observable_trace.','state_after.','state_before.')):paths.add(v.split(' (JSON')[0])
 walk(c.get('specific_findings',[]))
 for path in paths:
  cur=d
  try:
   for key,index in re.findall(r'([^.\[\]]+)|\[(\d+)\]',path):cur=cur[int(index)]if index else cur[key]
   n+=1
  except (KeyError,IndexError,TypeError):errors.append({'case':c['case_key'],'path':path})
for f in r['source_inventory']:
 p=root/f['path']
 if not p.exists()or hashlib.sha256(p.read_bytes()).hexdigest()!=f['sha256']:errors.append({'file':f['path'],'kind':'source_hash_mismatch'})
out={'role':'second development AI verification, not independent human','checked_paths':n,'checked_source_files':len(r['source_inventory']),'errors':errors,'passed':not errors,'audit_sha256':hashlib.sha256((root/'formal-ai-review/runtime-content-audit.json').read_bytes()).hexdigest()};(root/'formal-ai-review/pointer-verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(out)
