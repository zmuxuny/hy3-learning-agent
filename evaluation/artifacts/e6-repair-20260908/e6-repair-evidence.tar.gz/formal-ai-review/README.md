# 正式 Runtime 完整公开内容审计

参与开发的第二 AI 审计，不是独立人类或盲审。48/48 Episode 已逐例复核；不调用付费模型，不改变冻结方法或原结果。

- `runtime-content-audit.json`：每例目标达成摘要、具体残余、实际调用/审批/写入、模型原始参数与生产工具参数区分、Rules 原始失败、公开证据路径和144源文件哈希。
- `manual-notes.json`：人工逐例阅读后的明确 AI 内容判断；不以家族标签或 Rule Gate 自动判 Critical。
- `pointer-verification.json`：914个路径与144源文件哈希校验。后续只要修改审计，应重跑校验。
- `compile-runtime-audit.py` / `verify-audit-pointers.py`：离线重建和校验；所有输出只在本目录。
- `*.txt`：派生阅读视图，原始完整 Episode 才是证据，可不归档这些辅助文本。

`semantic_goal=met`仅说明具体内容/行为达到本例目标，不表示通过冻结行动协议、Rules或正式验收；`met_pending_approval`不表示已实际完成写入。8条Assessment审批等待的Major是事前保留的完成度扣分，不认定为实际写入失败/越权，也不凭此认定本轮修复失败。

G03-R错误声明动作后连带patch规则、G07-A帧位置错误后连带评分规则是适用性残余；G01-I只有一次实际sent，随后第二次调用冲突失败，没有重复投递。

G09-P的实际失败被改述成功、G06-P上方向测试反转、G02-P RPN复测算错等均有精确公开证据链。等Judge实际提名后逐候选裁决，不能根据这些摘要假造Judge提名或覆盖原Rules/Judge。

## Judge 输入失败离线复现与候选

`judge-input-failure-analysis.json` 精确复现正式8条 `judge_request_rejected`：冻结源码对完整HTTP正文的UTF-8字节数+2048超过196608，在reserve/HTTP之前抛 `ValueError("judge_input_limit_exceeded")`，不是超时或预算不足。重建blind SHA与8条原始失败完全一致，源文件与git 1f1f35f匹配。

`reproduce-judge-input-rejection.py`、`measure-historical-development-request.py`、`measure-lossless-packing-candidate.py`提供完整离线量化。历史Development最大194443，距上限仅2165；新正式最长207740。schema有3份相同enum，单独共享仅修复4/8。

`judge_request_candidate.py`为隔离未登记候选：共享enum及512→256无损去重。`verify-judge-request-candidate.py`验证79条原公开轨迹、6个共享标记/阈值边界fixture；完整内容规范化字节一致，ref展开后原schema完全一致，79条全部低于上限、最大188943。它没有真实provider验证或正式资格，不能替换1.4原始结果。主端1.5使用不同$defs名称，精确请求大小还应按1.5固定源码独立重建。

复现脚本必须用项目`.venv/bin/python`执行；只读取冻结外部源码和公开材料、只写本审计目录。脚本未创建真实账本对象；网络入口由失败哨兵禁止。`candidate-verifier-corrections.json`保留离线验证器两处纠正（缺jsonschema依赖、规范化tuple/list差异），不是模型实验失败。

## 最终二AI语义裁决建议

`semantic-decisions-secondary.json` 已绑定最终48个Judge结果及run-manifest：33 complete、8输入拒绝、7预算不足。按官方`review_candidates()`实际severity字段提取，只有G07-A一个Critical提名，建议dismissed同Rule形式错误的重复归因；没有suggested_hard_gates。

另对G09-P补`reviewer:observed-failure-fabricated-as-success`，仅确认独立公开观察编造；该例仍judge_error且无分。全部公开路径和semantic_adjudication输入接口已离线校验，未改任何原始分数。主端读取`interface_reviews_secondary`后用自己的角色作最终主审，不能把本文件冒充primary或独立人类审计。

过程更正：较早进行中的快速扫描误用了不存在的`critical_candidate`字段，曾报告0提名；本最终扫描使用冻结接口定义的`severity == critical`与所有suggested gates，正确保留1个实际提名及明确裁决。原Judge字节未动。
