#!/usr/bin/env python3
from pathlib import Path
base=Path(__file__).with_name('reproduce-judge-input-rejection.py');exec(compile(base.read_text().split('attempts=')[0],str(base),'exec'))
from judge_request_candidate import build_candidate_request,pack_shared_values_candidate
previous=load(OUT/'judge-input-offline-measurements.json');rows=[]
for row in previous['records']:
 episode,rule,reference=[load(ROOT/f['path'])for f in row['source_files']];blind=build_blind_judge_input_v3(episode,rule,reference);req=build_candidate_request(blind);decoded=json.loads(req['messages'][1]['content']);assert canonical_json_bytes(unpack_shared_values(decoded))==canonical_json_bytes(blind.document)
 catalog=evidence_catalog(blind.document['episode']);assert decoded['evidence_path_catalog']==catalog
 schema=req['response_format']['json_schema']['schema']
 original_schema=build_provider_request_v3(blind)['response_format']['json_schema']['schema']
 expanded=copy.deepcopy(schema);definition=expanded['$defs'].pop('EvidencePath')
 def expand_ref(node):
  if isinstance(node,dict):
   if node=={'$ref':'#/$defs/EvidencePath'}:node.clear();node.update(copy.deepcopy(definition))
   else:
    for v in node.values():expand_ref(v)
  elif isinstance(node,list):
   for v in node:expand_ref(v)
 expand_ref(expanded);assert expanded==original_schema
 assert definition=={'type':'string','enum':catalog}
 assert 'state_before.private_unknown'not in definition['enum']
 assert len(enum_nodes(schema))==1
 sz=size(body(req));rows.append({'scope':row['scope'],'case_key':row['case_key'],'original_bound':row['input_bound'],'candidate_bound':sz+2048,'all_content_preserved':True,'same_path_set':True,'expanded_schema_identical_to_frozen':True,'rejected_invalid_path':True,'passes_input_limit':sz+2048<=INPUT_LIMIT})
# Literal shared markers and threshold boundary fixtures must survive exactly.
fixtures=[{'a':{'$shared':'v1'},'b':{'$literal':[['x','y']]}},['x'*255]*4,['y'*256]*4,{'a':{'x':'z'*260},'b':{'x':'z'*260}},{'多字节':['测试'*128]*3},['short']*10]
for f in fixtures:assert unpack_shared_values(pack_shared_values_candidate(f))==f
report={'reviewer':'second development AI; not independent human','status':'offline unregistered candidate; no provider validation, no formal eligibility','cases':rows,'roundtrip_fixture_count':len(fixtures),'source_candidate_sha256':sha(OUT/'judge_request_candidate.py'),'observed_total':len(rows),'input_rejected':sum(not r['passes_input_limit']for r in rows),'maximum_candidate_bound':max(r['candidate_bound']for r in rows),'all_content_roundtrip_exact':True,'all_path_sets_identical':True,'all_expanded_schemas_identical_to_frozen':True,'full_jsonschema_validator_run':False,'validator_limitation':'jsonschema dependency absent; verified exact equality to original Pydantic schema after expanding only new local ref instead','invalid_path_rejected':True}
(OUT/'judge-request-candidate-validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print({k:v for k,v in report.items()if k!='cases'})
