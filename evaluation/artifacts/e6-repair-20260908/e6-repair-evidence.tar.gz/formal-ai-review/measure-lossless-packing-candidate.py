#!/usr/bin/env python3
"""Isolated candidate measurement; frozen source and results are never edited."""
from pathlib import Path
base=Path(__file__).with_name('reproduce-judge-input-rejection.py')
exec(compile(base.read_text().split('attempts=')[0],str(base),'exec'))
import inspect
from collections import Counter
from learning_agent_eval.canonical import canonical_json
pack_source=inspect.getsource(pack_shared_values)
previous=load(OUT/'judge-input-offline-measurements.json');rows=[]
for row in previous['records']:
 if not row['exceeds_by']:continue
 episode,rule,reference=[load(ROOT/f['path'])for f in row['source_files']];blind=build_blind_judge_input_v3(episode,rule,reference);request=build_provider_request_v3(blind);catalog=evidence_catalog(blind.document['episode'])
 variants=[]
 for threshold in [256,128,64]:
  ns={'Counter':Counter,'canonical_json':canonical_json};exec(compile(pack_source.replace('>= 512',f'>= {threshold}'),'<isolated lossless threshold candidate>','exec'),ns);packed=ns['pack_shared_values'](blind.document);assert unpack_shared_values(packed)==blind.document
  q=compact_enum(request);q['messages'][1]['content']=canonical_json({**packed,'evidence_path_catalog':catalog});sz=size(body(q));variants.append({'minimum_shared_value_bytes':threshold,'wire_bytes':sz,'input_bound':sz+2048,'saved_bytes':row['wire_bytes']-sz,'passes_input_limit':sz+2048<=INPUT_LIMIT,'lossless_roundtrip':True,'shared_entries':len(packed['shared_values'])})
 rows.append({'case_key':row['case_key'],'original_input_bound':row['input_bound'],'variants':variants})
report={'status':'isolated candidate only; no formal qualification or provider validation','method':'Shared schema enum plus changing existing exact duplicate minimum serialized-byte threshold; no evidence removal, no meaning/paths changes, same shared-json-v1 decoder.','cases':rows};(OUT/'judge-lossless-candidate-measurements.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
for r in rows:print(r['case_key'],r['original_input_bound'],[(x['minimum_shared_value_bytes'],x['input_bound'])for x in r['variants']])
