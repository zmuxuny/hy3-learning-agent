import json,subprocess,sys,time
from pathlib import Path
root=Path('/tmp/learning-e6-repair-hoxki28l'); clone=root/'formal-copy'; run=root/'formal'; ledger='/root/.local/state/learning-travel/e4-hy3-20260905-osj4FCZZ-budget.json'
while not (root/'logs/formal-runtime.execution.json').exists():time.sleep(5)
r=json.loads((root/'logs/formal-runtime.execution.json').read_text())
if not (run/'runtime/run-manifest.json').exists():raise SystemExit('Runtime manifest absent; no dependent paid run')
def invoke(label,args,paid=False):
 cmd=[sys.executable,str(root/'invoke.py'),'--clone',str(clone),'--log',str(root/'logs'/f'formal-{label}.log')]
 if paid:cmd+=['--paid']
 p=subprocess.run(cmd+['--','-m','learning_agent_eval',*args]); print(label,p.returncode,flush=True)
 return p.returncode
if invoke('rules',['evaluate-rules','--input',str(run/'runtime'),'--output',str(run/'rules')]) not in (0,2):raise SystemExit('rules infrastructure failure')
invoke('judge',['evaluate-judge','--episodes',str(run/'runtime'),'--rules',str(run/'rules'),'--output',str(run/'judge'),'--judge-mode','real','--allow-real-judge','--budget-ledger',ledger],True)
if (run/'judge/run-manifest.json').exists():invoke('aggregate',['aggregate-results','--episodes',str(run/'runtime'),'--rules',str(run/'rules'),'--judges',str(run/'judge'),'--output',str(run/'aggregate')])
