"""Produce separately archived, evidence-validated reviewed CSVs; never overwrite runs.
Run with the chosen checkout's evaluation/src in PYTHONPATH and project venv.
The original Aggregate/Rule/Judge files remain authoritative and unchanged.
"""
import argparse, hashlib, json
from pathlib import Path
from learning_agent_eval.semantic_adjudication import reviewed_results, write_reviewed_csv, verify_reviewed_csv
p=argparse.ArgumentParser();p.add_argument('--snapshot',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
base=Path('/tmp/learning-e6-repair-hoxki28l/method-v1');load=lambda p:json.loads(p.read_text())
a.output.mkdir(parents=True,exist_ok=False)
episodes={p.stem:load(p) for p in (base/'runtime/episodes').glob('*.json')}
inventory=[]
for review_path in sorted(a.snapshot.glob('reviews-r*.json')):
 name=review_path.stem.removeprefix('reviews-'); aggroot=base/'experiments'/f'aggregate-{name}';judgeroot=base/'experiments'/f'judge-{name}'
 aggpaths=sorted((aggroot/'episodes').glob('*.json'));judgepaths=sorted((judgeroot/'judge-results').glob('*.json'))
 aggregates=[load(p) for p in aggpaths];judges={p.stem:load(p) for p in judgepaths};reviews=load(review_path)
 rows=reviewed_results(aggregates,judges,episodes,reviews)
 target=a.output/f'reviewed-results-{name}.csv';write_reviewed_csv(target,rows);assert verify_reviewed_csv(target,aggregates,judges,episodes)==rows
 for path in [review_path,*aggpaths,*judgepaths,target]:inventory.append({'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
(a.output/'audit-manifest.json').write_text(json.dumps({'reviewer_role':'delegated_ai_reviewer','disclosure':'参与开发的第二AI审计，非独立人类；只新增离线审查CSV，不更改原实验。','source_snapshot':str(a.snapshot.resolve()),'input_and_output_hashes':inventory,'paid_calls':0},ensure_ascii=False,indent=2)+'\n')
print('verified_csv_partitions',len(list(a.output.glob('*.csv'))))
