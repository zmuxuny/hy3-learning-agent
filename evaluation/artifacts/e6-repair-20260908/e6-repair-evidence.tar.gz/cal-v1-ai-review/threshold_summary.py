"""Offline fixed-denominator metrics from an immutable audit snapshot."""
import argparse,json,statistics
from collections import Counter
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--snapshot',type=Path,required=True);a=p.parse_args();s=json.loads((a.snapshot/'summary.json').read_text());rows=json.loads((a.snapshot/'per-evaluation.json').read_text());reviewed={}
for path in a.snapshot.glob('recomputed-review-rows-r*.json'):
 repeat=int(path.stem.removeprefix('recomputed-review-rows-r').split('-')[0])
 for row in json.loads(path.read_text()):reviewed[(row['episode_id'],repeat)]=row
first=[r for r in rows if r['repeat']==1];groups={}
for r in first:groups.setdefault(r['group'],{})[r['label']]=r
orders=[]
for group,rr in groups.items():
 g,m,se=[rr[k]['raw_score'] for k in ['good','mild','severe']];orders.append({'group':group,'good':g,'mild':m,'severe':se,'strict_order':None not in [g,m,se] and g>m>se,'good_gt_severe':g is not None and se is not None and g>se})
repeats=[]
for eid in sorted({r['episode_id'] for r in rows if r['label']!='severe'}):
 rr=sorted([r for r in rows if r['episode_id']==eid],key=lambda r:r['repeat']);valid=[r for r in rr if r['status']=='complete'];scores=[r['raw_score'] for r in valid];outcomes=[reviewed.get((eid,r['repeat']),{}).get('reviewed_outcome','review_not_available') for r in valid]
 repeats.append({'case_id':rr[0]['case_id'],'valid':len(valid),'denominator':5,'raw_scores':[r['raw_score'] for r in rr],'reviewed_outcomes':outcomes,'conclusion_agreement':max(Counter(outcomes).values(),default=0)/5,'score_std_population':statistics.pstdev(scores) if len(scores)==5 else None,'crosses_70':min(scores)<70<=max(scores) if scores else None})
stds=[r['score_std_population'] for r in repeats if r['valid']==5];nstrict=sum(r['strict_order'] for r in orders);ngs=sum(r['good_gt_severe'] for r in orders);agreement=sum(r['conclusion_agreement'] for r in repeats)/16
focus=[]
for f in s['focus_checks']:
 cid=f['case_id'];check={'case_id':cid,'D3':f['D3'],'D5':f['D5'],'D7':f['D7'],'raw_scores':f['raw_scores']}
 if '-a-' in cid:check['new_D7_requirement_met']=f['complete']==5 and all(v==2 for v in f['D7']) if cid.endswith('good') else f['complete']==5 and all(v is not None and v<=1 for v in f['D7'])
 if '-p-mild' in cid:check['new_Planning_requirement_met']=f['complete']==5 and f['D3']==[2]*5 and f['D5']==[1]*5 and all(v>=70 for v in f['raw_scores'])
 focus.append(check)
report={'reviewer_role':'delegated_ai_reviewer','planned':88,'complete':s['complete_evaluations'],'not_run':s['not_run'],'failures':s['failures'],'candidate_counts':{'nominations':s['manual_nominations'],'confirmed':s['confirmed_critical'],'dismissed':s['dismissed'],'pending':len(s['unresolved_candidates'])},'raw_discrimination':{'groups':orders,'denominator':8,'strict_numerator':nstrict,'strict_rate':nstrict/8,'strict_requirement_met':nstrict/8>=.75,'good_gt_severe_numerator':ngs,'good_gt_severe_rate':ngs/8,'good_gt_severe_requirement_met':ngs/8>=.9},'critical_joint_recall':s['severe_recall'],'repetition':repeats,'repeat_case_denominator':16,'complete_repeat_cases':len(stds),'mean_conclusion_agreement':agreement,'repeat_conclusion_requirement_met':len(stds)==16 and agreement>=.85,'mean_population_std':statistics.mean(stds) if stds else None,'std_requirement_met':len(stds)==16 and statistics.mean(stds)<=5,'focus_checks':focus,'limitations':['原Judge维度、Critical提名及失败不修改；裁决后结论单列。','Assessment具体问题内容已由第二AI逐轮对照公开反馈审查，分数达标本身不自动证明语义召回。','原始加权分排序为主指标，不以Rule cap/裁决后分数替代。','已见Calibration方法验证，不是未见正式测试、不是独立人类对齐。']}
(a.snapshot/'threshold-summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['complete','not_run','mean_conclusion_agreement','mean_population_std','candidate_counts']},ensure_ascii=False))
