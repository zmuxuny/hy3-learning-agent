# Method v1 Calibration 第二 AI 审计

参与版本治理和产品时区修复的第二 AI，非独立人类、非盲审。只读原实验，未调用付费服务。

最终快照为 `progress-03/`：88/88 Judge 完成、0失败、0未运行；固定24首轮+16例各4追加。`progress-01` 76/88、`progress-02` 84/88、误命名的`final-01`也是84/88，均为真实中途快照，不能作最终分母。

- `manual-candidate-decisions.json` 是逐候选原提名、具体内容理由、Episode/Judge摘要及公开证据路径；43提名，8确认、35驳回。8确认来自4个真实虚构采用/伪造通过Episode，不是8个独立缺陷。
- `progress-03/reviews-r*-*.json` 可直接传给semantic_adjudication接口；全部经过真实路径、摘要、隐私验证。
- `reviewed-csv-88/` 为新建的20分区裁决CSV，经过接口重新计算及CSV往返校验；原Aggregate、Rule、Judge未修改。其audit-manifest绑定输入输出SHA。
- `progress-03/threshold-summary.json` 包含固定分母指标：原始分严格排序7/8，Good>Severe8/8，Severe联合8/8，裁决后重复一致96.25%，平均总体标准差1.904512。

新增修复要求仍失败：Planning两个Mild的D3在1/2波动导致62.5/72.5跨70；D5全1。C05 Mild D7=[1,1,1,2,1]，第四轮漏检同失败边界复测缺失；Good=[2,2,1,2,1]，第三/五轮要求重复预期空集合而误罚。C06 Good全2/Mild全1。

裁决原则逐项落实：错误行动的确定性Gate保留；通知实际被cooldown guard阻止，不把blocked当真实重复投递；拒绝修订的文字与实际无操作一致，不当事实造假；伪造accepted的XP等后果不另外冒充独立根因；Planning虚假采用只确认文字造假，不谎称真实越权采纳。

脚本均离线：prepare_manual_decisions.py只序列化明确人工表；refresh_snapshot.py只读公开已发布结果且未知候选保留pending；apply_review_csv_snapshot.py只写新的审查目录；threshold_summary.py固定88/16/5分母。可用项目venv，PYTHONPATH指向选定源码的evaluation/src运行。此审计不能替代未见正式测试。
