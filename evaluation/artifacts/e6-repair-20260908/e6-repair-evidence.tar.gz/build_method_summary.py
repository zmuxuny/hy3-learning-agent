import json,shutil
from pathlib import Path
r=Path('/tmp/learning-e6-repair-hoxki28l'); out=Path('evaluation/artifacts/e6-repair-20260908/method-validation');out.mkdir(exist_ok=True)
for name in ['version-comparison.json','dev-v1-independent-ai-audit.json','dev-v3-ai-audit.json','method-v4-focused-ai-audit.json','budget-before-formal-summary.json']:
 shutil.copy2(r/name,out/name)
for v in [1,2]:
 dest=out/f'calibration-v{v}';dest.mkdir(exist_ok=True)
 for name in ['design.json','metrics-reviewed.json','per-evaluation-reviewed.json','metrics-before-adjudication.json','per-evaluation-before-adjudication.json']:shutil.copy2(r/f'method-v{v}/experiments'/name,dest/name)
source={'version':'e6-repair-evidence-index-v1','formal':False,'historical_baselines':{'E5':'40fddb8','E6_first':'b0b0d02'},'calibration_versions':{v:json.loads((out/f'calibration-v{v}/metrics-reviewed.json').read_text()) for v in [1,2]},'validation_scope':'v2 full 88; v3 7 actual Agent/Judge +24 stub Rules; v4 Assessment20 + timezone6. Never represented as final v4 full88.'}
(out/'summary.json').write_text(json.dumps(source,ensure_ascii=False,indent=2)+'\n')
print('method evidence copied')
