"""Run one frozen command, recording exact source and exit status; no credentials logged."""
import argparse,json,os,subprocess,sys,time
from pathlib import Path
from dotenv import dotenv_values
p=argparse.ArgumentParser();p.add_argument('--clone',type=Path,required=True);p.add_argument('--log',type=Path,required=True);p.add_argument('--paid',action='store_true');p.add_argument('command',nargs=argparse.REMAINDER);a=p.parse_args()
cmd=a.command[1:] if a.command and a.command[0]=='--' else a.command
env=os.environ.copy();env['PYTHONPATH']=str(a.clone/'evaluation/src')+':'+str(a.clone/'backend')
if a.paid:
 if subprocess.check_output(['git','status','--porcelain','--untracked-files=normal'],cwd=a.clone):raise ValueError('paid source dirty')
 env['OPENAI_API_KEY']=dotenv_values('/root/workspace/tencent_rhinobird2026/learning_travel/.env').get('OPENAI_API_KEY') or env.get('OPENAI_API_KEY','')
 if not env['OPENAI_API_KEY']:raise ValueError('missing authorized key')
else:env.pop('OPENAI_API_KEY',None)
start=time.time()
with a.log.open('x') as log:
 result=subprocess.run([sys.executable,*cmd],cwd=a.clone,env=env,stdout=log,stderr=subprocess.STDOUT)
row={'command':['python',*cmd],'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=a.clone,text=True).strip(),'cwd':str(a.clone),'paid_enabled':a.paid,'seconds':round(time.time()-start,3),'exit_code':result.returncode}
a.log.with_suffix('.execution.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True)
raise SystemExit(result.returncode)
