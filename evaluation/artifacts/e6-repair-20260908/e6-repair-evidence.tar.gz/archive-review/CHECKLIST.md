# E6 修复归档复核清单

身份：参与开发的第二 AI，非独立人类审计。此检查只处理原始证据完整性、分母、版本和敏感文件；不替代正式结果内容裁决。

保留以下原始材料及失败，禁止用后版结果覆盖前版：

- Method v1（267127d / Protocol 1.1）：24 个受控 Runtime 与 Rules、7 个真实 Development（含漏声明/错误 Gate）、2 个时区对照；88 个 Judge 原文/attempt JSONL/20 个原 Aggregate 分区及20个主审分区；6 个时区 Judge。
- Method v2（2e7a4db / Protocol 1.2）：同样固定 24 / 7 / 2 Runtime、88+6 Judge，保留 C05 Good误罚及Good Planning D5波动、C08 Mild第3轮Critical提名和内容裁决。原结果与裁决 CSV并存。
- Method v3（1ae8cd2 / Protocol 1.3）：24 个受控 Runtime/Rules、7 个真实 Development及7个Judge、2个时区Runtime及6个Judge；保存原始模型参数声明与业务参数剥离证据。不能宣称本版又跑88 Judge。
- Method v4（c25da44 / Protocol 1.4）：4 个 Assessment Runtime/Rules、20个固定差分Judge、2个时区Runtime及6个Judge；保存 focused/design.json、全部 attempts。不能宣称本版又跑88。
- 新正式批次（1f1f35f / Protocol1.4）：冻结前G01–G12设计、48原始输入、两版预冻结输入纠正、双AI内容复核及摘要、可信登记、固定运行计划、48 Runtime终态（Episode和Failure共同计数）、所有Rules/Judge/attempt/修复/原Aggregate/语义裁决/统计/正式资格阻断理由。
- 产品体验：product-experience-v1、product-plan-experience-v1/v2 的 facts-*.json 和完整 public-calls.jsonl。保留v1核心证据缺失及前后审批；只归档公开投影，不归档 data/ 数据库或备份。
- 唯一账本的起始、正式前和最终快照及摘要：保留原490条历史、起始占用17.609982、总上限34.609982、未知usage预留；不追加17，不清空或释放历史未知预留。
- 全部回归日志，包括首次失败、修正后成功以及命令/退出码.execution.json；保留AI审计JSON、逐候选裁决JSON与可重新验证的CSV。
- 历史 E5 40fddb8 / E6 b0b0d02 原正式归档继续原字节保留。old-e6 是临时解包副本，可以只引用原归档及其已核对的361文件校验，不必再次复制完整副本。
- 最终归档的文件SHA清单、压缩包SHA及解包回验结果；压缩包不要包含自身或递归套入项目历史归档。

不归档：仓外源码clone的 .git/.venv/node_modules/cache、运行中的隐藏stage、任何 *.db/*.sqlite*/*-wal/*-shm、data/backups、真实.env、凭据/私钥、未脱敏Provider原始私有推理。公开提示与工具Schema是复现证据，不能因含system_prompt就删除。

检查工具：

```sh
python /tmp/learning-e6-repair-hoxki28l/archive-review/check_archive.py --output /tmp/learning-e6-repair-hoxki28l/archive-review/pre-final.json
python /tmp/learning-e6-repair-hoxki28l/archive-review/check_archive.py --final --archive-root /tmp/learning-e6-repair-hoxki28l/ARCHIVE_EXTRACTED --output /tmp/learning-e6-repair-hoxki28l/archive-review/final-check.json
```

归档解包根需保留此临时根下的相对路径；若实际归档分层不同，可先将待校验的公开证据整理为该相对布局。脚本不解包、不改原文件，也不自动脱敏或删库。源文件SHA清单绑定运行当时文件；正式执行完成后必须重新生成，不能用运行中的快照证明最终完整。

--final要求 formal/runtime、formal/rules、formal/judge 和 budget-final.json。若主端采用其它目录名，应在调用前仅调整这个离线检查脚本的路径；不得移动或覆写原评测结果来迎合脚本。Runtime failure无需伪造Judge，最终Judge分母为实际Episode数，48总分母仍保留Failure。

脚本只报告疑似凭据的文件、行号/字段路径，绝不输出匹配值。任何报警先人工核对：不要自动删除含合成测试字符串的原始结果，也不要把警告本身当作已泄露事实。
