import json
from pathlib import Path
repo=Path('/root/workspace/tencent_rhinobird2026/learning_travel');out=repo/'evaluation/artifacts/e6-repair-20260908';summary=json.loads((out/'summary.json').read_text());tracks=summary['tracks']
table='| 轨道 | 有效 / 失败 | 原始均分 | Rule封顶 / 裁决均分 | 通过 / 全部 |\n| --- | --- | --- | --- | --- |\n'
for t in ['planning','intervention','assessment','revision']:
 d=tracks[t];table+=f"| {t.title()} | {d['score_count']} / {12-d['score_count']} | {d['raw_score_mean']:.4f} | {d['rule_capped_score_mean']:.4f} / {d['reviewed_score_mean']:.4f} | {d['pass_count']} / 12 |\n"
text='''# E6 修复、另版验证与新版批次档案

从 `fix/evaluation-audit-readiness@c83c0ef` 接续。已实施产品和方法修复、多版 Development/Calibration、新 G01–G12 测试冻结登记及全批运行。**新版为48 Episode、33有效Judge、15失败；15通过、18不通过、15无分，formal=false。** 正式能力资格未通过，不能将自审、离线验证或高原始分替代它。开发和审计均为AI，一名可复用第二AI参与内容/治理复核，无独立人类盲审。

旧E5实验固定 `40fddb8`；首批E6固定 `b0b0d02`（48/46/2，formal=false），[原档案](../e6-formal-20260908/README.md)及旧Release不覆盖。完整执行预设和逐版修复见[工作记录](../../../docs/E6新版修复与验证记录.md)。G家族在本轮方法决定结束后才编写、复核、冻结；它们现已见，后续不能冒充新版本未见测试。F01–F12始终是已见回归。

## 实际修改与验证来源

| 版本 / 源码 | 实际变化 | 实验及结论 |
| --- | --- | --- |
| 1.1 / `267127d` | 站内通知按Notification/Intervention事实验证，外部渠道仍查回执；审批意图/实际提交分层；Owner时区统一；证据缺失/歧义与失败分开；Judge可见路径枚举、输出12288、超时180秒、安全失败类别 | Dev7例6 Gate；Calibration88有效，新增复测/Planning判据未全过；全部保留 |
| 产品体验 / `4e6c1c1` | 按两个具体action摘要真实批准intake和proposal，保留采用边界 | 产生1 pending Proposal/0 Plan，暴露3核心任务不要求证据 |
| 1.2 / `2e7a4db` | 核心任务强制证据完整性；弃权规则与包络分层；Planning D3/D5锚点分开 | Dev7例4通过3 Gate；第二个88次校准；真实批准后1 pending Proposal/0 Plan、5核心均需证据 |
| 1.3 / `1ae8cd2` | 写工具Schema接收模型自己生成的原生行动数组，原参数保留，交给业务Guard前只剥离评测字段；memory_search纯读；ready intake继续提案 | 已见Dev7/7无Gate、7/7真实Judge全维2；14模型轮，3原生写声明，0推断声明；保留待审批 |
| 1.4 / `c25da44` | Assessment允许引用已定义的同一失败测试及预期，不能用通过输入替代复测 | 固定20次Assessment与6次时区对照全部满足预设，0失败/repair；并非又跑88次 |
| 冻结1.4 / `1f1f35f` | 方法决定后建立G家族，双AI复核、冻结登记并干净提交，按48固定分母运行 | 本页新版批次；新暴露问题保留，未事后改分 |
| 候选1.5 / `3d20c8b` | shared-json最小共享长度512→256、证据路径enum共享引用；输入超限改为typed错误，不混成通用拒绝 | 仓外45 passed；79请求完整证据/路径/展开Schema等价，8超限→0，最大188971≤196608；仅离线，未登记新Benchmark/未真实复测 |

两版完整Calibration均88/88、0最终Judge失败：

| 方法 | 严格排序 | Good>Severe | Severe联合召回 | 重复一致 | 平均总体SD |
| --- | --- | --- | --- | --- | --- |
| v1 | 7/8 | 8/8 | 8/8 | 96.25% | 1.904512 |
| v2 | 8/8 | 8/8 | 8/8 | 98.75% | 0.838603 |

v1 C05 Mild仍一次漏检、Good两次误扣；v2 Good仍一次误扣，均保留，由Prompt3再做20次适用差分验证：Good10次D7全2、Mild10次D7全1且定位原失败测试。v2两个Planning Mild各5次D3全2/D5全1且不跨70线；Good D5仍有小幅波动。C08 Mild第3轮实际120却声称150，经AI确认Critical，保留39分Fail。时区正反输出均正确WAIT，只改解释；最终各3次D1/D7正确全2、错误全1。七维权重/70线未改。

[方法汇总](method-validation/compact-summary.json)、[回归索引](method-validation/regression-index.json)保留逐轮、失败、修正及源提交；完整原始制品在压缩包。产品体验是隔离headless Runtime和真实Hy3，未声称本轮重新做浏览器体验。多轮测试有重叠，不累加成总通过数。

## 新版固定分母结果

'''+table+'''
均值只用33个有效评分，失败保持null；通过率固定四轨各12，不做跨轨总平均。[逐例CSV](cases.csv)分列原始、Rule封顶及裁决分，[机器汇总](summary.json)保留七维均值、全部48例和阻断原因 `capability.judge_error`、`capability.run_not_trusted`。Runtime本身48/48有效且可信不等于最终整批正式资格。

Rules 48有效、30例Fail、28例Hard Gate。103模型轮中59有效声明、15纯读不适用、11 invalid、18 missing，26例存在声明分类问题（类别重叠）。16例等待审批、32例Run完成；冻结完成度判据仍可对待审批Assessment扣Major，但它不表示已经发生错误写入。原始Judge七维/Rules/聚合全部保留，裁决另外生成。

Judge 48条终态中33次真实请求成功，无结构修复、输出截断、无效路径或Provider失败；另外8条在HTTP/预算预留前因输入上界拒绝，7条因余额不足拒绝，均无付费请求。8条原错误码仍为 `judge_request_rejected`；[离线定位](judge-input-failure-analysis.json)证明它们是完整wire UTF-8字节+2048超过196608，范围196634–207740，不是脱敏/网络失败。开发最长旧请求194443仍低于限制，之前未覆盖该边界。

主AI采用第二AI的1条实际Critical提名驳回建议：G07-A完整文本正确弃权和索要补证，帧位于前言之后导致解析NO_OP；保留原Rule形式失败，不重复确认语义Critical。另确认G09-P把刚读到的“-1→桶0 FAIL（预期outside）”说成“正确拒绝”，并写进待审批草案，是观察事实编造；它原Judge输入失败，仍无分，**不会因补充裁决变成有效Judge**。机器逐轨 `confirmed_critical_cases` 只统计有分项；不能据其为0漏掉这一无分案例。完整[主AI裁决](semantic-decisions-primary.json)、[第二AI建议](semantic-decisions-secondary.json)均公开身份及证据路径。

## 实际行为与仍待解决的问题

[48例公开轨迹内容审计](content-audit.json)逐条绑定Episode、Reference和Rules（144来源、914有效证据指针），主AI核对裁决和关键原文。以下事实不按分数反推：

- 四个预期站内提醒各实际写入一次；六个WAIT遵守本地时间、冷却或日限额。G01-I额外尝试被幂等身份冲突拦住，只有一次真实通知；原链路成功规则仍Fail，不能说成重复发送。G04-I站内提问与行动效果映射冲突保留。
- 八个有证据Assessment给出4 ACCEPT/4 REVISION_REQUIRED意图，均待合法审批、零实际评分写入；四个证据不足/歧义案例保持未评分。G01-A提前声明弃权后ACCEPT导致历史合并冲突；G07-A是帧位置错误。完整弃权语义正确不消除协议失败。
- 八个ready Planning返回完整待审批提案，未持久化Plan；四个缺少条件的Planning记录collecting intake并询问两个具体条件。新草案仍有内容错误：G02 RPN表达式/计算不一致，G06 y轴方向和实例冲突，G05/G06/G11复习日期越过截止日，G12空数组边界断言过宽，G01引用未支持字段；G09观察编造。部分有分Planning原始100说明Judge仍漏检内容，不能把高分当修复证明。
- 五个授权Revision实际修改正确且保留inverse；G04无历史时索要原稿，未编造旧值。G03误用Intervention行动名，冻结规则连带要求patch，实际仍是待审批建议；G05声称撤销“回到v3”与单调增加版本的undo语义不符。本批没有真实执行undo，不把既有测试充当本批体验。

已修复的确定性机制及其验证来源列在上表；声明遵循、动作效果分类的边界和上述规划/Judge内容可靠性仍未全部闭合。1.5只修本次确认的输入编码退化，未改产品、Rules或Prompt3来迎合G结果。后续先把G作为已见回归做另版方法验证，再另建未见家族；不能重跑覆盖这48条或把候选离线等价当新正式能力结论。E7/E8及独立人类一致性仍待完成。

## 版本与预算

新正式Runtime固定干净 `1f1f35f04aff5c2c83f69a1ceb98b4d80d7f3fd6`；Protocol1.4 SHA `c2896364c4fd9ca4e293c0f8c3175ff5cd24e482cecc9cd2f7ff55c0f4dc6cd2`，Benchmark SHA `38a10334eca4be947633696c5c4ae4e13edde7119313a2a18bbaf9be88fa3fbf`。预调用的方法决定见[method-readiness.json](method-readiness.json)，冻结运行计划、输入纠正、双AI复核、注册表与完整源码快照均在包内；原1.0–1.4不可变资产保全。

活动源码现为未登记的Protocol1.5候选，SHA `18077001e25e46d236cd11fded5015b980dbb24d5094876b560b6b85c13107d7`。[候选离线验证](candidate-v5-verification.json)使用冻结1.4与候选1.5实际实现重建同79请求，逐条完整盲化文档、展开Schema、路径目录摘要一致。对应8个失败中最小新版请求需预留0.225624元，大于余额0.216953元，故真实候选复测0次。

唯一账本 `/root/.local/state/learning-travel/e4-hy3-20260905-osj4FCZZ-budget.json`，上限34.609982元。起始490请求/17.609982元；本轮新增417请求/16.783047元，其中方法与体验281请求/11.960885元，新版正式136请求/4.822162元（103 Agent+33 Judge）。最终907请求/34.393029元占用，剩余0.216953元；未追加17元、无活动预留，原7条未知usage预留1.767676元保留。417条全部匹配公开调用，未核对云账单实扣。见[账本审计](budget-audit.json)和[最终快照](budget-final.json)。

## 归档与复现

`e6-repair-evidence.tar.gz` 保存方法v1–v4、正式Runtime/Rules/Judge/原始与裁决聚合、完整公开模型轨迹与attempts、全部失败/修复/审计、预算、回归日志、输入及七份源码快照；不含真实.env、产品库、临时库、私有推理或Git内部文件。包内 `evidence-manifest.json` 按文件列SHA；顶层 `artifact-manifest.json` 绑定本目录全部交付文件；`validation-summary.json` 记录解包回验、冻结1.4报告复现、历史保全和敏感文件复核，`cleanup.json` 记录临时环境清理。扫描命中的35处凭据形状均是七份源码中两个脱敏测试文件的固定合成字面量，原始报警与主AI逐字节裁决都保留，不删改源测试。

用可信归档解包至仓外临时目录，依据包内manifest校验；取Git `1f1f35f` 的干净仓外副本（不要使用当前1.5解释旧制品），通过包内冻结输入执行：

```bash
PYTHONPATH=evaluation/src:backend python evaluation/scripts/summarize_e6_run.py \\
  --dataset /ABS/EXTRACTED/frozen-inputs/evaluation/datasets/decisionbench-v1.4-e6-test \\
  --run /ABS/EXTRACTED/formal --output /ABS/NEW_REPORT
```

使用项目锁定依赖；该命令只读，不调用模型。公开源码快照用于代码核对，不伪造Git身份。重新生成的summary/cases须与本页文件逐字节一致。日后重新运行模型需继续读实际账本和建立适用版本，归档脚本不构成新付费授权或新测试独立性。
'''
(out/'README.md').write_text(text)
# Current notices replace only current-entry sections; old experimental bodies remain historical.
notice='> 2026-09-08 修复轮已完成代码修复、另版验证及新版批次：48 Episode、33有效Judge、15失败（8输入超限、7预算不足），formal=false。Protocol1.5仅完成离线修复验证，未真实复测；当前原账本剩余0.216953元，累计上限34.609982元未再追加。详见[E6新版修复与验证记录](E6新版修复与验证记录.md)和[新版档案](../evaluation/artifacts/e6-repair-20260908/README.md)。'
for name in ['E6验收工作记录.md','STATUS.md','第三阶段开发交接.md']:
 p=repo/'docs'/name;s=p.read_text();a=s.index('> 2026-09-08用户最新要求：');b=s.index('\n\n',a);s=s[:a]+notice+s[b:];p.write_text(s)
p=repo/'docs/E6验收工作记录.md';s=p.read_text();at=s.index('## 2026-09-08 首批');s=s[:at]+'''## 最新修复轮收口

实际修复、预设和逐版实验见[新版工作记录](E6新版修复与验证记录.md)。新增G01–G12在方法调优结束后创建，Protocol1.4及Benchmark在`1f1f35f`冻结登记后运行：48 Episode/0Failure，33有效Judge/15失败，15通过/18不通过/15无分。分母固定四轨各12；新输入拒绝已另记1.5候选完成45项仓外回归及79请求等价验证，无真实复测，不覆盖冻结1.4结果。完整逐轨/七维/案例/费用在[新版档案](../evaluation/artifacts/e6-repair-20260908/README.md)。

本轮新增417请求，占用16.783047元；最终907请求，占用34.393029元，剩余0.216953元。预算预留不足已停止付费。动作格式、规划内容和Judge漏检仍有新反例，正式能力资格未通过；E7/E8仍待完成。以下首批48/46/2及其费用为历史结果，原字节档案保留。

'''+s[at:];p.write_text(s)
p=repo/'docs/E6修复开发交接.md';s=p.read_text();a=s.index('\n\n');s=s[:a]+ '\n\n'+notice+'\n\n本交接已由`c83c0ef`接续执行，以下是启动前授权与问题清单的历史快照；其中“当前17元/下一轮修复”不表示本轮结束后的余额或待办。'+s[a:];s=s.replace('## 当前余额：17 元可继续使用，已经更正原账本','## 启动前余额快照：17 元授权已更正原账本');p.write_text(s)
p=repo/'docs/第三阶段开发交接.md';s=p.read_text();a=s.index('## 最新接手状态');b=s.index('## 已完成基线',a);s=s[:a]+'''## 最新接手状态：修复、另版验证与新版运行完成，正式资格未通过

沿用 `fix/evaluation-audit-readiness` 最新HEAD，修复从`c83c0ef`开始；正式源码固定`1f1f35f`/Protocol1.4，当前源码为Protocol1.5离线候选，最后源码验证`3d20c8b`。两版Calibration各88有效、第三版Dev7/7及真实Judge7/7、最终Assessment20与时区6满足预设。G01–G12是在方法决定后新建并冻结登记的48输入，真实批次33有效Judge/15失败、15通过/18不通过/15无分，formal=false；完整证据与剩余缺陷见[新版档案](../evaluation/artifacts/e6-repair-20260908/README.md)。

候选1.5修复完整Judge输入编码和typed超限归因，仓外45 passed、79请求证据等价，8旧超限全部消除；余额0.216953元小于最小对应复测预留0.225624元，未真实调用、不注册新Benchmark。动作遵循、Planning内容/Judge漏检仍有反例。G/F现均已见；后续另版先验证再建立新未见家族。旧E5固定`40fddb8`、旧E6固定`b0b0d02`的48/46/2及formal=false不变。

唯一账本累计907请求、占用34.393029元，上限34.609982元，原490历史和7条未知usage预留保留；不得再加17元或重置账本。产品测试仅仓外副本/临时库，一名可复用子agent且无孙agent，本轮未推送/发布。临时目录、归档及本地提交完成情况见[工作记录](E6新版修复与验证记录.md)。E7/E8、独立人类盲审仍待完成，不重做已完成S06/E5旧清单。

'''+s[b:];p.write_text(s)
p=repo/'docs/STATUS.md';s=p.read_text();a=s.index('H1–H8 工程门禁');b=s.index('## 2026-09-08 E6 批次',a);s=s[:a]+'''H1–H8工程底座、E0–E4及S06/E5已完成。活动评测协议现为1.5离线候选；已登记并实际执行的新批次是1.4，旧1.0保留。已实施通知适用性、审批意图/提交分层、模型原生行动声明、Owner时区、证据不足决策与Judge修复；另版Calibration两组88、Dev7及Judge7、最终Assessment20/时区6完成。新G01–G12冻结登记后48 Runtime有效，33 Judge有效、15失败，最终15通过/18不通过/15无分，formal=false。

候选1.5的输入编码修复经仓外45项回归、79请求完整证据与路径等价验证，8超限降为0；无真实候选复测。仍有行动格式、规划内容及Judge漏检反例；不宣称全部缺陷闭合。新正式来源`1f1f35f`，候选验证`3d20c8b`；[版本、报告与归档](../evaluation/artifacts/e6-repair-20260908/README.md)、[计划与执行](E6新版修复与验证记录.md)是当前入口。E7/E8、外部真人采用和独立人类一致性未完成；M15–M20不在本阶段。

以下记录为首批和更早验收的历史快照，其中旧余额、活动协议及待办以本页顶部为准。

'''+s[b:];s=s.replace('## 2026-09-08 E6 批次、报告与自审','## 2026-09-08 E6 首批、报告与自审（历史）',1);p.write_text(s)
p=repo/'README.md';s=p.read_text();a=s.index('第三阶段已实现隔离 Runtime');b=s.index('\n\n## Demo',a);s=s[:a]+'''第三阶段已实现隔离Runtime、轨迹、Rules、盲化Judge、聚合与版本治理，E4及S06/E5已完成。E5实验固定`40fddb8`、88有效；首批E6固定`b0b0d02`的48 Episode/46有效Judge/2失败保留。随后实际修复通知、审批归因、行动声明、时区、证据不足决策及Judge，完成另版方法验证，并在`1f1f35f`冻结登记新的G01–G12四轨48输入后运行：33有效Judge、15失败，formal=false。输入超限另记Protocol1.5候选，45项仓外回归及79请求等价验证通过，未真实复测；动作格式和规划内容仍有反例。当前共享账本剩余0.216953元，已停止付费。完整结果、版本、失败与费用见[新版档案](evaluation/artifacts/e6-repair-20260908/README.md)和[工作记录](docs/E6新版修复与验证记录.md)。E7/E8及独立人类一致性仍待完成。
'''+s[b:];p.write_text(s)
for name in ['E5开发交接.md','E5验收工作记录.md']:
 p=repo/'docs'/name;s=p.read_text();a=s.index('> ');b=s.index('\n\n',a);s=s[:a]+'> 本页保留E5收口事实及`40fddb8`实验身份。后续E6首批48/46/2与修复轮新版48/33/15分别归档，均formal=false；当前结果、剩余缺陷和实际余额见[E6新版工作记录](E6新版修复与验证记录.md)。以下E6待办/旧余额均为E5收口时快照。'+s[b:];p.write_text(s)
p=repo/'docs/腾讯犀牛鸟开源实习第三阶段评测实施方案.md';s=p.read_text();a=s.index('| 当前状态 |');b=s.index('\n',a);s=s[:a]+'| 当前状态 | E4/S06/E5完成，E5固定40fddb8；E6首批48/46/2保留；修复轮完成多版方法验证、新G家族冻结登记及48 Episode/33有效Judge/15失败，formal=false；Protocol1.5仅离线修复验证，E7/E8待完成 |'+s[b:];a=s.index('2026-09-06 本轮已完成');b=s.index('\n\n产品 H1–H8',a);s=s[:a]+'''2026-09-08 修复轮已实施产品/方法改动，分别版本化并在仓外完成验证。两版Calibration各88有效，第三版Development7例及真实Judge7例，最终Assessment20/时区6满足新增预设；固定1.4后才建立并登记新G01–G12四轨48输入。`1f1f35f`正式运行48 Episode/33有效Judge/15失败，formal=false。输入编码退化另以1.5候选完成45项回归与79请求等价离线验证；因实际余额0.216953元不足预留，未真实复测。旧E5固定40fddb8、首批E6固定b0b0d02结果不变；新G家族现已见。逐轨结果、未闭合问题和预算见[新版档案](../evaluation/artifacts/e6-repair-20260908/README.md)，预设和执行见[新版工作记录](E6新版修复与验证记录.md)。下文旧阶段状态、协议1.0及预算均为历史，不覆盖当前1.5候选/1.4已登记运行的区分。'''+s[b:];s=s.replace('E6真实批次与报告完成，2个Judge错误使正式资格未通过。','E6首批与新版真实批次和报告完成，分别2个/15个Judge错误，正式资格均未通过。');p.write_text(s)
p=repo/'docs/腾讯犀牛鸟开源实习第三阶段项目方案.md';s=p.read_text();a=s.index('E4已完成AI内容与工程验收');b=s.index('\n',a);s=s[:a]+'''E4及S06/E5已完成。E6首批48 Episode/46有效Judge/2失败保留；修复轮已完成通知/审批归因、行动传输、时区/证据不足和Judge修复，并开展两版88次Calibration、真实Development及最终Assessment20/时区6差分验证。方法决定后建立新G01–G12四轨48输入，1.4冻结登记后运行得33有效Judge/15失败，formal=false；1.5输入编码候选完成45项仓外回归和79请求等价离线验证，无真实复测。当前原账本上限34.609982元、占用34.393029元、剩余0.216953元，已停止付费。仍有声明、规划内容与Judge漏检反例，详见[新版档案](../evaluation/artifacts/e6-repair-20260908/README.md)和[工作记录](E6新版修复与验证记录.md)。S/F/G已见材料均不能升级为后续未见测试。'''+s[b:];s=s.replace('| 正式冻结与全量评测 | 冻结/登记、全批运行与报告已完成；正式资格未通过 | 48 Episode、46有效Judge/2失败，逐轨结果及归因保留；formal=false，见[E6记录](E6验收工作记录.md) |','| 正式冻结与全量评测 | 修复、另版验证、新家族冻结登记及全批运行完成；正式资格未通过 | 新版48 Episode、33有效Judge/15失败；1.5候选仅离线；旧首批48/46/2保留，见[新版记录](E6新版修复与验证记录.md) |');p.write_text(s)
p=repo/'evaluation/README.md';s=p.read_text();s=s.replace('**Evaluation Protocol Release 1.4**，已绑定登记新的 `decisionbench-v1.4-e6-test-release`。','**Evaluation Protocol Release 1.5（仅离线验证的未登记候选）**。最近已登记并运行的正式批次是\nProtocol1.4 / `decisionbench-v1.4-e6-test-release`，必须用冻结源码`1f1f35f`复现旧批次。');a=s.index('E6 冻结批次已执行：');b=s.index('另见 [候选数据卡]',a);s=s[:a]+'''E6首批48/46/2保留；修复轮完成多版方法验证、新G家族冻结登记及48 Episode/33有效Judge/15失败，formal=false。
1.5候选修复完整请求编码和输入超限分类，仓外45 passed、79请求证据等价，仅离线，真实复测0次。
当前余额0.216953元，已停止付费；版本、费用和剩余问题见[新版档案](artifacts/e6-repair-20260908/README.md)及
[新版工作记录](../docs/E6新版修复与验证记录.md)。'''+s[b:];s=s.replace('当前 Protocol 1.4 及历史版本各自绑定活动组件','当前候选 Protocol1.5 及历史版本分别绑定组件');a=s.index('浏览器产品调用均计入原 14 元账本');b=s.index('Judge 的 real 模式',a);s=s[:a]+'''浏览器产品调用均计入唯一共享账本，E5结束占用11.606238元；首批E6结束占用17.609982元。
用户明确授权当时可用17元，累计上限一次更正为34.609982元；本次修复与另版实验新增417请求、16.783047元，
最终907请求/34.393029元，剩余0.216953元。历史7条未知usage预留1.767676元保留，未核对云实扣，
不得重复加17或重置账本。Agent 和
'''+s[b:];a=s.index('E6 新测试已完成冻结登记及全批运行');b=s.index('固定响应和 engineering',a);s=s[:a]+'''E6首批与新版G测试均完成冻结登记及全批运行，分别保留46/2和33/15有效Judge/失败，formal=false；
修复/验证和完整分母见[新版档案](artifacts/e6-repair-20260908/README.md)。1.5仅离线候选，G现在已见。
独立人类一致性、精确反事实、完整对抗安全扩展及E7/E8仍未完成。
'''+s[b:];p.write_text(s)
# Mark the executed plan; archive/cleanup checkbox waits for actual completion.
p=repo/'docs/E6新版修复与验证记录.md';s=p.read_text();s=s.replace('- [ ] 方法稳定后新建','- [x] 方法稳定后新建');s=s.replace('- [ ] 离线重建全部48','- [x] 离线重建全部48').replace('- [ ] 对确认的本轮输入退化','- [x] 对确认的本轮输入退化').replace('- [ ] 仓外验证结构等价','- [x] 仓外验证结构等价');s+='''
## 新版批次与候选离线验证最终结果

Protocol1.4/G01–G12在干净`1f1f35f`登记后全批执行：48 Episode、0RuntimeFailure，33有效Judge、15失败（8输入超限、7预算不足），15通过/18不通过/15无分，formal=false。1.4全部原终态保留；主AI最终裁决驳回G07-A重复形式Critical，补充确认G09-P观察编造但保留其judge_error/null，不回填维度或分数。

新问题的1.5候选实际代码在`31a230e`实现、`e8c7842`重建已见回归绑定、`3d20c8b`完成测试依赖修正；45项仓外回归通过（最初collection缺少非必要jsonschema依赖的失败日志保留）。用两版实际实现重建79份公开请求，完整证据文档、展开Schema及路径目录逐条摘要相等，旧8个超限全部降至限内，最大188971。候选不变更产品/Rules/Prompt3；仅离线、未登记新Benchmark、未真实Judge复测。原冻结1.4及旧Release不改字节。

新版仍有26例声明分类问题和规划内容/Judge漏检反例；Development7/7只证明该已见集，不代表全场景遵循。审批等待、尝试冲突和真实错误写入严格分开报告。逐轨、七维、48例内容审计、所有回归/初次失败、方法实验和完整公开轨迹见[新版档案](../evaluation/artifacts/e6-repair-20260908/README.md)。开发/主审及一名复用第二审均明确AI身份。

最终原账本907请求、占用34.393029元、上限34.609982元、剩余0.216953元；原490历史/授权完全不变，7条未知usage预留1.767676元保留。本轮417请求共16.783047元，全部匹配公开轨迹；方法/体验11.960885元、新正式4.822162元。修复后原失败请求中最小预留0.225624元，预算已不足，因此停止所有付费并完成独立离线工作。未核对云账单，不再追加授权金额。E7/E8仍未完成，正式能力资格未通过。
''';p.write_text(s)
print('Wrote final report and current documentation entries; cleanup checkbox remains pending.')
