"""Preserve public original artifacts, exact input/source versions, and audit false positives."""
import hashlib,json,shutil,subprocess,tarfile
from pathlib import Path
r=Path('/tmp/learning-e6-repair-hoxki28l');repo=Path('/root/workspace/tencent_rhinobird2026/learning_travel');out=repo/'evaluation/artifacts/e6-repair-20260908';a=r/'archive-review'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();load=lambda p:json.loads(p.read_text());write=lambda p,d:p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
# Snapshot final public inventory after every experiment/report has terminated.
p=subprocess.run(['python',str(a/'check_archive.py'),'--final','--output',str(a/'final-inventory.json')]);assert p.returncode in (0,1)
report=load(a/'final-inventory.json');assert not report['errors'] and not report['pending'];assert len(report['sensitive_findings_no_values'])==35
# Findings must be the exact known, public, credential-rejection test fixtures.
fixture_locations={'evaluation/tests/test_dataset_validation.py':{('bearer_credential',212),('openai_style_key',211),('openai_style_key',245),('openai_style_key',270)},'evaluation/tests/test_e1_runtime.py':{('bearer_credential',456)}}
fixtures=[]
for row in report['sensitive_findings_no_values']:
 parts=Path(row['path']).parts;assert parts[0]=='source-snapshots';sourcepath='/'.join(parts[2:]);assert (row['kind'],row['line']) in fixture_locations[sourcepath]
 expected=subprocess.check_output(['git','show',f'{parts[1]}:{sourcepath}'],cwd=repo);assert (r/row['path']).read_bytes()==expected
 fixtures.append({**row,'file_sha256':sha(r/row['path']),'verdict':'synthetic_credential_rejection_test_literal','rationale':'Primary AI inspected the two test functions and fixed synthetic literals; exact Git version bytes verified. No real credential, original source kept.'})
write(a/'synthetic-fixture-dispositions-primary.json',{'reviewer_role':'primary_ai_reviewer','scope':'Raw scanner findings remain preserved; these exact 35 source-test matches are not real credentials.','findings':fixtures})
staging=r/'archive-staging';staging.mkdir()
for row in report['required_public_files']:
 src=r/row['relative_path'];dst=staging/row['relative_path'];dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst);assert sha(dst)==row['sha256']
for folder in ['frozen-inputs','candidate-inputs-v5']:
 shutil.copytree(r/folder,staging/folder)
(staging/'archive-review').mkdir()
for p in a.iterdir():
 if p.is_file() and p.suffix in ('.json','.md','.py'):shutil.copy2(p,staging/'archive-review'/p.name)
# Repeat scanner on the extracted-layout staging including all additional files.
p=subprocess.run(['python',str(a/'check_archive.py'),'--final','--archive-root',str(staging),'--output',str(a/'staging-scan.json')]);assert p.returncode in (0,1)
d=load(a/'staging-scan.json');assert not d['errors'];assert d['sensitive_findings_no_values']==report['sensitive_findings_no_values']
write(a/'public-evidence-review-primary.json',{'reviewer_role':'primary_ai_reviewer','raw_second_ai_scanner_exit_code':p.returncode,'raw_scan_sha256':sha(a/'staging-scan.json'),'raw_sensitive_matches':35,'exact_synthetic_matches_reviewed':35,'unresolved_sensitive_findings':0,'inventory_files':len(report['required_public_files']),'all_required_original_bytes_preserved':all(x['identical'] for x in d['archive_comparison']),'additional_inputs_and_source_snapshots_scanned':True,'real_secrets_found':False,'private_reasoning_fields_found':False,'database_or_env_files_found':False,'completed':True})
for name in ['staging-scan.json','public-evidence-review-primary.json']:shutil.copy2(a/name,staging/'archive-review'/name)
files=[]
for p in sorted(staging.rglob('*')):
 if p.is_file():
  assert not p.is_symlink();files.append({'relative_path':str(p.relative_to(staging)),'size_bytes':p.stat().st_size,'sha256':sha(p)})
write(staging/'evidence-manifest.json',{'schema':'e6-repair-evidence-manifest-v1','files':files,'file_count':len(files),'exclusions':['this manifest itself','private databases and env','git and caches','optional old E6 extracted copy (authoritative old archive preserved)']})
archive=out/'e6-repair-evidence.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for p in sorted(staging.rglob('*')):
  if p.is_file():tar.add(p,arcname=str(p.relative_to(staging)),recursive=False)
extracted=r/'archive-extracted';extracted.mkdir()
with tarfile.open(archive) as tar:tar.extractall(extracted,filter='data')
m=load(extracted/'evidence-manifest.json');assert len(list(extracted.rglob('*')))>len(files)
assert all((extracted/x['relative_path']).stat().st_size==x['size_bytes'] and sha(extracted/x['relative_path'])==x['sha256'] for x in m['files'])
assert sha(extracted/'evidence-manifest.json')==sha(staging/'evidence-manifest.json')
write(a/'archive-extraction-verification.json',{'archive_sha256':sha(archive),'archive_size_bytes':archive.stat().st_size,'evidence_manifest_sha256':sha(extracted/'evidence-manifest.json'),'files_verified':len(files),'all_identical':True,'original_inventory_verified':len(report['required_public_files']),'reviewed_synthetic_fixture_matches':35,'unresolved_sensitive_findings':0})
shutil.copy2(a/'archive-extraction-verification.json',out/'archive-verification.json');shutil.copy2(a/'public-evidence-review-primary.json',out/'public-evidence-review.json')
print(json.dumps(load(a/'archive-extraction-verification.json')))
