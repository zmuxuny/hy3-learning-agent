#!/usr/bin/env python3
"""Read-only completeness/privacy/byte checks of this E6 repair's public evidence.

Writes reports only below /tmp/learning-e6-repair-hoxki28l/archive-review.
No payload snippets are emitted for suspected secrets. No source is redacted.
With --archive-root, compare a prepared/extracted archive preserving relative paths.
--final requires formal terminals and final budget snapshot; before completion they
are explicitly in-progress, never silently treated as a complete formal batch.
"""
from __future__ import annotations
import argparse,hashlib,json,os,re
from collections import Counter
from pathlib import Path
TASK=Path('/tmp/learning-e6-repair-hoxki28l');LEDGER=Path('/root/.local/state/learning-travel/e4-hy3-20260905-osj4FCZZ-budget.json')
p=argparse.ArgumentParser();p.add_argument('--source-root',type=Path,default=TASK);p.add_argument('--archive-root',type=Path);p.add_argument('--output',type=Path,required=True);p.add_argument('--final',action='store_true');a=p.parse_args();root=a.source_root.resolve();output=a.output.resolve()
if not output.is_relative_to(TASK/'archive-review'):raise SystemExit('output_must_be_in_task_archive_review')
load=lambda x:json.loads(x.read_text());sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
PUBLIC_TREES={'method-v1','method-v2','method-v3','method-v4','formal','logs','cal-v1-ai-review','cal-v2-ai-review','pre-freeze-input-corrections','heldout-review-input-snapshot','metrics-raw-reproduction-v1','metrics-raw-reproduction-v2','formal-ai-review','source-snapshots'}
PRODUCT_TREES={'product-experience-v1','product-plan-experience-v1','product-plan-experience-v2'}
# Copies of prior release's authoritative archive are optional references; original
# preserved archive remains authoritative, and may be retained without duplication.
OPTIONAL_TREES={'old-e6'}
DENIED_PARTS={'.git','.venv','node_modules','__pycache__','.pytest_cache','.ruff_cache','data','audit-views'}
DENIED_SUFFIXES={'.db','.sqlite','.sqlite3','.pyc','.pyo','.pem','.key','.p12','.pfx'}
errors=[];pending=[];findings=[];inventory=[];excluded=[];version_rows=[];denominators=[]
def allowed(path):
 rel=path.relative_to(root)
 if any(x.startswith('.') or x in DENIED_PARTS for x in rel.parts):return False
 if path.suffix.lower() in DENIED_SUFFIXES or path.name.endswith(('-wal','-shm','.db-journal')):return False
 if len(rel.parts)==1:return path.suffix in {'.json','.jsonl','.log','.md','.py'}
 if rel.parts[0]=='formal-ai-review':return path.suffix in {'.json','.jsonl','.py','.md','.csv'}
 if rel.parts[0] in PUBLIC_TREES:return True
 if rel.parts[0] in PRODUCT_TREES:return len(rel.parts)==2 and (path.name.startswith('facts-') and path.suffix=='.json' or path.name=='public-calls.jsonl')
 return False
for top in sorted(root.iterdir()):
 if top.is_file() and allowed(top):inventory.append(top)
 elif top.is_dir() and top.name in PUBLIC_TREES|PRODUCT_TREES:
  for f in sorted(top.rglob('*')):
   if f.is_file() and not f.is_symlink():
    if allowed(f):inventory.append(f)
    else:excluded.append(str(f.relative_to(root)))
# Name-based and literal-secret checks. Archive only public recorder projections;
# system prompts/tool schemas are legitimate reproducibility inputs, not secrets.
patterns={
 'private_key_material':re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
 'bearer_credential':re.compile(rb'(?i)Bearer\s+[A-Za-z0-9._~-]{20,}'),
 'openai_style_key':re.compile(rb'\bsk-[A-Za-z0-9_-]{20,}\b'),
 'tencent_access_id':re.compile(rb'\bAKID[A-Za-z0-9]{24,}\b'),
 'literal_secret_assignment':re.compile(rb'''(?i)(?:api[_-]?key|secret[_-]?key|access[_-]?token|password)\s*[=:]\s*["']([A-Za-z0-9_+/=.-]{24,})["']'''),
}
known_values=[v.encode() for k,v in os.environ.items() if any(x in k.upper() for x in ['API_KEY','SECRET_KEY','ACCESS_TOKEN']) and len(v)>=16]
def scan(f,relative):
 b=f.read_bytes()
 if b.startswith(b'SQLite format 3\x00'):findings.append({'path':relative,'kind':'sqlite_payload','action':'exclude_binary_database'});return
 for name,rx in patterns.items():
  for m in rx.finditer(b):findings.append({'path':relative,'kind':name,'line':b.count(b'\n',0,m.start())+1,'action':'review_before_archiving_no_value_echoed'})
 if any(v in b for v in known_values):findings.append({'path':relative,'kind':'matches_process_secret','action':'do_not_archive_secret_no_value_echoed'})
 if f.suffix not in {'.json','.jsonl'}:return
 try:docs=[json.loads(line) for line in b.splitlines() if line.strip()] if f.suffix=='.jsonl' else [json.loads(b)]
 except (ValueError,UnicodeError):errors.append({'path':relative,'kind':'invalid_json'});return
 def walk(x,where):
  if isinstance(x,dict):
   for k,v in x.items():
    if k in {'reasoning_content','chain_of_thought','private_reasoning'} and isinstance(v,str) and v.strip():findings.append({'path':relative,'kind':'nonempty_private_reasoning_field','json_path':where+'.'+k,'action':'review_public_projection_no_value_echoed'})
    walk(v,where+'.'+k)
  elif isinstance(x,list):
   for i,v in enumerate(x):walk(v,f'{where}[{i}]')
 for i,d in enumerate(docs):walk(d,f'$record[{i}]')
for f in inventory:scan(f,str(f.relative_to(root)))
def count_expected(folder,pattern,expected,label):
 files=sorted(folder.glob(pattern));observed=len(files);row={'scope':label,'expected':expected,'observed':observed,'complete':observed==expected};denominators.append(row)
 if observed!=expected:errors.append({'kind':'denominator_mismatch',**row})
 return files
def runtime(folder,n,version,commit,label,required=True):
 mp=folder/'run-manifest.json'
 if not mp.exists():
  (errors if required or a.final else pending).append({'kind':'runtime_manifest_missing','scope':label});return
 m=load(mp);terms=m['terminals'];eps=list((folder/'episodes').glob('*.json'));fails=list((folder/'failures').glob('*.json'));ids={t['artifact_id'] for t in terms};actual={f.stem for f in eps+fails}
 row={'scope':label,'expected':n,'terminals':len(terms),'episodes':len(eps),'failures':len(fails),'manifest_and_files_match':ids==actual,'protocol':m['evaluation_protocol_release_id'],'git_commit':m['git_commit'],'formal':m['formal_evaluation_result'],'selected_case_count':len(m['selected_case_ids'])};denominators.append(row)
 if len(terms)!=n or len(m['selected_case_ids'])!=n or ids!=actual:errors.append({'kind':'runtime_denominator_or_inventory_mismatch',**row})
 if m['evaluation_protocol_release_id']!=f'evaluation-protocol-release-{version}' or not m['git_commit'].startswith(commit):errors.append({'kind':'version_mismatch',**row})
 version_rows.append(row)
 for f in eps:
  d=load(f);t=next(t for t in terms if t['artifact_id']==d['episode_id'])
  if t['artifact_sha256']!=d['provenance']['episode_sha256']:errors.append({'kind':'terminal_episode_hash_binding','path':str(f.relative_to(root))})
for v,commit in [(1,'267127d'),(2,'2e7a4db'),(3,'1ae8cd2'),(4,'c25da44')]:
 b=root/f'method-v{v}';runtime(b/'runtime',4 if v==4 else 24,f'1.{v}',commit,f'method-v{v}/'+('focused-runtime' if v==4 else 'calibration-runtime'));count_expected(b/'rules','rules/*.json',4 if v==4 else 24,f'method-v{v}/'+('focused-rules' if v==4 else 'calibration-rules'));runtime(b/'controlled-runtime',2,f'1.{v}',commit,f'method-v{v}/timezone-runtime')
 count_expected(b,'controlled-judge-r*/judge-results/*.json',6,f'method-v{v}/timezone-judge')
 if v<=3:runtime(b/'dev-runtime',7,f'1.{v}',commit,f'method-v{v}/development-runtime');count_expected(b/'dev-rules','rules/*.json',7,f'method-v{v}/development-rules')
 if v in [1,2]:count_expected(b/'experiments','judge-r*/judge-results/*.json',88,f'method-v{v}/calibration-judge');count_expected(b/'experiments','aggregate-r*/run-manifest.json',20,f'method-v{v}/calibration-aggregate-partitions');count_expected(b/'experiments','adjudicated-r*/run-manifest.json',20,f'method-v{v}/adjudicated-partitions')
 if v==3:count_expected(b/'dev-judge','judge-results/*.json',7,'method-v3/development-judge')
 if v==4:count_expected(b/'focused','judge-r*/judge-results/*.json',20,'method-v4/assessment-focused')
runtime(root/'formal/runtime',48,'1.4','1f1f35f','formal/runtime',required=False)
if a.final:
 for sub,pat in [('rules','rules/*.json'),('judge','judge-results/*.json')]:
  # Episode failures consume the fixed denominator and legitimately lack Judges.
  mp=root/'formal/runtime/run-manifest.json'
  if mp.exists():n=sum(t['terminal_kind']=='episode' for t in load(mp)['terminals']);count_expected(root/'formal'/sub,pat,n,f'formal/{sub}')
 for b in [root/'formal',*(root/f'method-v{x}' for x in range(1,5))]:
  for x in b.glob('.*stage*'):errors.append({'kind':'unfinished_stage_directory','path':str(x.relative_to(root))})
ledger_info={}
if (root/'budget-start.json').exists():
 start=load(root/'budget-start.json');final_path=root/'budget-final.json';latest=load(final_path) if final_path.exists() else load(LEDGER);charged=sum(x['charged_micro_cny'] for x in latest['requests']);unknown=[x for x in latest['requests'] if x['token_usage'] is None]
 ledger_info={'source':str(final_path if final_path.exists() else LEDGER),'snapshot_final':final_path.exists(),'limit_micro_cny':latest['limit_micro_cny'],'occupied_micro_cny':charged,'remaining_micro_cny':latest['limit_micro_cny']-charged,'requests':len(latest['requests']),'start_requests':len(start['requests']),'historical_prefix_unchanged':latest['requests'][:len(start['requests'])]==start['requests'],'authorization_unchanged':latest['authorization_adjustments']==start['authorization_adjustments'],'unknown_usage_requests':len(unknown),'unknown_reservation_micro_cny':sum(x['charged_micro_cny'] for x in unknown)}
 if not ledger_info['historical_prefix_unchanged'] or not ledger_info['authorization_unchanged'] or latest['limit_micro_cny']!=34609982 or charged>34609982:errors.append({'kind':'ledger_preservation_or_limit_mismatch'})
 if any(x['charged_micro_cny']<=0 for x in unknown):errors.append({'kind':'unknown_usage_reservation_lost'})
 if a.final and not final_path.exists():errors.append({'kind':'final_budget_snapshot_missing'})
else:errors.append({'kind':'starting_ledger_snapshot_missing'})
files=[{'relative_path':str(f.relative_to(root)),'size_bytes':f.stat().st_size,'sha256':sha(f)} for f in inventory];comparison=[]
if a.archive_root:
 ar=a.archive_root.resolve()
 for row in files:
  dest=ar/row['relative_path'];ok=dest.is_file() and not dest.is_symlink() and sha(dest)==row['sha256'];comparison.append({'relative_path':row['relative_path'],'identical':ok})
  if not ok:errors.append({'kind':'archive_missing_or_changed','relative_path':row['relative_path']})
 # Extra archive files must be scanned too; don't silently allow excluded DBs.
 known={r['relative_path'] for r in files}
 for f in ar.rglob('*'):
  rel=str(f.relative_to(ar))
  if f.is_symlink():findings.append({'path':rel,'kind':'archive_symlink','action':'avoid_external_target'});continue
  if f.is_file():
   if any(part in DENIED_PARTS or part=='.env' for part in f.relative_to(ar).parts) or f.suffix in DENIED_SUFFIXES:findings.append({'path':rel,'kind':'archive_forbidden_file','action':'exclude_from_public_archive'})
   if rel not in known:scan(f,rel)
report={'audit_version':'e6-repair-archive-integrity-second-ai-v1','reviewer_role':'delegated_ai_reviewer','disclosure':'参与开发的第二AI完整性/敏感文件复核，非独立人类；不替代逐例内容审计或正式资格判定。','source_root':str(root),'final_requested':a.final,'complete_for_this_phase':not errors and not findings,'formal_in_progress':bool(pending),'denominators':denominators,'version_evidence':version_rows,'budget':ledger_info,'required_public_file_count':len(files),'required_public_files':files,'excluded_temporary_or_database_files':excluded,'sensitive_findings_no_values':findings,'errors':errors,'pending':pending,'archive_comparison':comparison,'paid_calls':0,'source_modified':False}
output.parent.mkdir(exist_ok=True,parents=True);output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['required_public_file_count','complete_for_this_phase','formal_in_progress']},ensure_ascii=False));print(json.dumps({'errors':errors,'sensitive_finding_counts':dict(Counter(x['kind'] for x in findings))},ensure_ascii=False))
raise SystemExit(0 if not errors and not findings else 1)
