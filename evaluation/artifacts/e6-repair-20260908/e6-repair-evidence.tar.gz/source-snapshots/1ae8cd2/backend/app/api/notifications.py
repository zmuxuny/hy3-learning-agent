from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.db.database import get_db
from app.db.uow import commit as commit_uow
from app.models import Notification
from app.notifications.push import push_service
from app.notifications.conversation import open_notification_in_conversation
from app.schemas import (
    NotificationArchiveResult,
    NotificationArchiveUpdate,
    NotificationOpenResult,
    NotificationRead,
    PushSubscriptionCreate,
    PushSubscriptionRead,
)


router = APIRouter()


@router.post("/subscriptions", response_model=PushSubscriptionRead, status_code=201)
async def create_push_subscription(
    data: PushSubscriptionCreate,
    db: AsyncSession = Depends(get_db),
):
    subscription = await push_service.subscribe(
        db,
        settings.DEFAULT_OWNER_ID,
        data.endpoint,
        data.keys,
    )
    await commit_uow(db)
    await db.refresh(subscription)
    return subscription


@router.delete("/subscriptions", response_model=dict)
async def delete_push_subscription(endpoint: str, db: AsyncSession = Depends(get_db)):
    removed = await push_service.unsubscribe(db, settings.DEFAULT_OWNER_ID, endpoint)
    await commit_uow(db)
    return {"removed": removed}


@router.get("", response_model=list[NotificationRead])
async def read_notifications(
    unread_only: bool = False,
    archived: bool = False,
    db: AsyncSession = Depends(get_db),
):
    # The inbox is a logical-message view. Email/browser rows are delivery
    # receipts for the same in-app primary and must not appear as duplicates.
    query = select(Notification).where(
        Notification.owner_id == settings.DEFAULT_OWNER_ID,
        Notification.channel == "in_app",
    )
    archive_filter = Notification.archived_at.is_not(None) if archived else Notification.archived_at.is_(None)
    query = query.where(archive_filter)
    if unread_only:
        query = query.where(Notification.read_at.is_(None))
    result = await db.execute(query.order_by(Notification.created_at.desc()).limit(100))
    return list(result.scalars())


@router.post("/archive-read", response_model=NotificationArchiveResult)
async def archive_read_notifications(db: AsyncSession = Depends(get_db)):
    archived_at = datetime.now(timezone.utc)
    primaries = list((await db.execute(
        select(Notification).where(
            Notification.owner_id == settings.DEFAULT_OWNER_ID,
            Notification.channel == "in_app",
            Notification.archived_at.is_(None),
            Notification.read_at.is_not(None),
        )
    )).scalars())
    for primary in primaries:
        await _set_delivery_group_archived(db, primary, archived_at)
    await commit_uow(db)
    return {"archived": len(primaries), "archived_at": archived_at}


@router.post("/{notification_id}/read", response_model=NotificationRead)
async def mark_notification_read(notification_id: int, db: AsyncSession = Depends(get_db)):
    notification = await db.get(Notification, notification_id)
    if not notification or notification.owner_id != settings.DEFAULT_OWNER_ID:
        raise HTTPException(status_code=404, detail="Notification not found")
    notification.read_at = datetime.now(timezone.utc)
    await commit_uow(db)
    await db.refresh(notification)
    return notification


@router.post("/{notification_id}/open", response_model=NotificationOpenResult)
async def open_notification(notification_id: int, db: AsyncSession = Depends(get_db)):
    notification = await db.get(Notification, notification_id)
    if not notification or notification.owner_id != settings.DEFAULT_OWNER_ID:
        raise HTTPException(status_code=404, detail="Notification not found")
    session, message, primary = await open_notification_in_conversation(db, notification)
    await commit_uow(db)
    await db.refresh(notification)
    return {
        "notification": notification,
        "intervention_id": primary.intervention_id,
        "session_id": session.id,
        "plan_id": primary.plan_id,
        "message_id": message.id,
    }


@router.patch("/{notification_id}/archive", response_model=NotificationRead)
async def set_notification_archived(
    notification_id: int,
    data: NotificationArchiveUpdate,
    db: AsyncSession = Depends(get_db),
):
    notification = await db.get(Notification, notification_id)
    if not notification or notification.owner_id != settings.DEFAULT_OWNER_ID:
        raise HTTPException(status_code=404, detail="Notification not found")
    await _set_delivery_group_archived(
        db,
        notification,
        datetime.now(timezone.utc) if data.archived else None,
    )
    await commit_uow(db)
    await db.refresh(notification)
    return notification


async def _set_delivery_group_archived(
    db: AsyncSession,
    notification: Notification,
    archived_at: datetime | None,
) -> None:
    group = list((await db.execute(
        select(Notification).where(
            Notification.owner_id == notification.owner_id,
            Notification.run_id == notification.run_id,
            Notification.plan_id == notification.plan_id,
            Notification.title == notification.title,
            Notification.body == notification.body,
        )
    )).scalars())
    for sibling in group or [notification]:
        sibling.archived_at = archived_at
