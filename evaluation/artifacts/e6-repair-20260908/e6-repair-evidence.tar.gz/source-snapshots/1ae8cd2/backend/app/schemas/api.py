from typing import Any, Literal

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    field_serializer,
    field_validator,
    model_validator,
)

from app.core.redaction import redact_data
from app.core.time import UTCInstant


class APIModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class TaskCreate(BaseModel):
    title: str = Field(min_length=1, max_length=300)
    description: str = ""
    kind: str = "learning"
    is_core: bool = False
    evidence_required: bool = False
    estimated_minutes: int = Field(default=30, ge=1, le=1440)
    due_at: UTCInstant | None = None
    review_due_at: UTCInstant | None = None
    resource_url: str = ""
    metadata: dict[str, Any] = Field(default_factory=dict)


class StageCreate(BaseModel):
    title: str = Field(min_length=1, max_length=240)
    description: str = ""
    objectives: list[str] = Field(default_factory=list)
    tasks: list[TaskCreate] = Field(default_factory=list)


class PlanCreate(BaseModel):
    title: str = Field(min_length=1, max_length=240)
    description: str = ""
    goal: str = ""
    current_level: str = ""
    deadline: UTCInstant | None = None
    weekly_minutes: int = Field(default=0, ge=0, le=10080)
    preferences: dict[str, Any] = Field(default_factory=dict)
    expected_outcome: str = ""
    available_resources: list[str] = Field(default_factory=list)
    avoid_methods: list[str] = Field(default_factory=list)
    stages: list[StageCreate] = Field(default_factory=list)


class TaskRead(APIModel):
    id: int
    stage_id: int
    title: str
    description: str
    kind: str
    status: str
    is_core: bool
    evidence_required: bool
    estimated_minutes: int
    position: int
    due_at: UTCInstant | None
    completed_at: UTCInstant | None
    review_due_at: UTCInstant | None
    resource_url: str
    task_metadata: dict[str, Any]


class StageRead(APIModel):
    id: int
    plan_id: int
    title: str
    description: str
    objectives: list[str]
    position: int
    status: str
    tasks: list[TaskRead]


class PlanRead(APIModel):
    id: int
    owner_id: str
    title: str
    description: str
    goal: str
    current_level: str
    deadline: UTCInstant | None
    weekly_minutes: int
    preferences: dict[str, Any]
    expected_outcome: str
    available_resources: list[str]
    avoid_methods: list[str]
    status: str
    archived_from_status: str | None
    version: int
    progress: float
    memory_summary: str
    created_at: UTCInstant
    updated_at: UTCInstant
    stages: list[StageRead]


class LearningResourceRead(APIModel):
    id: int
    plan_id: int | None
    title: str
    url: str
    resource_type: str
    provider: str
    language: str
    difficulty: str
    summary: str
    why_recommended: str
    source: str
    verified_at: UTCInstant | None
    created_at: UTCInstant


class TaskUpdate(BaseModel):
    title: str | None = None
    description: str | None = None
    status: Literal["pending", "active", "completed", "blocked", "skipped"] | None = None
    due_at: UTCInstant | None = None
    estimated_minutes: int | None = Field(default=None, ge=1, le=1440)
    review_due_at: UTCInstant | None = None
    evidence: list[dict[str, Any]] | None = None
    kind: str | None = None
    is_core: bool | None = None
    evidence_required: bool | None = None
    resource_url: str | None = None


class ProfileRead(APIModel):
    owner_id: str
    agent_style: str
    preferences: dict[str, Any]
    quiet_hours: dict[str, Any]
    daily_notification_limit: int
    xp: int
    level: int
    streak_days: int
    updated_at: UTCInstant


class ProfileUpdate(BaseModel):
    agent_style: str | None = None
    preferences: dict[str, Any] | None = None
    quiet_hours: dict[str, Any] | None = None
    daily_notification_limit: int | None = Field(default=None, ge=0, le=20)


class MemoryRead(APIModel):
    id: int
    owner_id: str
    scope: str
    scope_id: str | None
    layer: str
    content: str
    source_type: str
    source_id: str | None
    confidence: float
    status: str
    restorable: bool
    archived_from_status: str | None
    archived_reason: str
    lifecycle_reason_code: str
    supersedes_id: int | None
    superseded_by_id: int | None
    last_accessed_at: UTCInstant | None
    access_count: int
    last_reinforced_at: UTCInstant | None
    expires_at: UTCInstant | None
    lifecycle_version: int
    validity_state: str
    invalidated_at: UTCInstant | None
    invalidation_reason: str
    content_hash: str
    provenance_digest: str
    provenance_node_id: str | None
    created_at: UTCInstant
    updated_at: UTCInstant


class MemoryProposalCreate(BaseModel):
    model_config = ConfigDict(extra="forbid")

    scope: Literal["global", "plan", "session"] = "global"
    scope_id: str | None = None
    layer: Literal["short_term", "long_term", "episodic", "semantic", "working"] = "semantic"
    content: str = Field(min_length=1)
    confidence: float = Field(default=1.0, ge=0, le=1)
    expires_at: UTCInstant | None = None
    supersedes_id: int | None = Field(default=None, ge=1)


class NotificationRead(APIModel):
    id: int
    intervention_id: str | None
    run_id: str | None
    session_id: str | None
    plan_id: int | None
    channel: str
    title: str
    body: str
    status: str
    sent_at: UTCInstant | None
    read_at: UTCInstant | None
    archived_at: UTCInstant | None
    created_at: UTCInstant


class NotificationArchiveUpdate(BaseModel):
    archived: bool


class NotificationArchiveResult(BaseModel):
    archived: int = Field(ge=0)
    archived_at: UTCInstant


class NotificationOpenResult(BaseModel):
    notification: NotificationRead
    intervention_id: str | None = None
    session_id: str
    plan_id: int | None
    message_id: int


class PushSubscriptionCreate(BaseModel):
    endpoint: str = Field(min_length=1, max_length=2000)
    keys: dict[str, str] = Field(default_factory=dict)


class PushSubscriptionRead(APIModel):
    id: int
    endpoint: str
    keys: dict[str, Any]
    created_at: UTCInstant
    updated_at: UTCInstant


class ContextSnapshotRead(APIModel):
    id: int
    plan_id: int | None
    session_id: str | None
    run_id: str | None
    markdown: str
    source_manifest: list[dict[str, Any]]
    dropped_source_manifest: list[dict[str, Any]]
    budget_breakdown: dict[str, Any]
    estimated_tokens: int
    context_generation: int
    snapshot_version: int
    assembler_version: str
    context_digest: str
    source_digest: str
    validity_state: str
    provenance_node_id: str | None
    invalidated_at: UTCInstant | None
    invalidation_reason: str
    created_at: UTCInstant


class SessionSummaryRead(APIModel):
    id: int
    session_id: str
    version: int
    content: str
    coverage_start_message_id: int | None
    covered_through_message_id: int | None
    coverage_count: int
    source_message_ids: list[int]
    method: str
    source_digest: str
    content_hash: str
    algorithm_version: str
    validity_state: str
    provenance_node_id: str | None
    invalidated_at: UTCInstant | None
    invalidation_reason: str
    created_at: UTCInstant


class AgentRunCreate(BaseModel):
    objective: str = Field(min_length=1)
    session_id: str | None = None
    plan_id: int | None = None
    reply_to_notification_id: int | None = Field(default=None, ge=1)
    reply_to_intervention_id: str | None = Field(default=None, min_length=1, max_length=64)
    execution_mode: Literal["normal", "read_only"] = "normal"
    # Public conversation turns are always user initiated. Background and
    # email triggers are created only by their trusted scheduler/poller paths.
    trigger: Literal["user_message"] = "user_message"


class AgentRunRead(APIModel):
    id: str
    owner_id: str
    session_id: str | None
    plan_id: int | None
    parent_run_id: str | None
    trigger: str
    objective: str
    status: str
    phase: str
    state_version: int
    attempt: int
    retry_count: int
    available_at: UTCInstant | None
    status_reason: str | None
    model: str
    execution_mode: str
    reply_to_intervention_id: str | None
    proactive_candidate_state: str
    proactive_candidate_key: str | None
    proactive_candidate_kind: str | None
    proactive_candidate_payload: dict[str, Any]
    proactive_candidate_digest: str | None
    proactive_source_watermark: int | None
    proactive_source_projection_digest: str | None
    proactive_detected_at: UTCInstant | None
    cancel_requested: bool
    pending_approval: dict[str, Any] | None
    budget_usage: dict[str, Any] | None
    output: str
    created_plan_id: int | None
    started_at: UTCInstant | None
    completed_at: UTCInstant | None
    created_at: UTCInstant

    @field_serializer("pending_approval")
    def serialize_pending_approval(
        self,
        value: dict[str, Any] | None,
    ) -> dict[str, Any] | None:
        """Redact the client projection without rewriting durable approval facts."""

        return redact_data(value) if value is not None else None


class RunApprovalRequest(BaseModel):
    approved: bool
    note: str | None = Field(default=None, max_length=1000)
    answer: str | None = Field(default=None, max_length=4000)


class QueuedMessageCreate(BaseModel):
    objective: str = Field(min_length=1, max_length=50000)
    session_id: str | None = None
    plan_id: int | None = None
    reply_to_intervention_id: str | None = Field(default=None, min_length=1, max_length=64)
    execution_mode: Literal["normal", "read_only"] = "normal"

    @field_validator("objective")
    @classmethod
    def normalize_objective(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("message cannot be blank")
        return normalized


class QueuedMessageUpdate(BaseModel):
    expected_version: int = Field(ge=1)
    objective: str | None = Field(default=None, min_length=1, max_length=50000)
    position: int | None = Field(default=None, ge=0, le=1000)

    @field_validator("objective")
    @classmethod
    def normalize_objective(cls, value: str | None) -> str | None:
        if value is None:
            return None
        normalized = value.strip()
        if not normalized:
            raise ValueError("message cannot be blank")
        return normalized


class QueuedMessageMutation(BaseModel):
    expected_version: int = Field(ge=1)


class QueuedMessageRead(APIModel):
    id: str
    session_id: str | None
    plan_id: int | None
    trigger: str
    execution_mode: str
    objective: str
    user_content: str | None
    message_metadata: dict[str, Any]
    reply_to_intervention_id: str | None
    position: int
    version: int
    created_at: UTCInstant
    updated_at: UTCInstant


class RunSteerCreate(BaseModel):
    content: str = Field(min_length=1, max_length=50000)

    @field_validator("content")
    @classmethod
    def normalize_content(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("message cannot be blank")
        return normalized


class FollowUpBehaviorUpdate(BaseModel):
    follow_up_behavior: Literal["steer", "queue"]


class SessionRead(APIModel):
    id: str
    plan_id: int | None
    parent_session_id: str | None
    title: str
    summary: str
    handoff_summary: str
    archived_at: UTCInstant | None
    linked_plan_ids: list[int]
    message_count: int
    run_count: int
    last_message: str
    last_run_id: str | None
    last_run_status: str | None
    created_at: UTCInstant
    updated_at: UTCInstant


class SessionUpdate(BaseModel):
    title: str | None = Field(default=None, min_length=1, max_length=80)
    archived: bool | None = None

    @field_validator("title")
    @classmethod
    def normalize_title(cls, value: str | None) -> str | None:
        if value is None:
            return None
        normalized = " ".join(value.split())
        if not normalized:
            raise ValueError("title cannot be blank")
        return normalized

    @model_validator(mode="after")
    def require_change(self):
        if self.title is None and self.archived is None:
            raise ValueError("at least one session change is required")
        return self


class SessionHandoffCreate(BaseModel):
    plan_id: int


class PlanningQuestion(APIModel):
    id: str
    prompt: str
    why: str = ""
    options: list[str] = Field(default_factory=list)
    allow_custom: bool = True


class PlanningIntakeRead(APIModel):
    session_id: str
    goal: str
    confirmed_facts: list[dict[str, Any]]
    open_questions: list[PlanningQuestion]
    readiness: str
    readiness_confidence: float
    rationale: str
    source_run_id: str | None
    created_at: UTCInstant
    updated_at: UTCInstant


class PlanProposalRead(APIModel):
    id: str
    session_id: str
    source_run_id: str | None
    title: str
    rationale: str
    plan_payload: dict[str, Any]
    specialist_reports: list[dict[str, Any]]
    status: str
    plan_id: int | None
    decided_at: UTCInstant | None
    created_at: UTCInstant
    updated_at: UTCInstant


class PlanningStateRead(BaseModel):
    intake: PlanningIntakeRead | None = None
    proposal: PlanProposalRead | None = None


class PlanningAnswer(BaseModel):
    question_id: str = Field(min_length=1, max_length=80)
    answer: str = Field(min_length=1, max_length=4000)

    @field_validator("answer")
    @classmethod
    def normalize_answer(cls, value: str) -> str:
        return value.strip()


class PlanningAnswersSubmit(BaseModel):
    answers: list[PlanningAnswer] = Field(min_length=1, max_length=6)


class PlanProposalDecision(BaseModel):
    accepted: bool


class MessageEdit(BaseModel):
    content: str = Field(min_length=1, max_length=50000)
    rerun: Literal[True] = True

    @field_validator("content")
    @classmethod
    def normalize_content(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("message cannot be blank")
        return normalized


class PlanArchiveUpdate(BaseModel):
    archived: bool


class ChatMessageRead(APIModel):
    id: int
    session_id: str
    run_id: str | None
    message_key: str | None
    role: str
    content: str
    version: int
    content_hash: str
    validity_state: str
    invalidated_at: UTCInstant | None
    invalidation_reason: str
    reply_to_intervention_id: str | None
    message_metadata: dict[str, Any]
    created_at: UTCInstant


class RunEventRead(APIModel):
    id: int
    run_id: str
    sequence: int
    event_type: str
    event_key: str | None
    summary: str
    payload: dict[str, Any]
    created_at: UTCInstant


class OperationRead(APIModel):
    id: str
    run_id: str | None
    tool_name: str
    entity_type: str
    entity_id: str
    forward_patch: dict[str, Any]
    inverse_patch: dict[str, Any]
    status: str
    created_at: UTCInstant
    undone_at: UTCInstant | None
