from typing import Literal

from pydantic import BaseModel, Field
from sqlalchemy import select

from app.core.time import UTCInstant, canonical_utc, coerce_legacy_utc, utc_now
from app.db.uow import flush as flush_uow
from app.models import CalendarEvent, Operation, Plan, Task
from app.tools.base import ToolContext, ToolDefinition, ToolEffectKind, json_safe


class CalendarListArgs(BaseModel):
    starts_after: UTCInstant | None = None
    starts_before: UTCInstant | None = None
    plan_id: int | None = None
    limit: int = Field(default=30, ge=1, le=100)


class CalendarCreateArgs(BaseModel):
    title: str = Field(min_length=1, max_length=240)
    description: str = ""
    starts_at: UTCInstant
    ends_at: UTCInstant | None = None
    plan_id: int | None = None
    task_id: int | None = None


class CalendarPatchArgs(BaseModel):
    event_id: int
    title: str | None = None
    description: str | None = None
    starts_at: UTCInstant | None = None
    ends_at: UTCInstant | None = None
    status: Literal["scheduled", "completed", "cancelled"] | None = None


def _scope_error(ctx: ToolContext, plan_id: int | None) -> dict | None:
    if ctx.plan_id is not None and plan_id != ctx.plan_id:
        return {"error": "Plan-focused runs may only operate on their focused plan calendar"}
    return None


async def calendar_list(ctx: ToolContext, args: CalendarListArgs) -> dict:
    plan_id = args.plan_id if args.plan_id is not None else ctx.plan_id
    if error := _scope_error(ctx, plan_id):
        return error
    query = select(CalendarEvent).where(CalendarEvent.owner_id == ctx.owner_id)
    if plan_id is not None:
        query = query.where(CalendarEvent.plan_id == plan_id)
    if args.starts_after:
        query = query.where(CalendarEvent.starts_at >= args.starts_after)
    if args.starts_before:
        query = query.where(CalendarEvent.starts_at <= args.starts_before)
    events = list((await ctx.db.execute(query.order_by(CalendarEvent.starts_at).limit(args.limit))).scalars())
    return {"events": [{
        "id": event.id, "title": event.title, "description": event.description,
        "starts_at": canonical_utc(event.starts_at), "ends_at": canonical_utc(event.ends_at),
        "plan_id": event.plan_id, "task_id": event.task_id, "status": event.status,
    } for event in events]}


async def calendar_create(ctx: ToolContext, args: CalendarCreateArgs) -> dict:
    plan_id = args.plan_id if args.plan_id is not None else ctx.plan_id
    if error := _scope_error(ctx, plan_id):
        return error
    if args.ends_at and args.ends_at <= args.starts_at:
        return {"error": "ends_at must be later than starts_at"}
    if plan_id is not None:
        plan = await ctx.db.get(Plan, plan_id)
        if not plan or plan.owner_id != ctx.owner_id:
            return {"error": "Plan not found"}
        if plan.status == "archived":
            return {"error": "Restore the plan before changing its learning state"}
    if args.task_id is not None:
        task = (await ctx.db.execute(
            select(Task).join(Task.stage).join(Plan).where(
                Task.id == args.task_id,
                Plan.owner_id == ctx.owner_id,
                Plan.id == plan_id,
            )
        )).scalars().one_or_none()
        if not task:
            return {"error": "Task does not belong to the selected plan"}
    event = CalendarEvent(owner_id=ctx.owner_id, source="agent", **args.model_dump(exclude={"plan_id"}), plan_id=plan_id)
    ctx.db.add(event)
    await flush_uow(ctx.db)
    operation = Operation(
        owner_id=ctx.owner_id, invocation_id=ctx.invocation_id,
        run_id=ctx.run_id, tool_name="calendar.create",
        entity_type="calendar_event", entity_id=str(event.id),
        forward_patch={"created": event.id}, inverse_patch={"delete": event.id},
    )
    ctx.db.add(operation)
    await flush_uow(ctx.db)
    return {"event_id": event.id, "starts_at": canonical_utc(event.starts_at), "operation_id": operation.id, "undo_available": True}


async def calendar_patch(ctx: ToolContext, args: CalendarPatchArgs) -> dict:
    event = await ctx.db.get(CalendarEvent, args.event_id)
    if not event or event.owner_id != ctx.owner_id:
        return {"error": "Calendar event not found"}
    if error := _scope_error(ctx, event.plan_id):
        return error
    if event.plan_id is not None:
        plan = await ctx.db.get(Plan, event.plan_id)
        if not plan or plan.owner_id != ctx.owner_id:
            return {"error": "Plan not found"}
        if plan.status == "archived":
            return {"error": "Restore the plan before changing its learning state"}
    changes = args.model_dump(exclude={"event_id"}, exclude_unset=True)
    raw_effective_start = changes.get("starts_at", event.starts_at)
    raw_effective_end = changes.get("ends_at", event.ends_at)
    effective_start = (
        coerce_legacy_utc(raw_effective_start) if raw_effective_start is not None else None
    )
    effective_end = coerce_legacy_utc(raw_effective_end) if raw_effective_end is not None else None
    if effective_end and effective_end <= effective_start:
        return {"error": "ends_at must be later than starts_at"}
    before = {key: json_safe(getattr(event, key)) for key in changes}
    for key, value in changes.items():
        setattr(event, key, value)
    event.updated_at = utc_now()
    operation = Operation(
        owner_id=ctx.owner_id, invocation_id=ctx.invocation_id,
        run_id=ctx.run_id, tool_name="calendar.patch",
        entity_type="calendar_event", entity_id=str(event.id),
        forward_patch={"changes": json_safe(changes)}, inverse_patch={"changes": before},
    )
    ctx.db.add(operation)
    await flush_uow(ctx.db)
    return {"event_id": event.id, "status": event.status, "operation_id": operation.id, "undo_available": True}


CALENDAR_TOOLS = [
    ToolDefinition("calendar_list", "Inspect scheduled personal study events, optionally limited to the focused plan.", CalendarListArgs, calendar_list, effect_kind=ToolEffectKind.PURE_READ),
    ToolDefinition("calendar_create", "Create a reversible study calendar event for a plan or task.", CalendarCreateArgs, calendar_create, effect_kind=ToolEffectKind.DATABASE_WRITE, idempotent=True),
    ToolDefinition("calendar_patch", "Reschedule or update an existing study calendar event; changes are reversible.", CalendarPatchArgs, calendar_patch, effect_kind=ToolEffectKind.DATABASE_WRITE, idempotent=True),
]
