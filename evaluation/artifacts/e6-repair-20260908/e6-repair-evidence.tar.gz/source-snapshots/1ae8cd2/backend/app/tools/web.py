from html.parser import HTMLParser
from typing import Literal
from urllib.parse import urlparse

from app.core.config import settings
from app.core.time import utc_now
from app.db.uow import flush as flush_uow
from app.models import LearningEvent, LearningResource, Operation, Plan
from app.search import (
    current_snapshot_provider,
    fetch_with_safe_redirects,
    get_search_provider,
)
from app.search.security import (
    normalized_media_type,
    secure_http_client,
    validate_public_url,
)
from app.tools.base import ToolContext, ToolDefinition, ToolEffectKind, json_safe
from pydantic import BaseModel, Field
from sqlalchemy import select


class WebSearchArgs(BaseModel):
    query: str = Field(min_length=2, max_length=300)
    limit: int = Field(default=5, ge=1, le=10)
    plan_id: int | None = None
    save_results: bool = False


class WebOpenArgs(BaseModel):
    url: str = Field(min_length=8, max_length=2000)
    max_chars: int = Field(default=12000, ge=500, le=30000)


class ResourceSaveArgs(BaseModel):
    plan_id: int
    title: str = Field(min_length=2, max_length=300)
    url: str = Field(min_length=8, max_length=2000)
    resource_type: Literal["course", "tutorial", "lab", "documentation", "video", "book", "repository", "curriculum"]
    provider: str = Field(default="", max_length=120)
    language: str = Field(default="", max_length=32)
    difficulty: Literal["beginner", "intermediate", "advanced", "mixed"] = "mixed"
    summary: str = Field(min_length=8, max_length=1200)
    why_recommended: str = Field(min_length=8, max_length=1200)


class _TextParser(HTMLParser):
    SKIP = {"script", "style", "noscript", "svg"}

    def __init__(self):
        super().__init__()
        self.parts: list[str] = []
        self.depth = 0

    def handle_starttag(self, tag: str, attrs):
        if tag in self.SKIP:
            self.depth += 1
        elif tag in {"p", "h1", "h2", "h3", "li", "br"} and not self.depth:
            self.parts.append("\n")

    def handle_endtag(self, tag: str):
        if tag in self.SKIP and self.depth:
            self.depth -= 1

    def handle_data(self, data: str):
        if not self.depth:
            value = " ".join(data.split())
            if value:
                self.parts.append(value)


async def web_search(ctx: ToolContext, args: WebSearchArgs) -> dict:
    if ctx.plan_id is not None and args.plan_id not in {None, ctx.plan_id}:
        return {"error": "Plan-focused runs cannot save resources to another plan"}
    if args.save_results:
        return {
            "error": (
                "web_search is read-only; inspect the results and use resource_save "
                "for one deliberately selected resource"
            )
        }

    snapshot_provider = current_snapshot_provider()
    if snapshot_provider is not None:
        results = await snapshot_provider.search(args.query, args.limit)
        result_rows = []
        for result in results:
            row = result.as_dict()
            row.update(_catalog_metadata(result.url, result.title))
            row["external_untrusted"] = True
            result_rows.append(row)
        return {
            "provider": snapshot_provider.name,
            "query": args.query,
            "results": result_rows,
            "saved_resource_ids": [],
            "fallback_used": False,
            "external_untrusted": True,
        }

    primary_name = settings.WEB_SEARCH_PROVIDER
    fallback_name = settings.WEB_SEARCH_FALLBACK_PROVIDER
    provider = get_search_provider(primary_name)
    fallback_used = False
    try:
        results = await provider.search(args.query, args.limit)
    except Exception:
        if not fallback_name or fallback_name.lower() == "none" or fallback_name.lower() == primary_name.lower():
            raise
        provider = get_search_provider(fallback_name)
        results = await provider.search(args.query, args.limit)
        fallback_used = True
    if not results and fallback_name and fallback_name.lower() not in {"none", primary_name.lower()}:
        provider = get_search_provider(fallback_name)
        results = await provider.search(args.query, args.limit)
        fallback_used = True
    result_rows = []
    for result in results:
        row = result.as_dict()
        row.update(_catalog_metadata(result.url, result.title))
        row["external_untrusted"] = True
        result_rows.append(row)
    return {
        "provider": provider.name,
        "query": args.query,
        "results": result_rows,
        "saved_resource_ids": [],
        "fallback_used": fallback_used,
        "external_untrusted": True,
    }


async def resource_save(ctx: ToolContext, args: ResourceSaveArgs) -> dict:
    if ctx.plan_id is not None and args.plan_id != ctx.plan_id:
        return {"error": "Plan-focused runs cannot save resources to another plan"}
    # DNS/redirect validation is external I/O and must finish before this
    # handler opens its domain-write transaction.
    snapshot_provider = current_snapshot_provider()
    if snapshot_provider is not None:
        await snapshot_provider.validate(args.url)
    else:
        await validate_public_url(args.url)
    await ctx.enter_database_write_phase()
    plan = await ctx.db.get(Plan, args.plan_id)
    if not plan or plan.owner_id != ctx.owner_id:
        return {"error": "Plan not found"}
    if plan.status == "archived":
        return {"error": "Restore the plan before saving resources"}
    resource = (await ctx.db.execute(
        select(LearningResource).where(
            LearningResource.owner_id == ctx.owner_id,
            LearningResource.plan_id == args.plan_id,
            LearningResource.url == args.url,
        )
    )).scalars().one_or_none()
    created = resource is None
    if created:
        resource = LearningResource(owner_id=ctx.owner_id, plan_id=args.plan_id, title=args.title, url=args.url)
        ctx.db.add(resource)
        await flush_uow(ctx.db)
        inverse = {"delete": resource.id}
    else:
        inverse = {"changes": {
            "title": resource.title,
            "resource_type": resource.resource_type,
            "provider": resource.provider,
            "language": resource.language,
            "difficulty": resource.difficulty,
            "summary": resource.summary,
            "why_recommended": resource.why_recommended,
            "source": resource.source,
            "verified_at": json_safe(resource.verified_at),
        }}

    provider = args.provider.strip() or _catalog_metadata(args.url, args.title)["provider"]
    changes = {
        "title": args.title,
        "resource_type": args.resource_type,
        "provider": provider,
        "language": args.language,
        "difficulty": args.difficulty,
        "summary": args.summary,
        "why_recommended": args.why_recommended,
        "source": "agent_curated",
        "verified_at": utc_now(),
    }
    for field, value in changes.items():
        setattr(resource, field, value)
    operation = Operation(
        owner_id=ctx.owner_id,
        invocation_id=ctx.invocation_id,
        run_id=ctx.run_id,
        tool_name="resource.save",
        entity_type="learning_resource",
        entity_id=str(resource.id),
        forward_patch={"changes": json_safe(changes)},
        inverse_patch=inverse,
    )
    ctx.db.add_all([
        operation,
        LearningEvent(
            owner_id=ctx.owner_id,
            plan_id=args.plan_id,
            run_id=ctx.run_id,
            event_type="resource.curated",
            summary=f"Curated {args.resource_type}: {args.title}",
            payload={"resource_id": resource.id, "url": args.url, "provider": provider},
        ),
    ])
    await flush_uow(ctx.db)
    return {
        "resource_id": resource.id,
        "plan_id": args.plan_id,
        "created": created,
        "operation_id": operation.id,
        "undo_available": True,
    }


async def web_open(_: ToolContext, args: WebOpenArgs) -> dict:
    snapshot_provider = current_snapshot_provider()
    if snapshot_provider is not None:
        return await snapshot_provider.open(args.url, args.max_chars)
    headers = {"User-Agent": "Mozilla/5.0 LearningAgent/0.4"}
    async with secure_http_client(headers=headers) as client:
        response, redirect_count = await fetch_with_safe_redirects(client, args.url)
    content_type = normalized_media_type(response)
    allowed_content_types = {
        "application/json",
        "application/xhtml+xml",
        "application/xml",
        "text/html",
        "text/plain",
        "text/xml",
    }
    if content_type not in allowed_content_types:
        return {"error": f"Unsupported content type: {content_type}"}
    parser = _TextParser()
    parser.feed(response.text)
    text = " ".join("".join(parser.parts).split())
    return {
        "url": str(response.url),
        "title": _page_title(response.text),
        "content": text[: args.max_chars],
        "truncated": len(text) > args.max_chars,
        "redirect_count": redirect_count,
        "external_untrusted": True,
    }


def _page_title(html: str) -> str:
    start = html.lower().find("<title")
    if start < 0:
        return ""
    start = html.find(">", start) + 1
    end = html.lower().find("</title>", start)
    return " ".join(html[start:end].split()) if end >= start else ""


def _catalog_metadata(url: str, title: str = "") -> dict[str, str]:
    host = (urlparse(url).hostname or "").lower().removeprefix("www.")
    provider = host or "Web"
    providers = {
        "runoob.com": "菜鸟教程",
        "coursera.org": "Coursera",
        "huggingface.co": "Hugging Face",
        "kaggle.com": "Kaggle",
        "edx.org": "edX",
        "freecodecamp.org": "freeCodeCamp",
        "csdiy.wiki": "CS 自学指南",
        "youtube.com": "YouTube",
        "youtu.be": "YouTube",
        "bilibili.com": "哔哩哔哩",
    }
    for domain, name in providers.items():
        if host == domain or host.endswith(f".{domain}"):
            provider = name
            break
    if "stanford" in host or "cs336" in host:
        provider = "Stanford"

    value = f"{host} {urlparse(url).path} {title}".lower()
    if "kaggle.com/learn" in value or "lab" in value:
        resource_type = "lab"
    elif "stanford" in host or "cs336" in value:
        resource_type = "course"
    elif any(domain in host for domain in ("coursera.org", "edx.org")) or "/course" in value or "/learn" in value:
        resource_type = "course"
    elif "runoob.com" in host or "tutorial" in value:
        resource_type = "tutorial"
    elif any(domain in host for domain in ("youtube.com", "youtu.be", "bilibili.com")):
        resource_type = "video"
    elif "github.com" in host:
        resource_type = "repository"
    elif "csdiy.wiki" in host or "curriculum" in value:
        resource_type = "curriculum"
    elif "docs" in value or "documentation" in value:
        resource_type = "documentation"
    else:
        resource_type = "tutorial"
    return {"provider": provider, "resource_type": resource_type}


WEB_TOOLS = [
    ToolDefinition("web_search", "Search the public web without mutating the resource catalog. Results include inferred provider and resource type; use resource_save after inspection.", WebSearchArgs, web_search, effect_kind=ToolEffectKind.EXTERNAL_READ, idempotent=True),
    ToolDefinition("web_open", "Open a public HTTP(S) page, validate every redirect hop, and extract readable text for source verification.", WebOpenArgs, web_open, effect_kind=ToolEffectKind.EXTERNAL_READ),
    ToolDefinition("resource_save", "Save or update one deliberately selected learning resource after opening it. Record its course/tutorial type, level, language, summary, and why it fits this plan.", ResourceSaveArgs, resource_save, effect_kind=ToolEffectKind.DATABASE_WRITE, idempotent=True, defer_write_guard=True),
]
