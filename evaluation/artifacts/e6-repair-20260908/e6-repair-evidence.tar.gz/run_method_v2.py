import argparse,json,subprocess,sys
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
root=Path(__file__).parent;p=argparse.ArgumentParser();p.add_argument('part',choices=['cal','dev','controlled']);a=p.parse_args()
def call(name,cmd,paid=False,allowed=(0,2)):
 args=[sys.executable,str(root/'invoke.py'),'--clone',str(root/'run-v2'),'--log',str(root/'logs'/f'{name}-v2.log')]+(['--paid'] if paid else [])+['--',*cmd]
 result=subprocess.run(args)
 if result.returncode not in allowed:raise RuntimeError(f'{name} failed: {result.returncode}')
old=json.loads((root/'logs'/f'{a.part if a.part!="controlled" else "controlled"}-runtime-v1.execution.json').read_text())
cmd=[x.replace('method-v1','method-v2').replace('development-v1','development-v2').replace('decisionbench-v1.1','decisionbench-v1.2') for x in old['command'][1:]]
call(a.part+'-runtime',cmd,old['paid_enabled'])
runtime=root/'method-v2'/({'cal':'runtime','dev':'dev-runtime','controlled':'controlled-runtime'}[a.part]);rules=runtime.parent/({'cal':'rules','dev':'dev-rules','controlled':'controlled-rules'}[a.part])
call(a.part+'-rules',['-m','learning_agent_eval','evaluate-rules','--input',str(runtime),'--output',str(rules)])
ledger='/root/.local/state/learning-travel/e4-hy3-20260905-osj4FCZZ-budget.json'
if a.part=='cal':
 out=root/'method-v2/experiments'
 base=['evaluation/scripts/run_e5_experiments.py']
 inputs=['--output',str(out),'--runtime',str(runtime),'--rules',str(rules)]
 call('cal-design',base+['prepare',*inputs,'--dataset','evaluation/datasets/decisionbench-v1.2-regression/calibration','--experiment-version','e6-repair-method-2-calibration'])
 def phase(x):call('cal-'+x,base+[x,*inputs,'--budget-ledger',ledger],True)
 with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(phase,['discrimination','repeat']))
 call('cal-summarize',base+['summarize','--output',str(out)])
elif a.part=='controlled':
 def judge(n):call(f'controlled-judge-r{n}',['-m','learning_agent_eval','evaluate-judge','--episodes',str(runtime),'--rules',str(rules),'--output',str(root/f'method-v2/controlled-judge-r{n}'),'--judge-mode','real','--allow-real-judge','--budget-ledger',ledger],True)
 with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(judge,[1,2,3]))
