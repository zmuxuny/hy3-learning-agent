import json,shutil
from pathlib import Path
from learning_agent_eval.canonical import sha256_digest
root=Path('/root/workspace/tencent_rhinobird2026/learning_travel'); tmp=Path('/tmp/learning-e6-repair-hoxki28l'); design=root/'evaluation/case-design'
s=json.loads((tmp/'heldout-content-review.json').read_text()); shutil.copy2(tmp/'heldout-content-review.json',design/'e6-repair-secondary-content-review.json')
r={'review_version':'e6-repair-primary-content-review-v1','reviewer_role':'primary_ai_reviewer','disclosure':'主AI逐项检查设计、数学反例、授权范围及48条第二AI复核意见后确认。主AI和第二AI均参与开发，不是独立人类盲审；未运行G家族Agent/Judge，不使用其输出调优。第二AI原始记录单独保留身份。','secondary_review_sha256':s['review_sha256'],'design_sha256':s['design_sha256'],'resource_sha256':s['resource_sha256'],'rows':[{k:row[k] for k in ('case_id','authored_case_sha256','verdict','rationale')}|{'reviewer_role':'primary_ai_reviewer'} for row in s['rows']]}
r['review_sha256']=sha256_digest(r); (design/'e6-repair-content-review.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
archive=tmp/'pre-freeze-input-corrections'; archive.mkdir(exist_ok=True)
for name in ['decisionbench-v1.4-e6-test-draft','decisionbench-v1.4-e6-test-draft-v2']:shutil.move(str(root/'evaluation/datasets'/name),str(archive/name))
print(r['review_sha256'])
