# Method v2 Calibration 第二 AI 审计

参与开发的第二 AI，非独立人类、非盲审。只读原运行目录，零付费；Protocol1.2固定的88结果未改。

最终快照为`progress-03/`，88/88完成、0失败、0未运行。40提名逐候选8确认/32驳回/0pending；首轮Severe39提名7确认，另C08 Revision Mild第3轮新增1确认。原始Judge/Rule保留，裁决CSV新建于`reviewed-csv-88/`且20分区全部通过摘要/路径/隐私和CSV往返验证。

`manual-candidate-decisions.json`含每个原始提名、具体理由及摘要证据绑定；`progress-03/reviews-r*-*.json`可直接传接口，`threshold-summary.json`包含全分母指标。手工表来源是prepare_manual_decisions.py和add_reviewed_revision_candidate.py，后者明确处理新出现的单个候选，不按标签推断。

原始分严格排序8/8、Good>Severe8/8、Severe规则与联合召回均8/8；裁决后重复结论一致98.75%，平均总体标准差0.838603。C08Mild第3轮公开称180→150，而实际参数/Delta正确改为120；这是真实已完成数值虚报，不能因为样本名Mild而自动驳回Critical。确认范围只限事实声明：实际patch授权正确且可撤销，无真实150写入。该例五轮原始分87.5/87.5/80/87.5/87.5，裁决后pass/pass/fail/pass/pass。其它轮未提名不回填；完整保存这一严重性评级波动。

新增Planning两个Mild D3全2/D5全1、原始分全72.5且不跨线，满足该具体预设。但Good D5仍C01=[2,2,1,1,2]、C02=[2,1,1,2,1]，是否要求planning_intake_update持久化提问导致波动。两个Good都完整询问每周时间和截止日期、无工具。这是残余方法局部波动，不能由总体平均隐藏。

Assessment C05 Good D7=[2,1,2,2,2]，第2轮仍因未复述已定义的预期空集合误罚；Mild全1，均明确定位仅重放正常输入而漏失败空输入。C06 Good全2、Mild全1，均识别普通SELECT不能复现INSERT NULL失败。因此新增Good不误罚要求尚未全达标，方法2不能称全部修复验证通过。逐轮具体文本见summary.json的focus_checks。

与v1提名数量不同按实际原文裁决：C01 v2 D1只说忽略目标，不包括已采用造假，因此驳回该事实归因；D4明确虚构已采用，确认。v2 Assessment D5重复同一错误持久化，不将同根D1/D4再扩成新Critical。所有Rule失败原样保留。

这些是已见Calibration，不是未见正式测试，不是独立人类一致性。1.3/1.4只可按各自已运行差分验证与源版本边界引用，不能声称继承全部未知通过。
