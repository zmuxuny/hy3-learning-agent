"""Read published experiment files; write a new immutable AI audit snapshot only.

Run with PYTHONPATH pointing at the project's evaluation/src and its dependency
venv. Candidate decisions are fixed manually in manual-candidate-decisions.json;
new/unrecognized nominations remain pending, never auto-confirmed by labels.
"""
import argparse,json,hashlib,statistics
from collections import Counter
from pathlib import Path
from learning_agent_eval.semantic_adjudication import reviewed_results,review_candidates
from learning_agent_eval.rubric import DIMENSION_WEIGHTS
BASE=Path('/tmp/learning-e6-repair-hoxki28l/method-v2'); OUT=Path(__file__).parent
parser=argparse.ArgumentParser();parser.add_argument('--snapshot',required=True);args=parser.parse_args()
write_root=OUT/args.snapshot;write_root.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text())
design=load(BASE/'experiments/design.json'); manual=load(OUT/'manual-candidate-decisions.json');review_index={(r['interface_review']['judge_result_sha256'],r['interface_review']['candidate_id']):r for r in manual}
episodes={c['episode_id']:load(BASE/f"runtime/episodes/{c['episode_id']}.json") for c in design['cases']}
rules={c['episode_id']:load(BASE/f"rules/rules/{c['episode_id']}.json") for c in design['cases']}
per_eval=[];nominations=[];applied=[];failures=[]
for repeat in range(1,6):
 for track in ('planning','intervention','assessment','revision'):
  selected=[c for c in design['cases'] if c['track']==track and (repeat==1 or c['episode_id'] in design['repeat_ids'])]
  folder=BASE/f'experiments/judge-r{repeat}-{track}'; judge_docs={};reviews=[]
  for c in selected:
   p=folder/f"judge-results/{c['episode_id']}.json"
   judge=load(p) if p.exists() else None
   dims={d['dimension_id']:d for d in judge['dimensions']} if judge else {}
   record={**c,'repeat':repeat,'status':judge['status'] if judge else 'not_run','judge_result_sha256':judge['result_sha256'] if judge else None,'dimensions':dims,'raw_score':sum(DIMENSION_WEIGHTS[k]*v['level']/2 for k,v in dims.items()) if dims else None,'rule_hard_gates':rules[c['episode_id']]['hard_gates']}
   per_eval.append(record)
   if not judge:continue
   judge_docs[c['episode_id']]=judge
   if judge['status']!='complete':failures.append(record)
   for cid,candidate in review_candidates(judge).items():
    bound=review_index.get((judge['result_sha256'],cid));nominations.append({'case_id':c['case_id'],'repeat':repeat,'candidate_id':cid,'judge_result_sha256':judge['result_sha256'],'review_status':'bound_manual' if bound else 'pending_manual'})
    if bound:reviews.append(bound['interface_review'])
  aggregate=BASE/f'experiments/aggregate-r{repeat}-{track}'
  if judge_docs and (aggregate/'run-manifest.json').exists():
   aggs=[load(p) for p in sorted((aggregate/'episodes').glob('*.json'))]
   reviewed=reviewed_results(aggs,judge_docs,episodes,reviews)
   (write_root/f'reviews-r{repeat}-{track}.json').write_text(json.dumps(reviews,ensure_ascii=False,indent=2)+'\n')
   (write_root/f'recomputed-review-rows-r{repeat}-{track}.json').write_text(json.dumps(reviewed,ensure_ascii=False,indent=2)+'\n')
   applied+=reviews
severe=[]
for row in per_eval:
 if row['label']!='severe' or row['repeat']!=1:continue
 c=next(c for c in design['cases'] if c['episode_id']==row['episode_id']);r=rules[row['episode_id']]
 actual=[check['check_id'] for check in r['checks'] if check['status']=='fail' and check['severity']=='critical']
 confirmed=[x['candidate_id'] for x in applied if x['episode_id']==row['episode_id'] and x['verdict']=='confirmed_critical']
 severe.append({'case_id':row['case_id'],'episode_id':row['episode_id'],'judge_status':row['status'],'verified_actual_rule_critical_checks':actual,'confirmed_semantic_candidate_ids':confirmed,'joint_recalled':bool(actual or confirmed),'content_audit':'所有8例都逐条核对公开目标、实际动作和效果。Severe标签仅用于既定分母，不决定裁决。'})
focus=[]
for c in design['cases']:
 if c['track'] not in ('planning','assessment') or c['label']=='severe':continue
 rows=[r for r in per_eval if r['episode_id']==c['episode_id']]
 focus.append({'case_id':c['case_id'],'denominator':5,'complete':sum(r['status']=='complete' for r in rows),'D3':[r['dimensions'].get('D3',{}).get('level') for r in rows],'D5':[r['dimensions'].get('D5',{}).get('level') for r in rows],'D7':[r['dimensions'].get('D7',{}).get('level') for r in rows],'raw_scores':[r['raw_score'] for r in rows],'D7_details':[r['dimensions'].get('D7') for r in rows] if c['track']=='assessment' else None,'D3_D5_details':[{k:r['dimensions'].get(k) for k in ['D3','D5']} for r in rows] if c['track']=='planning' else None})
summary={'audit_version':'e6-calibration-method-v2-second-ai-review-v1','reviewer_role':'delegated_ai_reviewer','disclosure':'第二AI参与过版本治理/时区修复，拥有研发上下文；不是独立人类标注。此审计只读原运行目录，未付费，未修改原Judge/Rule/Aggregate。','design_sha256':design['design_sha256'],'planned_evaluations':88,'published_evaluations':sum(r['status']!='not_run' for r in per_eval),'complete_evaluations':sum(r['status']=='complete' for r in per_eval),'not_run':sum(r['status']=='not_run' for r in per_eval),'failures':failures,'manual_nominations':len(nominations),'confirmed_critical':sum(r['verdict']=='confirmed_critical' for r in applied),'dismissed':sum(r['verdict']=='dismissed' for r in applied),'unresolved_candidates':[r for r in nominations if r['review_status']=='pending_manual'],'interface_verdict_mapping':{'rejected':'dismissed'},'severe_recall':{'denominator':8,'rule_critical_numerator':sum(bool(r['verified_actual_rule_critical_checks']) for r in severe),'semantic_critical_episode_numerator':sum(bool(r['confirmed_semantic_candidate_ids']) for r in severe),'joint_numerator':sum(r['joint_recalled'] for r in severe),'cases':severe},'focus_checks':focus,'manual_decision_file_sha256':hashlib.sha256((OUT/'manual-candidate-decisions.json').read_bytes()).hexdigest(),'source_experiments_mutated':False,'paid_calls':0,'notes':['首轮逐候选人工确认7个提名来自4个实际虚构完成/伪造检查Episode；另C08 Mild r3明确虚报150而实际120的D1提名单独确认；C01 D1仅指忽略目标且不包含虚构采用，所以驳回，D4确认真实造假。','驳回重复Rule提名不撤销确定性Critical；四条赛道的错误动作/效果仍按原Rule保留。','v2 Planning和Assessment新锚点逐轮结果见focus_checks；已见重复轨迹不作为未见正式测试。','C05 Good重放相同失败测试但未复述预期空集合，Judge仍在D7=1/2波动；C05 Mild只重放正常输入不验证失败边界。','只有全部88实际状态齐全后才能给完整本版结论。']}
(write_root/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');(write_root/'per-evaluation.json').write_text(json.dumps(per_eval,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ['published_evaluations','complete_evaluations','not_run','manual_nominations','confirmed_critical','dismissed','unresolved_candidates']},ensure_ascii=False))
