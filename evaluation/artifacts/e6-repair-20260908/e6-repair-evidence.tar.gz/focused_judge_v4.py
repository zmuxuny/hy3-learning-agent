"""Predeclared 4 x 5 Assessment differential test; failures retain their denominator."""
import argparse,json,subprocess
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from learning_agent_eval.active_judge import evaluate_active_judges
from learning_agent_eval.canonical import sha256_digest
from learning_agent_eval.rubric import JUDGE_PROMPT_SHA256_V3,JUDGE_CONFIG_DOCUMENT_V3
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--ledger',type=Path,required=True);a=p.parse_args();root=a.root
runtime=root/'runtime';rules=root/'rules';out=root/'focused';out.mkdir(exist_ok=False)
cases=[json.loads(f.read_text()) for f in Path('evaluation/datasets/decisionbench-v1.4-regression/calibration/cases').glob('*.json')]
from learning_agent_eval.case_specs import episode_id_for_case
selected={episode_id_for_case(c):c for c in cases if c['track']=='assessment' and c['private_annotations']['quality_label'] in ['good','mild']}
assert len(selected)==4
load=lambda p:json.loads(p.read_text())
design={'version':'e6-assessment-differential-v1','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'judge_prompt_sha256':JUDGE_PROMPT_SHA256_V3,'judge_config':JUDGE_CONFIG_DOCUMENT_V3,'planned_evaluations':20,'repeats':5,'formal':False,'cases':[{'case_id':c['case_id'],'episode_id':eid,'label':c['private_annotations']['quality_label'],'episode_sha256':load(runtime/'episodes'/f'{eid}.json')['provenance']['episode_sha256'],'rule_sha256':load(rules/'rules'/f'{eid}.json')['result_sha256']} for eid,c in sorted(selected.items())],'criteria':'all Good D7=2; all Mild D7<=1 with same-failed-test defect located; no missing evaluation is a pass'}
design['design_sha256']=sha256_digest(design);(out/'design.json').write_text(json.dumps(design,ensure_ascii=False,indent=2)+'\n')
def run(n):
 r=evaluate_active_judges(episodes=runtime,rules=rules,output=out/f'judge-r{n}',judge_mode='real',allow_real_judge=True,budget_ledger=a.ledger,episode_ids=set(selected));print('round',n,'complete',len(r.episode_ids),'errors',len(r.judge_error_episode_ids),flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,range(1,6)))
rows=[]
for n in range(1,6):
 for eid,c in sorted(selected.items()):
  path=out/f'judge-r{n}/judge-results/{eid}.json';j=load(path) if path.exists() else {};d7=next((d for d in j.get('dimensions',[]) if d['dimension_id']=='D7'),None);good=c['private_annotations']['quality_label']=='good'
  rows.append({'case_id':c['case_id'],'repeat':n,'status':j.get('status','not_run'),'D7':d7,'automatic_target_met':bool(j.get('status')=='complete' and d7 and (d7['level']==2 if good else d7['level']<=1)),'result_sha256':j.get('result_sha256')})
summary={'design_sha256':design['design_sha256'],'denominator':20,'complete':sum(r['status']=='complete' for r in rows),'automatic_targets_met':all(r['automatic_target_met'] for r in rows),'requires_manual_specific_issue_review':True,'rows':rows};(out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='rows'}),flush=True)
