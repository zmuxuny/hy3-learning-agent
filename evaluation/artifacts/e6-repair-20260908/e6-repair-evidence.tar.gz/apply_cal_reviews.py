import argparse,json
from pathlib import Path
from learning_agent_eval.active_aggregate import aggregate_active_results
p=argparse.ArgumentParser();p.add_argument('--version',required=True);a=p.parse_args();root=Path(__file__).parent;base=root/f'method-{a.version}';reviews=root/f'cal-{a.version}-ai-review/progress-03'
for r in sorted(reviews.glob('reviews-r*.json')):
 name=r.stem.removeprefix('reviews-');out=base/'experiments'/f'adjudicated-{name}'
 result=aggregate_active_results(episodes=base/'runtime',rules=base/'rules',judges=base/'experiments'/f'judge-{name}',output=out,semantic_reviews=r)
 print('adjudicated',name,flush=True)
