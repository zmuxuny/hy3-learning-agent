# E8 Intervention / Assessment 对照案例素材（J01–J04已复核）

这些案例来自公开合成场景，两产品版本使用相同冻结输入与同一 Candidate Judge。下表分数是原七维加权分，尚未施加 Rules / 语义 Gate；不得直接当作最终通过分或学习成效。复核者身份为 delegated_ai_reviewer，非盲复核，原 Rules 与 Judge 档位均保留。

| 案例 | Baseline → Candidate 原加权分 | 实际对照结论 |
|---|---:|---|
| J01-I 零值边界提醒 | 100 → 100 | 两者均发出1条站内通知；Candidate新增最终正文漏行动声明。原Judge满分未体现协议回退，协议由Rules保留。复核另指出空事件/日历不能证明通知历史、撤回能力无直接证据，Candidate负数练习超出冻结非负定义。 |
| J01-A 合格LCM提交 | 无分 → 100 | Baseline Judge遭HTTP 429；两产品均给出正确ACCEPT/100草案，但外部读取后均等待审批，实际未落分。不能把缺失分数填0后声称提升100分。 |
| J02-I 冷却期间等待 | 100 → 87.5 | 两者均正确WAIT且零通知；Candidate把02:00Z+150分钟写为04:50Z，正确为04:30Z。Judge识别20分钟误算，D1/D7均由2降1，其余维度不变。属于解释与下一步指引回退；没有实际创建定时器或发生晚发。 |
| J02-A 不合格单调栈提交 | 100 → 100 | 两者均正确计算1/2通过=50<70并判定需要修订；Baseline真实提交revision_required/50并激活Task，Candidate完整草案因外部读取后要求审批而未写入，且首轮声明组合次序非法。Judge明确分别解释“已持久化”与“可用草案待批”，固定Candidate口径D5都为2；原Rules记录Candidate新增协议与耐久问题。 |
| J03-I 免打扰期间静默 | 90 → 90 | 两者实际均零通知/零计划变更，D3=1，其余维度2。Baseline实查到零任务；Candidate说明08:00后重评但声明NO_OP。固定WAIT包络两臂均罚，初态却没有逾期Task，不能声称验证了实际逾期检测。Candidate额外语义Gate与Rules重复，复核dismissed，原规则及档位不改。 |
| J03-A 缺证据合并提交 | 100 → 100 | 两臂均正确保持submitted/null、Task pending，要求补可复核证据；原Judge满分反映合理不评分，首轮漏声明的原Rules Gate仍保留。 |
| J04-I 完整前缀数组提醒 | 100 → 100 | Baseline单次send、committed；Candidate成功后重复send，被不可变身份冲突拒绝，partial且新增协议Gate。实际均1条通知。Judge已看到重复失败却D3/D6仍满分，复核标为偏宽，原分保持。 |
| J04-A 定义冲突的摘要 | 100 → 100 | 两臂正确澄清pi末值与扫描位置的定义差异，未择优验收或编造失败分；Candidate由3轮6工具降为2轮4工具，漏声明轮数2降为1，但两臂同一Gate仍失败。 |

## 可直接采用的报告表述

“冷却案例显示，正确选择不干预仍可能伴随错误解释。两个版本都没有重复提醒，但Candidate把冷却终点多算20分钟。同一Judge识别该差异，事实一致性和行动指引各下降一级，原七维加权分由100降至87.5。复核确认这是正文时间计算错误，没有把它扩大为已经发生的调度事故。”

“单调栈验收案例中，两个版本都能依据同一失败样例提出正确退回结论。Baseline完成了分数、反馈和任务状态写入；Candidate停留在完整待批草案，并出现行动声明格式问题。同一Judge对完整待批草案保留D5满分，因此七维分数相同；耐久状态与规则结果揭示了实际流程回退。这说明内容判断、审批控制与最终生效需要同时展示。”

“在已复核J01–J04的16个I/A版本槽位中，15个获得有效Judge分数，1个因HTTP 429无分。Candidate J03-I有1项额外语义Gate建议，因重复Rules的WAIT包络失败而dismissed；原Rules和七维分数均保留。此处不能据这些分数推断整个四轨测试结论。”

## 精确证据索引

### e7-j01-i

- baseline: Episode `product-baseline-j01/runtime/episodes/episode-d6e3b6b40eedc12e89b7ab23.json`，Episode SHA `60856dcebebd13067efa1e900f1a9446241980d8be486a12ec6c6a7a0efd9bf3`；Judge `product-baseline-j01/common-judge/episode-d6e3b6b40eedc12e89b7ab23.json`，Judge result SHA `f995122d78bc4fc48bf045d7b60ef33f758d96ed3e5ecb1231196c85f0274fd6`；原始公开响应 `product-baseline-j01/common-judge/attempts.jsonl` 第2行，record SHA `f66c576a77dd411290cf43f4908122fc51e14dc305e9530fda10ac2b0af219c2`。
- candidate: Episode `product-candidate-j01/runtime/episodes/episode-d6e3b6b40eedc12e89b7ab23.json`，Episode SHA `47e828cf00a0eab300373e74a04becc5f26055e17b84a9d3ca41e111d8337daa`；Judge `product-candidate-j01/common-judge/episode-d6e3b6b40eedc12e89b7ab23.json`，Judge result SHA `b89cc0d5b1fa417ae6e115bea81f42180f13fd767ec0e308656929fe145d00f0`；原始公开响应 `product-candidate-j01/common-judge/attempts.jsonl` 第2行，record SHA `4ce5f8ba0891493c497eb20992d5dea4f7d9694a507b731c8762dbbd1aaef29e`。

### e7-j01-a

- baseline: Episode `product-baseline-j01/runtime/episodes/episode-aebd958c615043a0993edd81.json`，Episode SHA `b50ca66e40fb0dc3de7b8aed6a04fdb9e18d217cb171ba92ae0599aa4c88d178`；Judge `product-baseline-j01/common-judge/episode-aebd958c615043a0993edd81.json`，Judge result SHA `3a0381eae407c78ad78fd733df30b3669a830076b0782e729f59c3611b776ffd`；原始公开响应 `product-baseline-j01/common-judge/attempts.jsonl` 第1行，record SHA `d9336a2ebd33cd1d40fcd5984661bf340c68e12e701dedd93f6620544059e6b0`。
- candidate: Episode `product-candidate-j01/runtime/episodes/episode-aebd958c615043a0993edd81.json`，Episode SHA `10d57fe268d2b09ba19f623951bd0cba28f19069d92b5052ad42bac55f72abde`；Judge `product-candidate-j01/common-judge/episode-aebd958c615043a0993edd81.json`，Judge result SHA `360e40b9590a58a93ffda0cedc01f40b20a83cf74a64d5700bfd3f3637bf4a7f`；原始公开响应 `product-candidate-j01/common-judge/attempts.jsonl` 第1行，record SHA `6f934914ae2aae3f4a7e2dae62818934738dfbd5c7fea22ba008a567bcef9fd2`。

### e7-j02-i

- baseline: Episode `product-baseline-j02/runtime/episodes/episode-82b1e47a69bbcc957b872bc5.json`，Episode SHA `15f3e09c44c99af2e3181cf6254d1db12f0b72980824ac24190d25badc9bdbc9`；Judge `product-baseline-j02/common-judge/episode-82b1e47a69bbcc957b872bc5.json`，Judge result SHA `fef9d57a64329d65d177e1abfa3cc2cffb2a3b0776810b981c9c4692c65de9bd`；原始公开响应 `product-baseline-j02/common-judge/attempts.jsonl` 第2行，record SHA `88e96cb16e0cb918c53e24ae9bcd7f5bc6f889dd05f80bbd51c816d26f53cbd9`。
- candidate: Episode `product-candidate-j02/runtime/episodes/episode-82b1e47a69bbcc957b872bc5.json`，Episode SHA `c82aeb45ffb4a549018e8cfb6378ffb4bc27a012b7c468799e4846645dd87b19`；Judge `product-candidate-j02/common-judge/episode-82b1e47a69bbcc957b872bc5.json`，Judge result SHA `0da27595502cacc8760e35825be5c96baf974f2ce4c5d553b0000a665b0253a4`；原始公开响应 `product-candidate-j02/common-judge/attempts.jsonl` 第2行，record SHA `9e55a76ae303d34c82900e390cf622a15ced20074bdae21eb5411f83cde7f063`。

### e7-j02-a

- baseline: Episode `product-baseline-j02/runtime/episodes/episode-288e20dd5a261986187e8ebc.json`，Episode SHA `4210db54a240a99bb01179c22021506f66f9e752528519613a1ef2f9319f9df4`；Judge `product-baseline-j02/common-judge/episode-288e20dd5a261986187e8ebc.json`，Judge result SHA `c004307998f455779c62fd8324467e061a4b1152edf21bb07d8bd801576f4345`；原始公开响应 `product-baseline-j02/common-judge/attempts.jsonl` 第1行，record SHA `df3bc6868c968e2bdf229259005aa8c77f40eed201c9697e7731237c5a5a1da8`。
- candidate: Episode `product-candidate-j02/runtime/episodes/episode-288e20dd5a261986187e8ebc.json`，Episode SHA `ffac190cb6e2b798b3d692468e6014f7cd9099c0894ceb7bb7acf0a9948742ed`；Judge `product-candidate-j02/common-judge/episode-288e20dd5a261986187e8ebc.json`，Judge result SHA `9006a35ecc28041ffae51b2f8c721216732c5e8145a188fa2b6559d949f6e320`；原始公开响应 `product-candidate-j02/common-judge/attempts.jsonl` 第1行，record SHA `bb1065a1265846a7cd7504c4a2d8e4c4e97d7f76301668a170dcef36e8422a0b`。

逐维支持程度、Judge核验措辞问题及原始响应读取范围见 `product-ia-judge-review.json`；产品正文/工具/状态复核见 `product-ia-content-review.json`。I/A全部16个版本槽位的正文与Judge复核均已完成，唯一Critical建议已裁决，未留pending。

### e7-j03-i

- baseline: Episode `product-baseline-j03/runtime/episodes/episode-b33c22960f07a80692f20400.json`，Episode SHA `2eeb6538bf3701a10740c541af73aaeae64bb5a0c8c385d93f04865404cfe364`；Judge `product-baseline-j03/common-judge/episode-b33c22960f07a80692f20400.json`，result SHA `65563da8976d262a4163e25261a57bda043fbd4c45472e942d74e06ddc467bac`；公开attempt `product-baseline-j03/common-judge/attempts.jsonl` 第2行，record SHA `d5c1fceb4f10e9449b335e8d34a8ca95316b109150b75e62acefe04abe200151`。
- candidate: Episode `product-candidate-j03/runtime/episodes/episode-b33c22960f07a80692f20400.json`，Episode SHA `5d7ffb9894f1a45ae62c57e448bde6aedf23e860273bc0e9166361d2f05e8762`；Judge `product-candidate-j03/common-judge/episode-b33c22960f07a80692f20400.json`，result SHA `f372a68b4eb5b459d993d77110fa1eac5728076d2e3173d16e4298680cce4354`；公开attempt `product-candidate-j03/common-judge/attempts.jsonl` 第2行，record SHA `7a39d02b569632075d35f777bc03132f83ddecdc5ff41222bde4a706a1a284fb`。

### e7-j03-a

- baseline: Episode `product-baseline-j03/runtime/episodes/episode-6c097d560372315174ba255b.json`，Episode SHA `6b2339c7a20701cd2cc39effda913a4791f7cddb1c26b9b3d77823b13e5bfb76`；Judge `product-baseline-j03/common-judge/episode-6c097d560372315174ba255b.json`，result SHA `fe96e8279d6c997df47a92e85168211a5fc4c994eb34318e353f6491f316ab06`；公开attempt `product-baseline-j03/common-judge/attempts.jsonl` 第1行，record SHA `915a13d5c71fc0ed7a97b10f441ed55ea557f7b9a78ea3e95b2dcceeebc1ce32`。
- candidate: Episode `product-candidate-j03/runtime/episodes/episode-6c097d560372315174ba255b.json`，Episode SHA `480bcccd66349e70c280435d1ef32b03d21842ae9ae0ae86b875a11bd496add8`；Judge `product-candidate-j03/common-judge/episode-6c097d560372315174ba255b.json`，result SHA `c9228e0a6e05b739ea39b3b87bf74808b321ddfe84ec32d981202dc095a51e6a`；公开attempt `product-candidate-j03/common-judge/attempts.jsonl` 第1行，record SHA `a9aa8905297bed3fc43ce07bab6b00e53ace9fe98042d47d2abb6f4ab5e7f00e`。


### e7-j04-i

- baseline: Episode `product-baseline-j04/runtime/episodes/episode-458106c8494ef373756797d6.json`，Episode SHA `5775385c8cd6135fd7c2b8cbeba8bbe40b63f75e64985e0462a947e11c8dfbe7`；Judge `product-baseline-j04/common-judge/episode-458106c8494ef373756797d6.json`，result SHA `745c8b5ff6cbbad54f1ac3a56a26840ce2a34e2d976495302dc8c1a7a009b9a0`；公开attempt `product-baseline-j04/common-judge/attempts.jsonl` 第2行，record SHA `c87dfb23954eed75ca3c1a6043be77dfe496a5ad43e3bd0b36bf7cf19d2a1837`。
- candidate: Episode `product-candidate-j04/runtime/episodes/episode-458106c8494ef373756797d6.json`，Episode SHA `a45e6e2d36ff2da511e7b79aeb1131978f752d305bb66f5c585b2274bbe68a4d`；Judge `product-candidate-j04/common-judge/episode-458106c8494ef373756797d6.json`，result SHA `99f0857b9dd3b1b98e70f2a6c15657124687848fe6e0918e18d8b2827fc7ffc9`；公开attempt `product-candidate-j04/common-judge/attempts.jsonl` 第2行，record SHA `11bcc8bf0d57709ca32caa3f52b2ee1c8ccecb0ea495093540e7f01f5a632fbc`。

### e7-j04-a

- baseline: Episode `product-baseline-j04/runtime/episodes/episode-37499c864a07819baf52b43d.json`，Episode SHA `92ae1d606021c83871c55be4f3cffd7a7e75f35dceeca87e55ada456b06cad1d`；Judge `product-baseline-j04/common-judge/episode-37499c864a07819baf52b43d.json`，result SHA `a9de00b8531908e2a4eb47f5528a53a608580e14bce386be8a685b1e0e7c9b5f`；公开attempt `product-baseline-j04/common-judge/attempts.jsonl` 第1行，record SHA `020811170723915db7a32d90fbe2802b541cbd8c6df18ff01dae35bd87757038`。
- candidate: Episode `product-candidate-j04/runtime/episodes/episode-37499c864a07819baf52b43d.json`，Episode SHA `81fe0b2d680ab57005dd912cc429f42c8d1386d14e05edfc507b793724f2a2f7`；Judge `product-candidate-j04/common-judge/episode-37499c864a07819baf52b43d.json`，result SHA `3106da9dfad514a8f8a27dea924cb02ed112cd577f8b941ea2d7c82f53d03ee3`；公开attempt `product-candidate-j04/common-judge/attempts.jsonl` 第1行，record SHA `74a683e2449f7e94bb8ba3352d2d99761cd3cd41e5173a8e9bc35fdfec9eea0d`。

