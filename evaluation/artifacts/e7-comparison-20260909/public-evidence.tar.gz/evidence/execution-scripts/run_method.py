import subprocess,json
from pathlib import Path
r=Path(__file__).parent;py='/root/workspace/tencent_rhinobird2026/learning_travel/.venv/bin/python';ledger='/root/.local/state/learning-travel/e4-hy3-20260905-osj4FCZZ-budget.json'
for repeat,arms in [(1,['baseline','candidate']),(2,['candidate','baseline'])]:
 for arm in arms:
  name=f'method-{arm}-r{repeat}'
  subprocess.run([py,str(r/'invoke.py'),arm,name,str(r/'evaluate_e7_trace.py'),'--run',str(r/'e6/calibration'),'--output',str(r/name),'--budget-ledger',ledger],check=True)
