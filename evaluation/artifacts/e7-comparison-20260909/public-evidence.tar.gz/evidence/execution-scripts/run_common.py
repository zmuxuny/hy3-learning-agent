import subprocess
from pathlib import Path
r=Path(__file__).parent
py='/root/workspace/tencent_rhinobird2026/learning_travel/.venv/bin/python'
script='/root/workspace/tencent_rhinobird2026/learning_travel/evaluation/scripts/evaluate_e7_trace.py'
ledger='/root/.local/state/learning-travel/e4-hy3-20260905-osj4FCZZ-budget.json'
for n in range(1,5):
 for arm in (['baseline','candidate'] if n%2 else ['candidate','baseline']):
  name=f'product-{arm}-j0{n}'
  subprocess.run([py,str(r/'invoke.py'),'candidate',name+'-common-judge',script,'--run',str(r/name),'--output',str(r/name/'common-judge'),'--budget-ledger',ledger],check=True)
for arm in ['baseline','candidate']:
 subprocess.run([py,str(r/'invoke.py'),arm,'controls-'+arm+'-judge',script,'--run',str(r/'controls'),'--output',str(r/('controls-'+arm+'-judge')),'--budget-ledger',ledger],check=True)
subprocess.run([py,str(r/'invoke.py'),'candidate','development-judge',script,'--run',str(r/'development'),'--output',str(r/'development/common-judge'),'--budget-ledger',ledger],check=True)
