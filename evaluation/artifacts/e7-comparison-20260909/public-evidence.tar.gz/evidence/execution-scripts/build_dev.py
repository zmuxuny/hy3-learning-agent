import json
from pathlib import Path
from learning_agent_eval.case_authoring import write_candidate_suite
r=Path.cwd();src=r/'evaluation/datasets/decisionbench-v1.15-validation/development'
cases=[json.loads(p.read_text()) for p in sorted((src/'cases').glob('*.json'))]
cases=[c for c in cases if c['case_id'] in ['dev-ring-planning-p','dev-history-r']]
write_candidate_suite(r/'evaluation/datasets/e7-development',cases=cases,resource_snapshot=src/'resources/snapshot.json',dataset_version='e7-development')
