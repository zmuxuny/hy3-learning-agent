import json
from pathlib import Path
r=Path(__file__).parent;run=r/'controls';m=json.load(open(run/'runtime/run-manifest.json'));rows=[]
for t in m['terminals']:
 e=json.load(open(run/'runtime/episodes'/f"{t['artifact_id']}.json"));rule=json.load(open(run/'rules/rules'/f"{t['artifact_id']}.json"))
 calls=e['observable_trace']['model_calls'];drafts=[]
 for i,c in enumerate(calls):
  for j,tool in enumerate(c['returned_tool_calls']):
   if tool['name']=='plan_proposal_create':
    p=tool['canonical_arguments']['plan'];p=json.loads(p) if isinstance(p,str) else p
    drafts.append(dict(path=f'observable_trace.model_calls[{i}].returned_tool_calls[{j}].canonical_arguments.plan',current_level=p['current_level'],description=p['description'],dates=[{'due':task['due_at'],'review':task['review_due_at']} for stage in p['stages'] for task in stage['tasks']]))
 row=dict(case_id=t['case_id'],episode_sha256=t['artifact_sha256'],drafts=drafts,public_text=[c['assistant_text'] for c in calls],tools=[dict(name=x['tool_name'],status=x['observation_status'],result=x['result']) for x in e['observable_trace']['tool_invocations']],operations=e['observable_trace']['operations'],rule_failures=[x['check_id'] for x in rule['checks'] if x['status']=='fail'],reviewer_role='primary_ai_reviewer')
 rows.append(row)
(r/'controls-content-review.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2));print(json.dumps(rows,ensure_ascii=False))
