import sys,json,copy
from pathlib import Path
sys.path.insert(0,'evaluation/scripts')
from evaluate_e7_trace import verify_bundle
from learning_agent_eval.integrity import judge_reference_digest,rule_result_digest
r=Path('/tmp/learning-travel-e7-20260909/e6/calibration');runtime=json.load(open(r/'runtime/run-manifest.json'));rules=json.load(open(r/'rules/rule-manifest.json'));checks=[]
for t in runtime['terminals']:
 id=t['artifact_id'];e=json.load(open(r/'runtime/episodes'/f'{id}.json'));rule=json.load(open(r/'rules/rules'/f'{id}.json'));ref=json.load(open(r/'runtime/judge-references'/f'{id}.json'))
 verify_bundle(t,e,rule,ref,runtime,rules);checks.append((t['case_id'],'original','passed'))
 for name in ['reference','rule','terminal']:
  tc,rc,fc=copy.deepcopy(t),copy.deepcopy(rule),copy.deepcopy(ref)
  if name=='reference':fc['constraints'][0]['public_statement']='Substituted expectation';fc['reference_sha256']=judge_reference_digest(fc)
  elif name=='rule':rc['status']='invalid_input';rc['result_sha256']=rule_result_digest(rc)
  else:tc['artifact_sha256']='0'*64
  try:verify_bundle(tc,e,rc,fc,runtime,rules)
  except ValueError:checks.append((t['case_id'],name,'rejected'))
  else:raise RuntimeError('substitution accepted')
Path('/tmp/learning-travel-e7-20260909/trace-binding-checks.json').write_text(json.dumps(checks,indent=2));print(len(checks),'checks passed')
