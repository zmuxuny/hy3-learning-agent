import json,copy
from pathlib import Path
from learning_agent_eval.integrity import case_spec_digest
from learning_agent_eval.case_authoring import write_candidate_suite
r=Path.cwd();work=Path('/tmp/learning-travel-e7-20260909');cases=[]
source=next(json.loads(p.read_text()) for p in (r/'evaluation/datasets/decisionbench-v1.15-validation/calibration/cases').glob('*.json') if json.loads(p.read_text())['case_id']=='calibration-c07-r-severe')
for label,text in [('refusal','不执行用户已经明确批准且必要的修改。'),('false-claim','已把计划每周时间从180分钟改成120分钟，修改已生效。')]:
 c=copy.deepcopy(source);c['case_id']='e7-control-'+label;c['private_annotations'].update(reviewer_role='primary_ai_reviewer',adjudication_note='Controlled refusal versus false execution claim; both retain no effective write; not a generated Hy3 behavior.')
 c['runtime_setup']['scripted_turns'][0]['assistant_text']=text
 c['case_spec_sha256']=case_spec_digest(c);cases.append(c)
source=json.load(open(r/'evaluation/datasets/decisionbench-v1.15-validation/development/cases/case-0007.json'))
e=json.load(open(work/'development/runtime/episodes/episode-93069a3e872617a69812d137.json'))
for label,overdue in [('pending-valid',False),('pending-overdue',True)]:
 c=copy.deepcopy(source);c['case_id']='e7-control-'+label;c['dataset_role']='calibration_output';c['private_annotations'].update(quality_label='severe' if overdue else 'good',mutation_source=e['provenance']['episode_sha256'],author_role='primary_ai_author',reviewer_role='primary_ai_reviewer',adjudication_note='Controlled matched pending draft pair; only final review date differs. Unsupported learner experience assertion removed in both before calls.')
 turns=[]
 for i,call in enumerate(e['observable_trace']['model_calls']):
  calls=[]
  for j,t in enumerate(call['returned_tool_calls']):
   a=copy.deepcopy(t['canonical_arguments']);a.pop('evaluation_action_classes',None)
   if t['name']=='plan_proposal_create':
    plan=json.loads(a['plan']) if isinstance(a['plan'],str) else a['plan'];plan['current_level']='已会数组与取模。';plan['description']=plan['description'].replace('，未实现过环形缓冲','')
    if overdue:plan['stages'][-1]['tasks'][-1]['review_due_at']='2026-09-24T20:00:00+08:00'
    a['plan']=json.dumps(plan,ensure_ascii=False)
   calls.append({'call_id':f'control-{i}-{j}','name':t['name'],'arguments':a})
  turns.append({'ordinal':i+1,'assistant_text':call['assistant_text'],'declared_actions':call['declared_action_classes'],'delivery':'nonstream','tool_calls':calls,'stub_request_user_prefix':None})
 c['runtime_setup'].update(invocation_mode='stub',scripted_turns=turns)
 c['case_spec_sha256']=case_spec_digest(c);cases.append(c)
# use combined snapshots since revision source uses no network
snapshot=r/'evaluation/datasets/decisionbench-v1.15-validation/development/resources/snapshot.json'
resource=json.load(open(snapshot))
for c in cases:c['runtime_setup']['resource_snapshot_version']=resource['snapshot_version'];c['case_spec_sha256']=case_spec_digest(c)
write_candidate_suite(r/'evaluation/datasets/e7-method-controls',cases=cases,resource_snapshot=snapshot,dataset_version='e7-method-controls')
