import os,sys,json,subprocess,time
from pathlib import Path
from dotenv import dotenv_values
root=Path(__file__).parent
arm,label,*args=sys.argv[1:];copy=root/arm
assert not (copy/'.env').exists()
env={**os.environ,'PYTHONPATH':str(copy/'evaluation/src')+':'+str(copy/'backend'),'PYTHONDONTWRITEBYTECODE':'1'}
values=dotenv_values('/root/workspace/tencent_rhinobird2026/learning_travel/.env')
for k in ('OPENAI_API_KEY','OPENAI_API_BASE','OPENAI_MODEL_NAME'):
 if values.get(k):env[k]=values[k]
cmd=['/root/workspace/tencent_rhinobird2026/learning_travel/.venv/bin/python',*args]
start=time.time()
(root/'logs').mkdir(exist_ok=True)
with (root/'logs'/f'{label}.log').open('x') as log:p=subprocess.run(cmd,cwd=copy,env=env,stdout=log,stderr=subprocess.STDOUT)
(root/'logs'/f'{label}.json').write_text(json.dumps({'command':cmd,'arm':arm,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=copy,text=True).strip(),'exit_code':p.returncode,'seconds':time.time()-start},indent=2))
print(label,p.returncode,flush=True)
sys.exit(p.returncode)
