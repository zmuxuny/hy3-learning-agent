import json,hashlib,subprocess,tarfile,os
from pathlib import Path
r=Path(__file__).parent;repo=Path('/root/workspace/tencent_rhinobird2026/learning_travel');a=repo/'evaluation/artifacts/e7-comparison-20260909';source=r/'verification';dest=r/'repro-unpack';dest.mkdir(exist_ok=False)
with tarfile.open(a/'public-evidence.tar.gz') as tar:tar.extractall(dest,filter='data')
evidence=dest/'evidence';manifest=json.load(open(evidence/'file-manifest.json'))
assert set(manifest)=={str(p.relative_to(evidence)) for p in evidence.rglob('*') if p.is_file() and p.name!='file-manifest.json'}
for name,v in manifest.items():
 data=(evidence/name).read_bytes();assert len(data)==v['bytes'] and hashlib.sha256(data).hexdigest()==v['sha256']
env={**os.environ,'PYTHONPATH':str(source/'evaluation/src')+':'+str(source/'backend')}
assert subprocess.check_output(['git','status','--porcelain'],cwd=source)==b''
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip();assert commit.startswith('e8c3e2d')
subprocess.run([str(r/'repro-venv/bin/python'),str(source/'evaluation/scripts/summarize_e7.py'),'--evidence',str(evidence),'--output',str(r/'fresh-recomputed')],cwd=source,env=env,check=True)
files={}
for name in ['summary.json','slots.csv','pairs.csv','method-stability.csv']:
 data=(a/name).read_bytes();assert data==(r/'fresh-recomputed'/name).read_bytes();files[name]=hashlib.sha256(data).hexdigest()
subprocess.run(['git','bundle','verify',str(a/'baseline-controls.bundle')],cwd=source,check=True,capture_output=True)
# Search exact configured key values without displaying them or writing secret-containing findings.
from dotenv import dotenv_values
secrets=[v.encode() for k,v in dotenv_values(repo/'.env').items() if v and ('KEY' in k.upper() or 'TOKEN' in k.upper() or 'SECRET' in k.upper()) and len(v)>=12]
checked=0
for base in [evidence,a]:
 for path in base.rglob('*'):
  if not path.is_file() or path.suffix in ['.gz','.bundle','.png','.pdf']:continue
  assert path.name not in ['.env'] and path.suffix not in ['.db','.sqlite','.sqlite3','.pyc']
  assert not any(x in path.parts for x in ['__pycache__','.venv','node_modules'])
  data=path.read_bytes();assert not any(secret in data for secret in secrets),str(path)
  checked+=1
receipt=dict(version='e7-reproduction-checks-v1',fresh_environment=True,source_commit=commit,dependency_lock='evaluation/runtime-requirements.lock',api_calls=0,public_files_verified=len(manifest),byte_identical_recomputed_files=files,baseline_controls_bundle_verified=True,public_text_files_checked_for_configured_secrets=checked,no_configured_secrets_found=True,no_product_databases_or_caches_in_public_evidence=True,mini_receipt='evidence/fresh-mini/receipt.json')
(a/'reproduction-checks.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(receipt))
