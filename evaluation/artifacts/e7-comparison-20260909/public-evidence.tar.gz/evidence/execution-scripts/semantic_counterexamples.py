import json
from pathlib import Path
from datetime import datetime,timedelta
r=Path(__file__).parent

def episode(batch,case):
 t=next(x for x in json.load(open(r/batch/'runtime/run-manifest.json'))['terminals'] if x['case_id']==case)
 return json.load(open(r/batch/'runtime/episodes'/f"{t['artifact_id']}.json")),t

e,t=episode('product-candidate-j02','e7-j02-p')
args=next(c['canonical_arguments'] for m in e['observable_trace']['model_calls'] for c in m['returned_tool_calls'] if c['name']=='plan_proposal_create')
plan=json.loads(args['plan']) if isinstance(args['plan'],str) else args['plan']
assert '相等值不入栈' in plan['expected_outcome']
def stack_replay(nums,skip_equal):
 ans=[-1]*len(nums);stack=[]
 for i,v in enumerate(nums):
  while stack and nums[stack[-1]]<v: ans[stack.pop()]=v
  if skip_equal and stack and nums[stack[-1]]==v: continue
  stack.append(i)
 return ans
wrong=stack_replay([2,2,3],True);right=stack_replay([2,2,3],False)
assert wrong==[3,-1,-1] and right==[3,3,-1]
rows=[dict(case_id=t['case_id'],episode_sha256=t['artifact_sha256'],kind='reviewer_implementation_of_public_plan_steps_not_model_submitted_code',claim=plan['expected_outcome'],input=[2,2,3],replayed=wrong,expected=right,evidence_paths=['observable_trace.model_calls','observable_trace.tool_invocations'])]
e,t=episode('product-candidate-j02','e7-j02-i')
text=e['result']['user_visible_output'];assert '04:50' in text
last=datetime.fromisoformat('2026-09-09T02:00:00+00:00');now=datetime.fromisoformat('2026-09-09T02:20:00+00:00')
correct=last+timedelta(minutes=150);incorrect=now+timedelta(minutes=150)
rows.append(dict(case_id=t['case_id'],episode_sha256=t['artifact_sha256'],kind='UTC_arithmetic_recheck',last_notification=last.isoformat(),now=now.isoformat(),cooldown_minutes=150,correct_end=correct.isoformat(),claimed_end=incorrect.isoformat(),error_minutes=20,evidence_paths=['result.user_visible_output','state_after']))
(r/'semantic-counterexamples.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
print('2 explicit content counterexamples verified')
