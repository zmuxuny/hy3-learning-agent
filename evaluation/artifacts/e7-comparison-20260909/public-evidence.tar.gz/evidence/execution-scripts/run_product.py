import subprocess,json
from pathlib import Path
r=Path(__file__).parent;py='/root/workspace/tencent_rhinobird2026/learning_travel/.venv/bin/python';ledger='/root/.local/state/learning-travel/e4-hy3-20260905-osj4FCZZ-budget.json'
for family in range(1,5):
 for arm in (['baseline','candidate'] if family%2 else ['candidate','baseline']):
  name=f'product-{arm}-j{family:02d}';run=r/name;dataset=f'evaluation/datasets/e7-test-e7-j{family:02d}'
  for stage,args in [('runtime',['run-agent','--dataset',dataset,'--manifest',dataset+'/manifest.json','--output',str(run/'runtime'),'--model-mode','real','--allow-real-model','--budget-ledger',ledger]),('rules',['evaluate-rules','--input',str(run/'runtime'),'--output',str(run/'rules')])]:
   manifest=run/stage/('run-manifest.json' if stage=='runtime' else 'rule-manifest.json')
   if manifest.exists():continue
   label=name+'-'+stage
   if (r/'logs'/(label+'.log')).exists():label+='-cli-corrected'
   p=subprocess.run([py,str(r/'invoke.py'),'product-'+arm,label,'-m','learning_agent_eval',*args])
   if not (run/stage/('run-manifest.json' if stage=='runtime' else 'rule-manifest.json')).exists():raise RuntimeError('missing terminal manifest '+name+' '+stage)
