import json,hashlib,collections,subprocess
from pathlib import Path
from learning_agent_eval.canonical import sha256_digest
r=Path(__file__).parent;repo=Path('/root/workspace/tencent_rhinobird2026/learning_travel')
index=json.load(open(r/'experiment-index.json'));summary=json.load(open(r/'comparison/summary.json'))
before=json.load(open(r/'budget-before.json'));after=json.load(open('/root/.local/state/learning-travel/e4-hy3-20260905-osj4FCZZ-budget.json'))
assert before['requests']==after['requests'][:len(before['requests'])]
assert before['limit_micro_cny']==after['limit_micro_cny']
new=after['requests'][len(before['requests']):];assert all(x['status']!='reserved' for x in new)
(r/'budget-after.json').write_text(json.dumps(after,ensure_ascii=False,indent=2)+'\n')
tickets={};attempt_count=0;response_matches=0
for b in index['batches']:
 directory=r/b['judge'];attempts=[json.loads(x) for x in (directory/'attempts.jsonl').read_text().splitlines()]
 for attempt in attempts:
  digest=attempt.pop('record_sha256');assert sha256_digest(attempt)==digest
  assert sha256_digest(attempt['public_response'])==attempt['public_response_sha256']
  if attempt['budget_ticket'] is not None:
   ticket=int(attempt['budget_ticket']);assert ticket not in tickets;tickets[ticket]=b['kind']+'_judge'
  attempt_count+=1
 for x in json.load(open(directory/'comparison-manifest.json'))['rows']:
  j=json.load(open(directory/x['judge_result']))
  if j['status']=='complete':
   response=next(v['public_response'] for v in reversed(attempts) if v['episode_id']==j['episode_id'] and v['public_response'] is not None)
   assert response['dimensions']==j['dimensions'] and response['semantic_issues']==j['semantic_issues'] and response['suggested_hard_gates']==j['suggested_hard_gates']
   response_matches+=1
bykind={}
for x in new:
 kind=tickets.get(int(x['ticket']),'development_runtime' if x['scope'].startswith('dev-') else 'product_runtime')
 v=bykind.setdefault(kind,dict(requests=0,charged_micro_cny=0,unknown_usage_micro_cny=0));v['requests']+=1;v['charged_micro_cny']+=x['charged_micro_cny']
 if x['status']=='unknown_usage_reserved':v['unknown_usage_micro_cny']+=x['charged_micro_cny']
occupied=lambda b:sum(x['charged_micro_cny'] for x in b['requests'])
budget=dict(version='e7-budget-audit-v1',pricing_basis=after['pricing_basis'],account_invoice_verified=False,before_requests=len(before['requests']),after_requests=len(after['requests']),new_requests=len(new),prior_requests_unchanged=True,limit_unchanged=True,limit_micro_cny=after['limit_micro_cny'],before_occupied_micro_cny=occupied(before),after_occupied_micro_cny=occupied(after),new_occupied_micro_cny=occupied(after)-occupied(before),remaining_micro_cny=after['limit_micro_cny']-occupied(after),new_request_statuses=dict(collections.Counter(x['status'] for x in new)),by_kind=bykind)
(r/'budget-audit.json').write_text(json.dumps(budget,ensure_ascii=False,indent=2)+'\n')
review_rows=[(x['batch'],x,False) for x in json.load(open(r/'main-judge-content-review.json'))]+[(x['batch']+'/common-judge',x,True) for x in json.load(open(r/'product-ia-judge-review.json'))['rows']]
expected={(x['judge'],x['case_id']):x for x in summary['rows']}
assert len(review_rows)==len(expected)==90
assert len({(batch,x['case_id']) for batch,x,_ in review_rows})==90
for batch,x,delegated in review_rows:
 row=expected[(batch,x['case_id'])]
 for key in ['episode_id','episode_sha256','judge_result_sha256']:assert x[key]==row[key]
 levels={d['dimension']:d['judge_level'] for d in x['dimensions'] if d['judge_level'] is not None} if delegated else {d['dimension_id']:d['level'] for d in x['dimensions']}
 assert levels==row['dimensions']
weights=[15,15,20,20,15,5,10];arithmetic=0
for row in summary['rows']:
 if row['score'] is None:continue
 raw=sum(w*row['dimensions'][f'D{i}']/2 for i,w in enumerate(weights,1));assert raw==row['raw_score']
 rule=json.load(open(r/row['run']/'rules/rules'/f"{row['episode_id']}.json"));fails=[x for x in rule['checks'] if x['status']=='fail']
 cap=39 if any(x['severity']=='critical' for x in fails) or row['confirmed_critical'] else 69 if any(x['severity']=='major' for x in fails) else 100
 assert min(raw,cap)==row['score'];arithmetic+=1
old_artifacts=[]
for name in subprocess.check_output(['git','ls-tree','-r','--name-only','bf06d36','evaluation/artifacts'],cwd=repo,text=True).splitlines():
 data=subprocess.check_output(['git','show','bf06d36:'+name],cwd=repo)
 assert (repo/name).read_bytes()==data;old_artifacts.append(name)
checks=dict(version='e7-final-validation-v1',recompute_source_commit='e8c3e2d',product_regressions=dict(passed=62,source_commit='22bfd40',log='regressions.log'),final_protocol_schema_comparison_regressions=dict(passed=35,source_commit='e8c3e2d',log='final-e7-tests.log',command='pytest -q evaluation/tests/test_e6_release_versions.py evaluation/tests/test_e312_release_governance.py evaluation/tests/test_protocol_schemas.py evaluation/tests/test_e7_comparison.py'),mini_receipt='fresh-mini/receipt.json',fixed_slots=len(summary['rows']),reviewed_slot_bindings_verified=len(review_rows),raw_attempt_records_verified=attempt_count,raw_responses_equal_judge_results=response_matches,independent_score_arithmetic_checks=arithmetic,pending_semantic_reviews=sum(bool(x['pending']) for x in summary['rows']),historical_artifact_files_unchanged=len(old_artifacts),history_budget_prefix_unchanged=True)
(r/'validation-checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(budget,ensure_ascii=False));print(json.dumps(checks))
