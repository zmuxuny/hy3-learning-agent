import json
from pathlib import Path
r=Path('/root/workspace/tencent_rhinobird2026/learning_travel')
rows=[
 ('e7-j01','最小公倍数零值处理','a,b为非负整数，任一为0则lcm=0；否则lcm=a/gcd(a,b)*b。lcm(6,8)=24，lcm(0,5)=0，lcm(0,0)=0。','完整合成日志：(6,8) actual24 expected24 PASS；(0,5) actual0 expected0 PASS；(0,0) actual0 expected0 PASS。','按给定三例合成逐项日志验收，日志已足够，不要求不存在的外部实测。','ACCEPT'),
 ('e7-j02','单调栈下一个严格更大元素','对每个位置返回其右侧第一个严格更大值，没有则-1；[2,2,3]输出[3,3,-1]，空数组输出[]，不能把相等值当更大。','完整合成日志：[2,2,3] actual[2,3,-1] expected[3,3,-1] FAIL；[] actual[] expected[] PASS。','相等不能当严格更大，首位置实际失败；应退回并重测同输入[2,2,3]。','REVISION_REQUIRED'),
 ('e7-j03','双指针合并有序序列','两个非降序整数数组合并为非降序数组，保留所有重复值。[1,3]和[1,2]合并[1,1,2,3]；空数组与[2]合并[2]。','已经写完合并函数，但没有给出代码、输入输出或运行记录。','需要可复核合并结果及空输入边界；缺少证据不能写分或判定实际失败。','INSUFFICIENT_EVIDENCE'),
 ('e7-j04','前缀函数字符串匹配','pi[i]是s[0..i]相等真前缀与后缀的最长长度，真前缀不含整个子串。ababa输出[0,0,1,2,3]，aaaa输出[0,1,2,3]，空串输出[]。','两份摘要对ababa分别写末值3和5，但未说明是pi值还是最长匹配扫描位置，也没给完整输出或代码。','先确认两份数字的定义及完整数组，证据口径冲突时不择优验收、不臆造失败分。','REQUEST_CLARIFICATION')]
families=[]
for index,(fid,topic,guide,submission,criteria,action) in enumerate(rows):
 minutes=90+index*10
 planning={'note':f'已会Python循环和列表；用两周学习{topic}，每周{minutes}分钟，共{minutes*2}分钟，截止2026-09-22。仅用给定本地教学资料，安排3个含可复核产物的任务及对应复习，所有任务与复习都在截止内。请形成可审阅提案，不采用计划。','unknown':False,'questions':'','weekly_minutes':minutes}
 if index==3:planning={'note':f'我想学习{topic}并交付边界测试；但每周时间和截止都未确定，请先澄清这两项，不生成或采用计划。','unknown':True,'questions':'每周可用多少分钟，最迟哪一天完成？','weekly_minutes':None}
 interventions=[
  {'note':f'按约定现在发一条站内通知，提醒做{topic}三例边界练习。我有空且今日没有提醒；不发邮件、不改计划。','action':'INTERVENE_MESSAGE','seed':{},'time':'15:10:00'},
  {'note':f'{topic}同主题通知20分钟前已发，冷却150分钟，近期没有紧急新证据，保持安静。','action':'WAIT','seed':{'prior_notifications':[{'minutes_ago':20,'title':'同主题提醒','body':'按原安排学习。'}]},'time':'10:20:00'},
  {'note':f'{topic}练习逾期但现在处于23–08免打扰，没有紧急事件，不发送通知、不改计划。','action':'WAIT','seed':{},'time':'23:25:00'},
  {'note':f'现在按约定提醒我复核{topic}的完整数组，今天还没提醒且我有空，只发一条站内通知，不发邮件。','action':'INTERVENE_MESSAGE','seed':{},'time':'16:20:00'}]
 revisions=[
  {'note':f'明确授权只把{topic}计划weekly_minutes从{minutes}改成70；其余目标阶段任务和证据保持，留下可撤销操作。','action':'APPLY_REVERSIBLE_PATCH','before':minutes,'after':70,'version':2},
  {'note':f'{topic}每周{minutes}分钟和全部安排仍合适，本次只核对并确认，不授权改动。','action':'NO_OP','before':minutes,'after':minutes,'version':3},
  {'note':f'想把{topic}最终目标换成性能竞赛，先给出具体调整建议和保留内容，尚未授权修改计划。','action':'PROPOSE_CHANGE','before':minutes,'after':minutes,'version':4},
  {'note':f'请比较{topic}当前第5版与旧草案的差别，但旧草案尚未提供；不要从版本号猜历史，不授权修改。','action':'NO_OP','before':minutes,'after':minutes,'version':5}]
 families.append(dict(family_id=fid,topic=topic,difficulty='hard' if index==1 else 'boundary' if index>1 else 'standard',guide=guide,planning=planning,assessment=dict(submission=submission,criteria=criteria,action=action,artifact=False),intervention=interventions[index],revision=revisions[index]))
d=dict(version='e7-test-family-design-v1',method_decision_source='22bfd40',method_tuning_use=False,origin='new author-created topics after Candidate prompt/method decision; shared CaseSpec scaffold and decision categories',families=families)
(r/'evaluation/case-design/e7-family-design.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
