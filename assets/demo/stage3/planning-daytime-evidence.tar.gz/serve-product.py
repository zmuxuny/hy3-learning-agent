import asyncio,json,os,sys,time
from pathlib import Path
from datetime import datetime,timedelta,timezone
from dotenv import dotenv_values
SOURCE=Path('/tmp/learning-demo-daytime-product');OUT=Path('/tmp/learning-demo-daytime-update')
for k,v in dotenv_values('/root/workspace/tencent_rhinobird2026/learning_travel/.env').items():
 if v is not None and k in {'OPENAI_API_KEY','OPENAI_API_BASE','MODEL_NAME','MODEL_CONTEXT_WINDOW','MODEL_REASONING_EFFORT'}:os.environ[k]=v
os.environ.update(RUNTIME_STATE_ROOT=str(SOURCE),DATABASE_URL='sqlite+aiosqlite:///'+str(SOURCE/'data/learning_companion.db'),ENABLE_SCHEDULER='false',ENABLE_EMAIL_REPLY_POLLING='false',DEFAULT_TIMEZONE='Asia/Shanghai',AGENT_MAX_MODEL_CALLS='10',AGENT_MAX_STEPS='12')
sys.path[:0]=[str(SOURCE/'backend'),str(SOURCE/'evaluation/src')]
import app.core.time as clock
start=time.monotonic();fixed=datetime(2026,9,11,7,0,tzinfo=timezone.utc)
clock.utc_now=lambda:fixed+timedelta(seconds=time.monotonic()-start)
from app.core.config import settings,prepare_runtime_directories
from app.runtime.model_clients import use_model_client_factory,current_model_call_metadata
from learning_agent_eval.recorder import EvaluationModelRecorder
from learning_agent_eval.model_budget import ModelBudget
from app.db.database import create_schema,AsyncSessionLocal
from app.main import app,ensure_local_owner
from app.models import UserProfile
from openai import AsyncOpenAI
import uvicorn
ledger=ModelBudget('/root/.local/state/learning-travel/e4-hy3-20260905-osj4FCZZ-budget.json')
recorder=EvaluationModelRecorder(AsyncOpenAI(api_key=settings.OPENAI_API_KEY,base_url=settings.OPENAI_API_BASE,max_retries=0),invocation_mode='real',metadata_provider=current_model_call_metadata,max_calls=20,max_output_tokens=16000,budget=ledger,budget_scope='demo-daytime-product-20260914')
async def monitor():
 while True:
  await asyncio.sleep(3)
  (OUT/'product-model-calls.json').write_text(json.dumps(recorder.records,ensure_ascii=False,indent=2,default=str))
  (OUT/'product-budget-after.json').write_text(json.dumps(ledger.summary(),indent=2))
async def main():
 (OUT/'product-budget-before.json').write_text(json.dumps(ledger.summary(),indent=2))
 with use_model_client_factory(lambda:recorder):
  prepare_runtime_directories();await create_schema(state_root=SOURCE);await ensure_local_owner()
  async with AsyncSessionLocal() as db:
   p=await db.get(UserProfile,'local');p.preferences={'learning_hours':'每天15:00—17:00之间选择30分钟学习','resources':'Python标准库与中文资料'};await db.commit()
  task=asyncio.create_task(monitor())
  try:await uvicorn.Server(uvicorn.Config(app,host='127.0.0.1',port=8768,log_level='warning')).serve()
  finally:task.cancel()
asyncio.run(main())
