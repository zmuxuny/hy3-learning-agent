import argparse
import sys
from pathlib import Path

parser = argparse.ArgumentParser(description="目录统计工具：路径校验")
parser.add_argument("directory")
args = parser.parse_args()
path = Path(args.directory)
if not path.exists() or not path.is_dir():
    print("错误：请输入存在的目录", file=sys.stderr)
    raise SystemExit(1)
print("目录有效，可以开始统计")
