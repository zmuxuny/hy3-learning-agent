import asyncio, json, os, sys, time
from datetime import datetime,timedelta,timezone
from pathlib import Path
from dotenv import dotenv_values
SOURCE=Path('/tmp/learning-daytime-demo')
STATE=SOURCE
OUT=Path('/tmp/learning-daytime-work')
for k,v in dotenv_values('/root/workspace/tencent_rhinobird2026/learning_travel/.env').items():
    if v is not None and k in {'OPENAI_API_KEY','OPENAI_API_BASE','MODEL_NAME','MODEL_CONTEXT_WINDOW','MODEL_REASONING_EFFORT'}:os.environ[k]=v
os.environ.update(RUNTIME_STATE_ROOT=str(STATE),DATABASE_URL='sqlite+aiosqlite:///'+str(STATE/'data/learning_companion.db'),ENABLE_SCHEDULER='true',AGENT_HEARTBEAT_SECONDS='15',ENABLE_EMAIL_REPLY_POLLING='false',DEFAULT_TIMEZONE='Asia/Shanghai',AGENT_MAX_MODEL_CALLS='8',AGENT_MAX_STEPS='8')
sys.path[:0]=[str(SOURCE/'backend'),str(SOURCE/'evaluation/src')]
from app.core.config import settings,prepare_runtime_directories
from app.core.time import frozen_utc
import app.core.time as demo_clock
FIXED=datetime(2026,9,11,7,0,tzinfo=timezone.utc)
clock_start=time.monotonic()
def scenario_now():
    return FIXED+timedelta(seconds=time.monotonic()-clock_start)
demo_clock.utc_now=scenario_now
from app.runtime.model_clients import use_model_client_factory,current_model_call_metadata
from learning_agent_eval.recorder import EvaluationModelRecorder
from learning_agent_eval.model_budget import ModelBudget
from app.db.database import create_schema,AsyncSessionLocal
from app.main import app,ensure_local_owner
from app.models import Plan,Stage,Task,UserProfile,Notification
from app.runtime.scheduler import proactive_scheduler
from openai import AsyncOpenAI
from sqlalchemy import select
import uvicorn
FIXED=datetime(2026,9,11,7,0,tzinfo=timezone.utc)
ledger=ModelBudget('/root/.local/state/learning-travel/e4-hy3-20260905-osj4FCZZ-budget.json')
client=AsyncOpenAI(api_key=settings.OPENAI_API_KEY,base_url=settings.OPENAI_API_BASE,max_retries=0)
recorder=EvaluationModelRecorder(client,invocation_mode='real',metadata_provider=current_model_call_metadata,max_calls=10,max_output_tokens=16000,budget=ledger,budget_scope='readme-daytime-proactive-20260913')
async def seed():
    prepare_runtime_directories();await create_schema(state_root=STATE);await ensure_local_owner()
    async with AsyncSessionLocal() as db:
        profile=await db.get(UserProfile,'local')
        profile.preferences={'learning_hours':'每天15:00—17:00之间选择30分钟学习；仅需站内提醒。提醒请用简短自然段，便于阅读' ,'resources':'Python官方中文文档和标准库；本地练习'}
        plan=Plan(owner_id='local',title='一周完成目录文件统计工具',goal='掌握 pathlib，并实现可验证的文件统计工具',current_level='会Python基础语法',weekly_minutes=210,expected_outcome='统计目录内的文件类型与大小，保留测试输入和输出',status='active')
        db.add(plan);await db.flush()
        stage=Stage(plan_id=plan.id,title='目录遍历与统计',description='从可运行的小例子逐步完成工具',position=0,status='active');db.add(stage);await db.flush()
        db.add_all([Task(stage_id=stage.id,title='用 pathlib 列出目录中的文件',description='准备包含两个文本文件的 samples 目录，用 Path.iterdir() 遍历，以 is_file() 筛选并输出文件名。验证只输出文件，不包含子目录。',estimated_minutes=30,is_core=True,evidence_required=True,status='pending',position=0,due_at=FIXED+timedelta(hours=1)),Task(stage_id=stage.id,title='按扩展名统计文件数量与大小',description='在遍历基础上累计文件数量与 stat().st_size，提供空目录测试。先完成目录遍历任务。',estimated_minutes=60,status='pending',position=1,due_at=FIXED+timedelta(hours=2))]);await db.commit()
async def monitor():
    for i in range(180):
        await asyncio.sleep(5)
        (OUT/'model-calls.json').write_text(json.dumps(recorder.records,ensure_ascii=False,indent=2,default=str))
        async with AsyncSessionLocal() as db:
            notes=(await db.execute(select(Notification))).scalars().all()
        if notes:
            # Stop further heartbeats after the real notification has been persisted.
            proactive_scheduler._loop_task.cancel()
            print('NOTIFICATION_READY',notes[-1].title,flush=True)
            (OUT/'ready.json').write_text(json.dumps({'notification_id':notes[-1].id,'title':notes[-1].title,'body':notes[-1].body},ensure_ascii=False,indent=2))
            return
async def main():
    (OUT/'budget-before.json').write_text(json.dumps(ledger.summary(),indent=2))
    with use_model_client_factory(lambda:recorder):
        await seed()
        task=asyncio.create_task(monitor())
        try:await uvicorn.Server(uvicorn.Config(app,host='127.0.0.1',port=8766,log_level='warning')).serve()
        finally:
            task.cancel();(OUT/'model-calls.json').write_text(json.dumps(recorder.records,ensure_ascii=False,indent=2,default=str));(OUT/'budget-after.json').write_text(json.dumps(ledger.summary(),indent=2))
asyncio.run(main())
