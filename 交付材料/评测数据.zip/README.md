# 评测数据与离线复算

本包包含测试输入、原始决策证据、模型请求与响应、人工原始标注、协商参考、统计结果及复算代码。目录保留仓库相对路径。包内SHA256SUMS.json逐文件列出摘要。

Python 3.11或以上，解压后在本目录运行：

```bash
python -m venv .venv
.venv/bin/pip install ./evaluation
PYTHONPATH=evaluation/src .venv/bin/python evaluation/scripts/summarize_final_method.py --archive evaluation/artifacts/decisionbench-final-method-20260910 --output /tmp/recomputed-main
PYTHONPATH=evaluation/src .venv/bin/python evaluation/scripts/summarize_condition_validation.py --archive evaluation/artifacts/condition-validation-20260910 --output /tmp/recomputed-conditions
PYTHONPATH=evaluation/src .venv/bin/python evaluation/scripts/summarize_condition_insight.py --archive evaluation/artifacts/condition-insight-20260910 --output /tmp/recomputed-insight
python evaluation/scripts/summarize_human_confirmation.py --output /tmp/recomputed-human
```

以上命令不调用模型。输出分别与对应档案的automatic目录及human-confirmation-20260910中的CSV/JSON比较。主体实验200次评分，条件验证36次评分，卷积诊断单独统计；人工比较使用48个应用案例。两份原始标注与协商参考在交付材料/人工标注。

完整产品、图文报告和Demo由仓库根目录的第三阶段交付说明提供。
